import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Monitor, 
  FileText, 
  Clock, 
  CreditCard, 
  TrendingUp, 
  Users, 
  Calendar, 
  Lightbulb, 
  ArrowUpRight, 
  Plus, 
  Zap, 
  Target, 
  BarChart3, 
  Star,
  Globe,
  CheckCircle,
  AlertCircle
} from './icons';
import { useBia } from './BiaContext';
import { ARTICLE_SAVINGS_VALUE, ARTICLE_TIME_SAVED_HOURS, FREE_PLAN_LIMITS, getPlanLimits, isFreePlan } from '../utils/constants';

interface DashboardProps {
  userData: any;
  onNavigate?: (page: string) => void;
  onUpdateUser?: (userData: any) => Promise<boolean>;
}

export function Dashboard({ userData, onNavigate, onUpdateUser }: DashboardProps) {
  const { state, actions } = useBia();

  // Default navigation function if not provided
  const handleNavigate = (page: string) => {
    if (onNavigate) {
      onNavigate(page);
    } else {
      // Fallback navigation using hash
      window.location.hash = page;
    }
  };

  // Usar dados reais do contexto BIA
  const sites = state.sites || [];
  const ideas = state.ideas || [];
  const articles = state.articles || [];

  // Verificar se é plano gratuito e obter limites
  const userPlan = userData?.plano || 'Free';
  const isFree = isFreePlan(userPlan);
  const planLimits = getPlanLimits(userPlan);
  const currentPlan = userData?.plano || 'Free';

  const formatMoney = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const completedArticles = articles.filter(a => a.status === 'Concluído' || a.status === 'Publicado');
  const publishedArticles = articles.filter(a => a.status === 'Publicado');
  const activeSites = sites.filter(s => s.status === 'ativo');

  // Estatísticas principais com design clean e ícones roxos
  const mainStats = [
    {
      title: 'Sites Conectados',
      value: sites.length,
      maxValue: planLimits.isUnlimited ? '∞' : planLimits.sites,
      icon: Monitor,
      description: `${activeSites.length} ativos`,
      action: 'sites',
      isUnlimited: planLimits.isUnlimited
    },
    {
      title: 'Ideias Geradas',
      value: ideas.length,
      maxValue: isFree ? planLimits.ideas : '∞',
      icon: Lightbulb,
      description: 'Disponíveis para produção',
      action: 'ideas',
      isUnlimited: !isFree
    },
    {
      title: 'Artigos Produzidos',
      value: completedArticles.length,
      maxValue: planLimits.articles,
      icon: FileText,
      description: `${publishedArticles.length} publicados`,
      action: 'articles',
      isUnlimited: false
    },
    {
      title: 'Economia',
      value: formatMoney(completedArticles.length * ARTICLE_SAVINGS_VALUE),
      subValue: `${(completedArticles.length * ARTICLE_TIME_SAVED_HOURS).toFixed(1)}h economizadas`,
      icon: TrendingUp,
      description: 'Em produção manual',
      action: 'articles',
      isMonetary: true
    }
  ];

  // Atividades recentes organizadas
  const recentActivities = [
    ...articles
      .filter(a => a.status === 'Publicado')
      .slice(0, 3)
      .map(article => ({
        id: `article-${article.id}`,
        title: `Artigo publicado: "${article.titulo.substring(0, 40)}..."`,
        time: new Date(article.updatedAt).toLocaleDateString('pt-BR'),
        type: 'published',
        icon: CheckCircle
      })),
    ...articles
      .filter(a => a.status === 'Produzindo')
      .slice(0, 2)
      .map(article => ({
        id: `producing-${article.id}`,
        title: `Produzindo: "${article.titulo.substring(0, 40)}..."`,
        time: new Date(article.updatedAt).toLocaleDateString('pt-BR'),
        type: 'producing',
        icon: Zap
      })),
    ...ideas
      .slice(0, 2)
      .map(idea => ({
        id: `idea-${idea.id}`,
        title: `Nova ideia: "${idea.titulo.substring(0, 40)}..."`,
        time: new Date(idea.createdAt).toLocaleDateString('pt-BR'),
        type: 'ideas',
        icon: Lightbulb
      })),
    ...sites
      .slice(0, 1)
      .map(site => ({
        id: `site-${site.id}`,
        title: `Site conectado: "${site.nome}"`,
        time: new Date(site.createdAt).toLocaleDateString('pt-BR'),
        type: 'connected',
        icon: Globe
      }))
  ].slice(0, 6);

  // Ações rápidas organizadas
  const quickActions = [
    {
      title: 'Gerar Ideias',
      description: 'Crie novos temas com IA',
      icon: Lightbulb,
      action: 'ideas',
      badge: null,
      priority: 'high'
    },
    {
      title: 'Produzir Artigos',
      description: 'Transforme ideias em conteúdo',
      icon: FileText,
      action: 'articles',
      badge: ideas.length > 0 ? `${ideas.length} disponíveis` : null,
      priority: 'high'
    },
    {
      title: 'Agendar Posts',
      description: 'Programe publicações',
      icon: Clock,
      action: 'schedule',
      badge: null,
      priority: 'medium'
    },
    {
      title: 'Calendário',
      description: 'Visualize programações',
      icon: Calendar,
      action: 'calendar',
      badge: null,
      priority: 'medium'
    }
  ];

  // Calcular progresso geral
  const calculateOverallProgress = () => {
    if (isFree) {
      const sitesProgress = (sites.length / planLimits.sites) * 100;
      const ideasProgress = (ideas.length / planLimits.ideas) * 100;
      const articlesProgress = (completedArticles.length / planLimits.articles) * 100;
      return Math.min(100, (sitesProgress + ideasProgress + articlesProgress) / 3);
    }
    return 45; // Para planos pagos, mostrar um progresso moderado
  };

  const overallProgress = calculateOverallProgress();

  return (
    <div className="space-y-8">
      {/* Header Clean */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div>
          <h1 className="font-poppins text-2xl text-black mb-2">
            Dashboard
          </h1>
          <p className="font-montserrat text-gray-600">
            Olá, <strong>{userData?.name || 'Usuário'}</strong>! Aqui está um resumo da sua conta BIA.
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Badge 
            variant="outline"
            className="px-3 py-1 font-montserrat text-gray-700 border-gray-200"
          >
            Plano {currentPlan}
          </Badge>
          <Button 
            onClick={() => handleNavigate('ideas')}
            className="font-montserrat"
            style={{ backgroundColor: '#8B5FBF' }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Nova Ideia
          </Button>
        </div>
      </div>

      {/* Status do Plano Clean */}
      {isFree && (
        <Card className="border border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="flex items-center justify-center w-10 h-10 bg-gray-100 rounded-lg flex-shrink-0">
                <AlertCircle className="h-5 w-5" style={{ color: '#8B5FBF' }} />
              </div>
              <div className="flex-1">
                <h3 className="font-poppins text-lg text-black mb-3">
                  Plano Gratuito
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="font-poppins text-xl text-black mb-1">
                      {sites.length}/{FREE_PLAN_LIMITS.sites}
                    </div>
                    <div className="font-montserrat text-sm text-gray-600">Sites Conectados</div>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="font-poppins text-xl text-black mb-1">
                      {ideas.length}/{FREE_PLAN_LIMITS.ideas}
                    </div>
                    <div className="font-montserrat text-sm text-gray-600">Ideias Geradas</div>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="font-poppins text-xl text-black mb-1">
                      {completedArticles.length}/{FREE_PLAN_LIMITS.articles}
                    </div>
                    <div className="font-montserrat text-sm text-gray-600">Artigos Produzidos</div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <p className="font-montserrat text-sm text-gray-600">
                    Progresso Geral: <strong>{Math.round(overallProgress)}%</strong>
                  </p>
                  <Button
                    onClick={() => handleNavigate('store')}
                    variant="outline"
                    className="font-montserrat"
                  >
                    Fazer Upgrade
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Estatísticas Principais Clean */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {mainStats.map((stat, index) => {
          const Icon = stat.icon;
          const isAtLimit = !stat.isUnlimited && !stat.isMonetary && stat.value >= stat.maxValue;
          
          return (
            <Card 
              key={index} 
              className="border border-gray-200 hover:shadow-md transition-all cursor-pointer group"
              onClick={() => handleNavigate(stat.action)}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                    <Icon size={20} style={{ color: '#8B5FBF' }} />
                  </div>
                  <ArrowUpRight size={16} className="text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                
                <div className="space-y-2">
                  <div className="font-montserrat text-sm text-gray-600">
                    {stat.title}
                  </div>
                  
                  <div className="font-poppins text-2xl text-black">
                    {stat.isMonetary ? stat.value : `${stat.value}${stat.maxValue && stat.maxValue !== '∞' ? `/${stat.maxValue}` : ''}`}
                  </div>
                  
                  {stat.subValue && (
                    <div className="font-montserrat text-sm text-gray-600">
                      {stat.subValue}
                    </div>
                  )}
                  
                  <div className="font-montserrat text-xs text-gray-500">
                    {stat.description}
                  </div>

                  {/* Progress Bar para limites */}
                  {!stat.isMonetary && !stat.isUnlimited && stat.maxValue !== '∞' && (
                    <div className="pt-2">
                      <Progress 
                        value={Math.min(100, (stat.value / stat.maxValue) * 100)} 
                        className="h-1.5"
                      />
                      {isAtLimit && (
                        <div className="flex items-center gap-1 mt-1">
                          <AlertCircle size={12} className="text-red-500" />
                          <span className="font-montserrat text-xs text-red-600">Limite atingido</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Conteúdo Principal */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Ações Rápidas */}
        <Card className="border border-gray-200 xl:col-span-2">
          <CardHeader className="pb-4">
            <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
              <Zap size={20} style={{ color: '#8B5FBF' }} />
              Ações Rápidas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                
                return (
                  <Card 
                    key={index} 
                    className="border border-gray-200 hover:border-gray-300 hover:shadow-sm transition-all cursor-pointer group"
                    onClick={() => handleNavigate(action.action)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Icon size={20} style={{ color: '#8B5FBF' }} />
                        </div>
                        <ArrowUpRight size={16} className="text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      
                      <div>
                        <h4 className="font-montserrat font-medium text-black mb-1">
                          {action.title}
                        </h4>
                        <p className="font-montserrat text-sm text-gray-600 mb-2">
                          {action.description}
                        </p>
                        {action.badge && (
                          <Badge 
                            variant="outline" 
                            className="text-xs font-montserrat"
                          >
                            {action.badge}
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Atividade Recente com fundo colorido */}
        <Card className="border border-gray-200" style={{ backgroundColor: '#f8f5ff' }}>
          <CardHeader className="pb-4">
            <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
              <BarChart3 size={20} style={{ color: '#8B5FBF' }} />
              Atividade Recente
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentActivities.length > 0 ? recentActivities.map((activity) => {
                const Icon = activity.icon;
                
                return (
                  <div key={activity.id} className="flex items-center gap-3 p-3 bg-white/60 rounded-lg border border-purple-100">
                    <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center flex-shrink-0 border border-purple-200">
                      <Icon size={14} style={{ color: '#8B5FBF' }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-montserrat text-sm text-black truncate">
                        {activity.title}
                      </p>
                      <p className="font-montserrat text-xs text-gray-500">
                        {activity.time}
                      </p>
                    </div>
                  </div>
                );
              }) : (
                <div className="text-center py-8">
                  <BarChart3 size={32} className="mx-auto text-purple-300 mb-4" />
                  <p className="font-montserrat text-gray-600 mb-2">Nenhuma atividade ainda</p>
                  <p className="font-montserrat text-sm text-gray-500">Comece gerando algumas ideias!</p>
                  <Button
                    onClick={() => handleNavigate('ideas')}
                    variant="outline"
                    size="sm"
                    className="mt-3 font-montserrat"
                  >
                    Gerar Primeira Ideia
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dicas com fundo colorido */}
      <Card className="border border-gray-200" style={{ backgroundColor: '#f0fff4' }}>
        <CardHeader>
          <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
            <Star size={20} style={{ color: '#8B5FBF' }} />
            Dicas da BIA para Maximizar Resultados
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-4 bg-white/60 rounded-lg border border-green-100">
              <div className="flex items-center gap-2 mb-2">
                <Target size={16} style={{ color: '#8B5FBF' }} />
                <h4 className="font-montserrat font-medium text-black">
                  Otimize palavras-chave
                </h4>
              </div>
              <p className="font-montserrat text-sm text-gray-600">
                Use palavras-chave de cauda longa nos títulos para melhorar o SEO e atrair tráfego qualificado.
              </p>
            </div>
            
            <div className="p-4 bg-white/60 rounded-lg border border-green-100">
              <div className="flex items-center gap-2 mb-2">
                <Clock size={16} style={{ color: '#8B5FBF' }} />
                <h4 className="font-montserrat font-medium text-black">
                  Programe estrategicamente
                </h4>
              </div>
              <p className="font-montserrat text-sm text-gray-600">
                Publique nos horários de maior engajamento para maximizar o alcance dos seus artigos.
              </p>
            </div>
            
            <div className="p-4 bg-white/60 rounded-lg border border-green-100">
              <div className="flex items-center gap-2 mb-2">
                <Star size={16} style={{ color: '#8B5FBF' }} />
                <h4 className="font-montserrat font-medium text-black">
                  Diversifique nichos
                </h4>
              </div>
              <p className="font-montserrat text-sm text-gray-600">
                Explore diferentes ângulos do seu nicho para criar conteúdo variado e atrair audiências diversas.
              </p>
            </div>
            
            <div className="p-4 bg-white/60 rounded-lg border border-green-100">
              <div className="flex items-center gap-2 mb-2">
                <BarChart3 size={16} style={{ color: '#8B5FBF' }} />
                <h4 className="font-montserrat font-medium text-black">
                  Monitore métricas
                </h4>
              </div>
              <p className="font-montserrat text-sm text-gray-600">
                Acompanhe o desempenho no Analytics para identificar os melhores tipos de conteúdo.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}