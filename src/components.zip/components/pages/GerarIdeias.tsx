import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Alert, AlertDescription } from '../ui/alert';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';
import { Label } from '../ui/label';
import { Lightbulb, CheckCircle, AlertCircle, Loader2, Zap, Monitor, RefreshCw, RotateCcw, User, Tag, FolderOpen, Megaphone, Image, Link, Type, Eye, ExternalLink, Edit3, ChevronRight, Plus } from '../icons';
import { useBia } from '../BiaContext';
import { FREE_PLAN_LIMITS, getPlanLimits, isFreePlan } from '../../utils/constants';
import { toast } from 'sonner';
import { wordpressService, WordPressCategory, WordPressAuthor, WordPressTag } from '../../services/wordpressService';
import { contentService, IdeaGenerationParams } from '../../services/contentService';
import { openaiService } from '../../services/openaiService';

interface GerarIdeiasProps {
  userData: any;
  onPageChange?: (page: string) => void;
  onUpdateUser?: (userData: any) => Promise<boolean>;
}

interface FormData {
  siteId: string;
  nicho: string;
  palavrasChave: string;
  quantidade: number;
  idioma: string;
  contexto: string;
  autor: string;
  categorias: string[];
  tags: string[];
  ctaTitulo: string;
  ctaDescricao: string;
  ctaBotao: string;
  ctaLink: string;
  ctaImagem: string;
  ctaPosicao: 'inicio' | 'meio' | 'final';
}

interface WordPressData {
  categories: WordPressCategory[];
  authors: WordPressAuthor[];
  tags: WordPressTag[];
}

export function GerarIdeias({ userData, onPageChange, onUpdateUser }: GerarIdeiasProps) {
  const { state, actions } = useBia();
  const [isGenerating, setIsGenerating] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    siteId: '',
    nicho: '',
    palavrasChave: '',
    quantidade: 5,
    idioma: 'Português',
    contexto: '',
    autor: 'none',
    categorias: [],
    tags: [],
    ctaTitulo: '',
    ctaDescricao: '',
    ctaBotao: '',
    ctaLink: '',
    ctaImagem: '',
    ctaPosicao: 'final'
  });

  const [wordpressData, setWordpressData] = useState<WordPressData>({
    categories: [],
    authors: [],
    tags: []
  });
  const [isLoadingWordPress, setIsLoadingWordPress] = useState(false);
  const [newTag, setNewTag] = useState('');
  const [apiDiagnostic, setApiDiagnostic] = useState<{
    checked: boolean;
    hasKey: boolean;
    isValid: boolean;
    error?: string;
    details?: string;
  }>({ checked: false, hasKey: false, isValid: false });
  
  // Usar ref para evitar recarregamentos desnecessários
  const loadingRef = useRef<string | null>(null);
  const lastLoadedSiteRef = useRef<string | null>(null);

  // Verificar limites do plano e obter dados corretos
  const limits = actions.checkFreePlanLimits();
  const isFree = actions.isFreePlan();
  const userPlan = userData?.plano || 'Free';
  const planLimits = getPlanLimits(userPlan);

  // Filtrar apenas sites ativos - memorizar para evitar recriação
  const activeSites = React.useMemo(() => 
    state.sites.filter(site => site.status === 'ativo'), 
    [state.sites]
  );

  // Filtrar ideias pendentes para exibir na seção "Produzir a partir de Ideias"
  const pendingIdeas = React.useMemo(() => 
    state.ideas.filter(idea => idea.status === 'ativa'),
    [state.ideas]
  );

  // Estatísticas - corrigir lógica para dev/admin
  const ideasUsed = state.ideas.length;
  const isDevOrAdmin = userData?.email === 'dev@bia.com' || userData?.email === 'admin@bia.com';
  const hasUnlimitedIdeas = isDevOrAdmin || !isFree;
  const ideasRemaining = hasUnlimitedIdeas ? 'Ilimitado' : Math.max(0, planLimits.ideas - ideasUsed);
  const progressValue = hasUnlimitedIdeas ? 0 : (ideasUsed / planLimits.ideas) * 100;

  // Verificar se tem dados suficientes para mostrar preview do CTA
  const hasCtaContent = formData.ctaTitulo || formData.ctaDescricao || formData.ctaBotao || formData.ctaLink;

  // Verificar se o formulário está válido para permitir geração
  const isFormValid = formData.siteId && formData.nicho.trim() && formData.palavrasChave.trim() && formData.quantidade >= 1;

  // Sincronizar dados WordPress na inicialização e verificar OpenAI
  useEffect(() => {
    const initializeServices = async () => {
      try {
        // Sincronizar WordPress
        await wordpressService.syncFromBiaContext();
        
        // Verificar status da API OpenAI
        console.log('🔬 Verificando status da chave OpenAI...');
        const diagnostic = await openaiService.diagnosticSystem();
        
        setApiDiagnostic({
          checked: true,
          hasKey: diagnostic.hasApiKey,
          isValid: diagnostic.apiKeyValid,
          error: diagnostic.error,
          details: diagnostic.details
        });
        
        if (diagnostic.hasApiKey && diagnostic.apiKeyValid) {
          console.log('✅ Sistema OpenAI funcionando corretamente');
        } else {
          console.warn('⚠️ Problema detectado no sistema OpenAI:', {
            hasKey: diagnostic.hasApiKey,
            isValid: diagnostic.apiKeyValid,
            details: diagnostic.details
          });
        }
      } catch (error) {
        console.warn('Erro na inicialização dos serviços:', error);
        setApiDiagnostic({
          checked: true,
          hasKey: false,
          isValid: false,
          error: 'Erro na verificação',
          details: 'Não foi possível verificar o status da API'
        });
      }
    };

    initializeServices();
  }, []);

  // Função para testar a API OpenAI
  const handleTestApiKey = async () => {
    console.log('🧪 Testando chave OpenAI manualmente...');
    
    try {
      const testResult = await openaiService.testApiKey();
      
      if (testResult.success) {
        toast.success('Chave OpenAI funcionando corretamente!');
        setApiDiagnostic(prev => ({
          ...prev,
          hasKey: true,
          isValid: true,
          details: testResult.details
        }));
      } else {
        toast.error(`Problema na chave OpenAI: ${testResult.error}`);
        setApiDiagnostic(prev => ({
          ...prev,
          hasKey: !!testResult.details,
          isValid: false,
          error: testResult.error,
          details: testResult.details
        }));
      }
    } catch (error) {
      console.error('❌ Erro ao testar chave:', error);
      toast.error('Erro ao testar a conexão com OpenAI');
    }
  };

  // Funções de WordPress permanecem as mesmas...
  const loadCachedWordPressData = useCallback((site: any) => {
    try {
      console.log('🔍 Tentando carregar dados WordPress do cache para site:', site.nome);
      
      const cachedSite = wordpressService.getSiteById(site.id.toString());
      
      if (cachedSite) {
        const hasRealData = (cachedSite.categories?.length || 0) > 0 || 
                           (cachedSite.authors?.length || 0) > 0 || 
                           (cachedSite.tags?.length || 0) > 0;
        
        if (hasRealData) {
          console.log('✅ Cache contém dados reais, usando cache');
          
          setWordpressData({
            categories: cachedSite.categories || [],
            authors: cachedSite.authors || [],
            tags: cachedSite.tags || []
          });
          
          setIsLoadingWordPress(false);
          return true;
        }
      }
    } catch (error) {
      console.warn('❌ Erro ao carregar dados do cache:', error);
    }
    
    return false;
  }, []);

  const loadWordPressData = useCallback(async (site: any) => {
    const siteKey = `${site.id}-${site.wordpressUrl}`;
    if (loadingRef.current === siteKey) {
      console.log('🔄 Carregamento já em andamento para este site, ignorando...');
      return;
    }

    loadingRef.current = siteKey;
    setIsLoadingWordPress(true);
    
    try {
      console.log('🔄 Carregando dados FRESCOS do WordPress para site:', site.nome);
      
      if (!site.wordpressUrl || !site.wordpressUsername || !site.wordpressPassword) {
        console.warn('⚠️ Site não tem dados WordPress completos');
        setWordpressData({
          categories: [{ id: 1, name: 'Sem categoria', slug: 'sem-categoria', parent: 0 }],
          authors: [{ id: 1, name: 'Admin', slug: 'admin', description: 'Administrador' }],
          tags: []
        });
        lastLoadedSiteRef.current = siteKey;
        return;
      }

      const success = await wordpressService.reloadSiteData(site.id);
      
      if (success) {
        const updatedSite = wordpressService.getSiteById(site.id.toString());
        
        if (updatedSite && (updatedSite.categories.length > 0 || updatedSite.authors.length > 0)) {
          console.log('✅ Dados WordPress FRESCOS recarregados com sucesso');
          
          setWordpressData({
            categories: updatedSite.categories,
            authors: updatedSite.authors,
            tags: updatedSite.tags
          });
          
          lastLoadedSiteRef.current = siteKey;
          return;
        }
      }
      
      setWordpressData({
        categories: [{ id: 1, name: 'Sem categoria', slug: 'sem-categoria', parent: 0 }],
        authors: [{ id: 1, name: 'Admin', slug: 'admin', description: 'Administrador' }],
        tags: []
      });
      
    } catch (error) {
      console.error('❌ Erro geral ao carregar dados do WordPress:', error);
      setWordpressData({
        categories: [{ id: 1, name: 'Sem categoria', slug: 'sem-categoria', parent: 0 }],
        authors: [{ id: 1, name: 'Admin', slug: 'admin', description: 'Administrador' }],
        tags: []
      });
    } finally {
      setIsLoadingWordPress(false);
      loadingRef.current = null;
    }
  }, []);

  // Carregar dados do WordPress quando um site for selecionado
  useEffect(() => {
    const loadSiteData = async () => {
      if (!formData.siteId) {
        setWordpressData({
          categories: [],
          authors: [],
          tags: []
        });
        setIsLoadingWordPress(false);
        lastLoadedSiteRef.current = null;
        return;
      }

      const site = activeSites.find(s => s.id.toString() === formData.siteId);
      if (!site) {
        console.warn('❌ Site não encontrado no BiaContext:', formData.siteId);
        return;
      }

      if (site.wordpressUrl && site.wordpressUsername && site.wordpressPassword) {
        const hasCachedData = loadCachedWordPressData(site);
        
        if (hasCachedData) {
          console.log('✅ Dados em cache encontrados e carregados');
          loadWordPressData(site);
        } else {
          console.log('📡 Sem dados válidos no cache, carregando dados frescos...');
          setIsLoadingWordPress(true);
          loadWordPressData(site);
        }
      } else {
        console.log('⚠️ Site sem dados WordPress completos');
        setWordpressData({
          categories: [],
          authors: [],
          tags: []
        });
        setIsLoadingWordPress(false);
        lastLoadedSiteRef.current = null;
      }
    };

    loadSiteData();
  }, [formData.siteId, loadCachedWordPressData, loadWordPressData]);

  const handleInputChange = (field: keyof FormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleQuantidadeChange = (value: string) => {
    const numericValue = value.replace(/[^0-9]/g, '');
    const quantidade = parseInt(numericValue) || 0;
    const validQuantidade = Math.min(Math.max(quantidade, 0), 99);
    
    setFormData(prev => ({ ...prev, quantidade: validQuantidade }));
  };

  const handleCategoryToggle = (categoryId: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      categorias: checked 
        ? [...prev.categorias, categoryId]
        : prev.categorias.filter(id => id !== categoryId)
    }));
  };

  const handleTagToggle = (tagSlug: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      tags: checked 
        ? [...prev.tags, tagSlug]
        : prev.tags.filter(slug => slug !== tagSlug)
    }));
  };

  const handleAddNewTag = () => {
    if (!newTag.trim()) {
      toast.error('Digite o nome da nova tag');
      return;
    }

    const tagSlug = newTag.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9\-]/g, '');
    
    if (wordpressData.tags.some(tag => tag.slug === tagSlug)) {
      toast.error('Esta tag já existe');
      return;
    }

    const newTagObject = {
      id: Date.now(),
      name: newTag.trim(),
      slug: tagSlug,
      count: 0
    };

    setWordpressData(prev => ({
      ...prev,
      tags: [...prev.tags, newTagObject]
    }));

    setFormData(prev => ({
      ...prev,
      tags: [...prev.tags, tagSlug]
    }));

    setNewTag('');
    toast.success(`Tag "${newTag.trim()}" adicionada e selecionada`);
  };

  const handleGenerate = async () => {
    // Verificar se o plano permite gerar ideias
    if (isFree && !isDevOrAdmin && ideasUsed >= planLimits.ideas) {
      toast.error(`Limite atingido! Seu plano permite apenas ${planLimits.ideas} ideias. Faça upgrade para gerar mais ideias.`);
      return;
    }

    if (!formData.siteId) {
      toast.error('Selecione um site para gerar ideias.');
      return;
    }

    if (!formData.nicho.trim() || !formData.palavrasChave.trim()) {
      toast.error('Preencha o nicho e as palavras-chave para gerar ideias.');
      return;
    }

    if (formData.quantidade < 1 || formData.quantidade > 99) {
      toast.error('A quantidade deve ser entre 1 e 99 ideias.');
      return;
    }

    // Verificar se a API está funcionando
    if (!apiDiagnostic.hasKey || !apiDiagnostic.isValid) {
      toast.error('Sistema de IA não disponível. Verifique a configuração da chave OpenAI.');
      return;
    }

    setIsGenerating(true);

    try {
      const selectedSite = activeSites.find(site => site.id.toString() === formData.siteId);
      const selectedAuthor = formData.autor && formData.autor !== 'none'
        ? wordpressData.authors.find(author => author.id.toString() === formData.autor)
        : null;
      
      const selectedCategories = formData.categorias.map(catId => 
        wordpressData.categories.find(cat => cat.id.toString() === catId)
      ).filter(Boolean);

      // Usar diretamente o openaiService
      console.log('🤖 Gerando ideias diretamente com OpenAI...');
      
      const result = await openaiService.generateIdeas({
        type: 'ideas',
        userId: parseInt(userData?.id) || Date.now(),
        prompt: '',
        parameters: {
          nicho: formData.nicho,
          palavrasChave: formData.palavrasChave,
          quantidade: formData.quantidade,
          idioma: formData.idioma,
          contexto: formData.contexto,
          userPlan: userData?.plano || 'Free',
          userEmail: userData?.email
        }
      });

      if (!result.success) {
        console.error('❌ Falha na geração de ideias:', result.error);
        toast.error(result.error || 'Erro ao gerar ideias');
        return;
      }

      if (!result.ideas || result.ideas.length === 0) {
        toast.error('Nenhuma ideia foi gerada. Tente novamente.');
        return;
      }

      // Criar objetos de ideia para adicionar ao contexto
      const newIdeas = result.ideas.map((titulo, index) => {
        const tituloLimpo = titulo.replace(/^\d+\.\s*/, '').replace(/['"]/g, '').trim();
        
        return {
          titulo: tituloLimpo,
          descricao: `Ideia gerada para o nicho de ${formData.nicho}, focando nas palavras-chave: ${formData.palavrasChave}. Site: ${selectedSite?.nome}. ${selectedAuthor ? `Autor: ${selectedAuthor.name}. ` : ''}${selectedCategories.length > 0 ? `Categorias: ${selectedCategories.map(c => c?.name).join(', ')}. ` : ''}${formData.contexto ? `Contexto adicional: ${formData.contexto}` : ''}`,
          categoria: selectedCategories.length > 0 ? selectedCategories[0]?.name || formData.nicho : formData.nicho,
          tags: [
            ...formData.palavrasChave.split(',').map(tag => tag.trim()),
            ...formData.tags.map(tagSlug => {
              const tag = wordpressData.tags.find(t => t.slug === tagSlug);
              return tag ? tag.name : tagSlug;
            })
          ],
          siteId: parseInt(formData.siteId),
          status: 'ativa' as const,
          wordpressData: {
            autor: selectedAuthor?.id || null,
            categorias: formData.categorias.map(id => parseInt(id)),
            tags: formData.tags,
          },
          cta: formData.ctaTitulo || formData.ctaDescricao || formData.ctaBotao ? {
            titulo: formData.ctaTitulo,
            descricao: formData.ctaDescricao,
            botao: formData.ctaBotao,
            link: formData.ctaLink,
            imagem: formData.ctaImagem,
            posicao: formData.ctaPosicao
          } : null,
          generationParams: {
            nicho: formData.nicho,
            palavrasChave: formData.palavrasChave,
            idioma: formData.idioma,
            contexto: formData.contexto
          }
        };
      });

      const success = actions.addIdeas(newIdeas);
      
      if (success) {
        toast.success(`${newIdeas.length} ideia(s) gerada(s) com sucesso usando IA para ${selectedSite?.nome}!`);
        
        // Reset form on success
        setFormData({
          siteId: '',
          nicho: '',
          palavrasChave: '',
          quantidade: 5,
          idioma: 'Português',
          contexto: '',
          autor: 'none',
          categorias: [],
          tags: [],
          ctaTitulo: '',
          ctaDescricao: '',
          ctaBotao: '',
          ctaLink: '',
          ctaImagem: '',
          ctaPosicao: 'final'
        });
        setWordpressData({
          categories: [],
          authors: [],
          tags: []
        });
        lastLoadedSiteRef.current = null;
      } else {
        toast.error('Erro ao salvar as ideias. Verifique se não atingiu o limite do seu plano.');
      }

    } catch (error) {
      console.error('Erro ao gerar ideias:', error);
      toast.error('Erro temporário na geração de ideias. Tente novamente em alguns instantes.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGoToArticles = () => {
    if (onPageChange) {
      onPageChange('articles');
    }
  };

  const renderCtaPreview = () => {
    if (!hasCtaContent) return null;

    const ctaComponent = (
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-dashed border-purple-300 rounded-lg p-6 text-center">
        <div className="max-w-md mx-auto">
          {formData.ctaImagem && (
            <div className="mb-4">
              <img 
                src={formData.ctaImagem} 
                alt="CTA" 
                className="w-full max-w-sm h-32 object-cover rounded-lg mx-auto"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            </div>
          )}
          
          {formData.ctaTitulo && (
            <h3 className="font-poppins text-xl text-purple-800 mb-3">
              {formData.ctaTitulo}
            </h3>
          )}
          
          {formData.ctaDescricao && (
            <p className="font-montserrat text-gray-700 mb-4">
              {formData.ctaDescricao}
            </p>
          )}
          
          {formData.ctaBotao && (
            <Button 
              className="font-montserrat text-white px-6 py-2"
              style={{ backgroundColor: '#8B5FBF' }}
              disabled
            >
              {formData.ctaBotao}
              {formData.ctaLink && <ExternalLink className="ml-2 h-4 w-4" />}
            </Button>
          )}
          
          {formData.ctaLink && (
            <div className="mt-2">
              <span className="font-montserrat text-xs text-gray-500">
                Link: {formData.ctaLink}
              </span>
            </div>
          )}
        </div>
      </div>
    );

    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="font-poppins flex items-center">
            <Eye className="mr-2 h-5 w-5 text-purple-600" />
            Preview do CTA (Aparecerá no {formData.ctaPosicao} do artigo)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {ctaComponent}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-poppins text-2xl text-black mb-2">Gerar Ideias</h1>
        <p className="font-montserrat text-gray-600">Use IA para criar ideias de conteúdo otimizadas para seu nicho</p>
      </div>

      {/* Status da API OpenAI */}
      {apiDiagnostic.checked && (!apiDiagnostic.hasKey || !apiDiagnostic.isValid) && (
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="font-montserrat">
            <div className="flex items-center justify-between">
              <div>
                <strong>Sistema de IA indisponível:</strong> {
                  !apiDiagnostic.hasKey 
                    ? 'A chave OpenAI não está configurada no sistema.'
                    : 'A chave OpenAI configurada é inválida.'
                } {apiDiagnostic.details && (
                  <span className="text-sm block mt-1 text-red-700">
                    Detalhes: {apiDiagnostic.details}
                  </span>
                )}
              </div>
              <Button
                onClick={handleTestApiKey}
                size="sm"
                variant="outline"
                className="ml-4 text-red-600 border-red-300 hover:bg-red-100"
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Testar
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Status do usuário */}
      <Card className="border border-gray-200">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div>
                <p className="font-montserrat text-sm text-black">
                  <strong>Plano {userData?.plano || 'Free'}:</strong> {ideasRemaining} ideias restantes
                </p>
                <p className="font-montserrat text-xs text-gray-600 mt-1">
                  {ideasUsed} de {isFree ? planLimits.ideas : '∞'} ideias utilizadas
                </p>
              </div>
              
              {/* Indicador de status da API */}
              {apiDiagnostic.checked && (
                <div 
                  className={`w-3 h-3 rounded-full ${
                    apiDiagnostic.hasKey && apiDiagnostic.isValid 
                      ? 'bg-green-500' 
                      : 'bg-red-500'
                  }`} 
                  title={
                    apiDiagnostic.hasKey && apiDiagnostic.isValid 
                      ? 'Sistema de IA funcionando' 
                      : 'Sistema de IA indisponível'
                  } 
                />
              )}
            </div>
            
            {isFree && (
              <div className="w-full sm:w-48">
                <Progress value={progressValue} className="h-2" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Alerta de limite */}
      {!limits.ideas && isFree && !isDevOrAdmin && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertCircle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-700 font-montserrat">
            <strong>Limite atingido!</strong> Você utilizou todas as {planLimits.ideas} ideias do plano gratuito.
            Faça upgrade para gerar mais ideias.
          </AlertDescription>
        </Alert>
      )}

      {/* Formulário de geração */}
      <Card>
        <CardHeader>
          <CardTitle className="font-poppins flex items-center">
            <Lightbulb className="mr-2 h-5 w-5 text-purple-600" />
            Gerar Novas Ideias
            {apiDiagnostic.checked && (
              <div className={`w-2 h-2 rounded-full ml-2 ${
                apiDiagnostic.hasKey && apiDiagnostic.isValid 
                  ? 'bg-green-500' 
                  : 'bg-red-500'
              }`} />
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Seleção do Site */}
          <div className="space-y-2">
            <Label className="font-montserrat">Site</Label>
            <Select value={formData.siteId} onValueChange={(value) => handleInputChange('siteId', value)}>
              <SelectTrigger className="font-montserrat">
                <SelectValue placeholder="Selecione um site ativo" />
              </SelectTrigger>
              <SelectContent>
                {activeSites.length === 0 ? (
                  <SelectItem value="none" disabled>
                    Nenhum site ativo encontrado
                  </SelectItem>
                ) : (
                  activeSites.map((site) => (
                    <SelectItem key={site.id} value={site.id.toString()}>
                      <div className="flex items-center space-x-2">
                        <span className="font-montserrat">{site.nome}</span>
                        <Badge variant="outline" className="text-xs">
                          {site.categoria}
                        </Badge>
                      </div>
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Dados básicos */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="font-montserrat">Nicho</Label>
              <Input
                value={formData.nicho}
                onChange={(e) => handleInputChange('nicho', e.target.value)}
                placeholder="Ex: Marketing Digital, Culinária, Tecnologia"
                className="font-montserrat"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-montserrat">Palavras-chave</Label>
              <Input
                value={formData.palavrasChave}
                onChange={(e) => handleInputChange('palavrasChave', e.target.value)}
                placeholder="Ex: SEO, redes sociais, estratégias"
                className="font-montserrat"
              />
            </div>
          </div>

          {/* Configurações de geração */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="font-montserrat">Quantidade de ideias (1-99)</Label>
              <Input
                type="text"
                value={formData.quantidade.toString()}
                onChange={(e) => handleQuantidadeChange(e.target.value)}
                placeholder="Digite um número de 1 a 99"
                className="font-montserrat"
                min="1"
                max="99"
              />
              <p className="text-xs text-gray-500 font-montserrat">
                Digite um número entre 1 e 99
              </p>
            </div>

            <div className="space-y-2">
              <Label className="font-montserrat">Idioma</Label>
              <Select value={formData.idioma} onValueChange={(value) => handleInputChange('idioma', value)}>
                <SelectTrigger className="font-montserrat">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Português">Português</SelectItem>
                  <SelectItem value="Inglês">Inglês</SelectItem>
                  <SelectItem value="Espanhol">Espanhol</SelectItem>
                  <SelectItem value="Francês">Francês</SelectItem>
                  <SelectItem value="Italiano">Italiano</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Contexto adicional */}
          <div className="space-y-2">
            <Label className="font-montserrat">Contexto adicional (opcional)</Label>
            <Textarea
              value={formData.contexto}
              onChange={(e) => handleInputChange('contexto', e.target.value)}
              placeholder="Forneça informações adicionais sobre o público-alvo, tom desejado, objetivos específicos..."
              className="font-montserrat min-h-[80px]"
            />
          </div>

          {/* Dados WordPress */}
          {formData.siteId && (
            <div className="border-t pt-6">
              <h3 className="font-poppins text-lg mb-4 flex items-center">
                <Monitor className="mr-2 h-5 w-5 text-purple-600" />
                Configurações WordPress
                {isLoadingWordPress && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
              </h3>

              {/* Autor */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="space-y-2">
                  <Label className="font-montserrat flex items-center">
                    <User className="mr-1 h-4 w-4" />
                    Autor
                  </Label>
                  <Select value={formData.autor} onValueChange={(value) => handleInputChange('autor', value)} disabled={isLoadingWordPress}>
                    <SelectTrigger className="font-montserrat">
                      <SelectValue placeholder="Selecione um autor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Nenhum autor específico</SelectItem>
                      {wordpressData.authors.map((author) => (
                        <SelectItem key={author.id} value={author.id.toString()}>
                          {author.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Categorias */}
              {wordpressData.categories.length > 0 && (
                <div className="space-y-2 mb-4">
                  <Label className="font-montserrat flex items-center">
                    <FolderOpen className="mr-1 h-4 w-4" />
                    Categorias WordPress
                  </Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-32 overflow-y-auto border rounded-lg p-3 bg-gray-50">
                    {wordpressData.categories.map((category) => (
                      <div key={category.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category.id}`}
                          checked={formData.categorias.includes(category.id.toString())}
                          onCheckedChange={(checked) => handleCategoryToggle(category.id.toString(), checked as boolean)}
                          disabled={isLoadingWordPress}
                        />
                        <Label htmlFor={`category-${category.id}`} className="text-sm font-montserrat">
                          {category.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tags */}
              <div className="space-y-2">
                <Label className="font-montserrat flex items-center">
                  <Tag className="mr-1 h-4 w-4" />
                  Tags WordPress
                </Label>
                
                {/* Input para nova tag */}
                <div className="flex space-x-2 mb-3">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="Nova tag..."
                    className="font-montserrat"
                    disabled={isLoadingWordPress}
                  />
                  <Button
                    onClick={handleAddNewTag}
                    disabled={!newTag.trim() || isLoadingWordPress}
                    size="sm"
                    className="font-montserrat text-white"
                    style={{ backgroundColor: '#8B5FBF' }}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>

                {/* Lista de tags existentes */}
                {wordpressData.tags.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-32 overflow-y-auto border rounded-lg p-3 bg-gray-50">
                    {wordpressData.tags.map((tag) => (
                      <div key={tag.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`tag-${tag.id}`}
                          checked={formData.tags.includes(tag.slug)}
                          onCheckedChange={(checked) => handleTagToggle(tag.slug, checked as boolean)}
                          disabled={isLoadingWordPress}
                        />
                        <Label htmlFor={`tag-${tag.id}`} className="text-sm font-montserrat">
                          {tag.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* CTA (Call-to-Action) */}
          <div className="border-t pt-6">
            <h3 className="font-poppins text-lg mb-4 flex items-center">
              <Megaphone className="mr-2 h-5 w-5 text-purple-600" />
              CTA (Call-to-Action) - Opcional
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="font-montserrat flex items-center">
                  <Type className="mr-1 h-4 w-4" />
                  Título do CTA
                </Label>
                <Input
                  value={formData.ctaTitulo}
                  onChange={(e) => handleInputChange('ctaTitulo', e.target.value)}
                  placeholder="Ex: Quer saber mais sobre o assunto?"
                  className="font-montserrat"
                />
              </div>

              <div className="space-y-2">
                <Label className="font-montserrat flex items-center">
                  <Link className="mr-1 h-4 w-4" />
                  Texto do Botão
                </Label>
                <Input
                  value={formData.ctaBotao}
                  onChange={(e) => handleInputChange('ctaBotao', e.target.value)}
                  placeholder="Ex: Clique aqui"
                  className="font-montserrat"
                />
              </div>

              <div className="space-y-2">
                <Label className="font-montserrat flex items-center">
                  <ExternalLink className="mr-1 h-4 w-4" />
                  Link do CTA
                </Label>
                <Input
                  value={formData.ctaLink}
                  onChange={(e) => handleInputChange('ctaLink', e.target.value)}
                  placeholder="https://seusite.com/pagina"
                  className="font-montserrat"
                />
              </div>

              <div className="space-y-2">
                <Label className="font-montserrat">Posição do CTA</Label>
                <Select value={formData.ctaPosicao} onValueChange={(value: 'inicio' | 'meio' | 'final') => handleInputChange('ctaPosicao', value)}>
                  <SelectTrigger className="font-montserrat">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="inicio">Início do artigo</SelectItem>
                    <SelectItem value="meio">Meio do artigo</SelectItem>
                    <SelectItem value="final">Final do artigo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2 mt-4">
              <Label className="font-montserrat">Descrição do CTA</Label>
              <Textarea
                value={formData.ctaDescricao}
                onChange={(e) => handleInputChange('ctaDescricao', e.target.value)}
                placeholder="Descrição complementar do CTA..."
                className="font-montserrat"
              />
            </div>

            <div className="space-y-2 mt-4">
              <Label className="font-montserrat flex items-center">
                <Image className="mr-1 h-4 w-4" />
                URL da Imagem do CTA (opcional)
              </Label>
              <Input
                value={formData.ctaImagem}
                onChange={(e) => handleInputChange('ctaImagem', e.target.value)}
                placeholder="https://exemplo.com/imagem.jpg"
                className="font-montserrat"
              />
            </div>
          </div>

          {/* Preview do CTA */}
          {renderCtaPreview()}

          {/* Botão de gerar */}
          <div className="flex justify-center pt-6">
            <Button
              onClick={handleGenerate}
              disabled={
                isGenerating || 
                !isFormValid || 
                !apiDiagnostic.hasKey || 
                !apiDiagnostic.isValid ||
                (isFree && !isDevOrAdmin && ideasUsed >= planLimits.ideas)
              }
              className="font-montserrat px-8 py-3 text-white disabled:bg-gray-300"
              style={{ 
                backgroundColor: isFormValid && apiDiagnostic.hasKey && apiDiagnostic.isValid && !(isFree && !isDevOrAdmin && ideasUsed >= planLimits.ideas) 
                  ? '#8B5FBF' 
                  : '#9CA3AF' 
              }}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Gerando ideias...
                </>
              ) : (
                <>
                  <Zap className="mr-2 h-4 w-4" />
                  Gerar {formData.quantidade} Ideias
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Ideias pendentes */}
      {pendingIdeas.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="font-poppins flex items-center justify-between">
              <div className="flex items-center">
                <Edit3 className="mr-2 h-5 w-5 text-purple-600" />
                Ideias Pendentes para Produzir ({pendingIdeas.length})
              </div>
              <Button
                onClick={handleGoToArticles}
                size="sm"
                className="font-montserrat text-white"
                style={{ backgroundColor: '#8B5FBF' }}
              >
                Ir para Produzir Artigos
                <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {pendingIdeas.slice(0, 6).map((idea) => (
                <div key={idea.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-montserrat font-medium text-black mb-2">
                        {idea.titulo}
                      </h4>
                      <div className="flex flex-wrap gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          {idea.categoria}
                        </Badge>
                        {idea.tags?.slice(0, 3).map((tag, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {idea.tags && idea.tags.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{idea.tags.length - 3}
                          </Badge>
                        )}
                      </div>
                      <p className="font-montserrat text-sm text-gray-600 line-clamp-2">
                        {idea.descricao || 'Sem descrição adicional'}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2 ml-4">
                      <Badge variant="outline" className="text-xs">
                        {state.sites.find(s => s.id === idea.siteId)?.nome || 'Site não encontrado'}
                      </Badge>
                      {idea.status === 'produzido' && (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              {pendingIdeas.length > 6 && (
                <div className="text-center pt-4">
                  <Button
                    onClick={handleGoToArticles}
                    variant="outline"
                    className="font-montserrat"
                  >
                    Ver todas as {pendingIdeas.length} ideias
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}