import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Label } from '../ui/label';
import { 
  Calendar as CalendarIcon,
  ChevronLeft, 
  ChevronRight,
  Monitor,
  Filter,
  XCircle,
  CheckCircle,
  Clock,
  ExternalLink,
  Eye,
  AlertCircle,
  Tag
} from '../icons';
import { useBia } from '../BiaContext';

interface CalendarioProps {
  userData: any;
  onUpdateUser?: (updatedUserData: any) => Promise<boolean>;
}

export function Calendario({ userData, onUpdateUser }: CalendarioProps) {
  const { state } = useBia();
  
  // Estados principais
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedSiteId, setSelectedSiteId] = useState<'all' | number>('all');
  const [selectedDay, setSelectedDay] = useState<number | null>(null);

  // Mês e ano atual
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();

  // Nomes dos meses
  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  // Nomes dos dias da semana
  const dayNames = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

  // Obter nome do site por ID
  const getSiteName = useCallback((siteId: number) => {
    const site = state.sites.find(s => s.id === siteId);
    return site?.nome || `Site ${siteId}`;
  }, [state.sites]);

  // Obter lista de sites disponíveis
  const availableSites = useMemo(() => {
    const articleSiteIds = state.articles.map(a => a.siteId);
    const ideaSiteIds = state.ideas.map(i => i.siteId);
    const allSiteIds = [...articleSiteIds, ...ideaSiteIds];
    const uniqueSiteIds = [...new Set(allSiteIds)];
    const filteredSiteIds = uniqueSiteIds.filter(Boolean);
    
    return filteredSiteIds.map(siteId => ({
      id: siteId,
      name: getSiteName(siteId)
    })).sort((a, b) => a.name.localeCompare(b.name));
  }, [state.articles, state.ideas, getSiteName]);

  // Coletar todos os posts (artigos publicados e agendados)
  const allPosts = useMemo(() => {
    const posts: any[] = [];

    console.log('📅 Analisando artigos para calendário:', state.articles.length);

    // Artigos publicados - usando publishedAt e publishedUrl
    state.articles.forEach(article => {
      if (article.publishedUrl && (article.publishedAt || article.createdAt)) {
        const publishDate = article.publishedAt || article.createdAt;
        console.log('✅ Artigo publicado encontrado:', {
          title: article.titulo,
          publishedAt: article.publishedAt,
          publishedUrl: article.publishedUrl,
          date: publishDate
        });
        
        posts.push({
          id: `article-${article.id}`,
          title: article.titulo,
          content: article.conteudo,
          date: publishDate,
          type: 'published',
          status: 'Publicado',
          siteId: article.siteId,
          url: article.publishedUrl,
          articleId: article.id,
          article: article
        });
      }
    });

    // Artigos agendados - usando scheduledDate
    state.articles.forEach(article => {
      if (article.scheduledDate && !article.publishedUrl) {
        console.log('⏰ Artigo agendado encontrado:', {
          title: article.titulo,
          scheduledDate: article.scheduledDate,
          hasPublishedUrl: !!article.publishedUrl
        });
        
        posts.push({
          id: `scheduled-${article.id}`,
          title: article.titulo,
          content: article.conteudo,
          date: article.scheduledDate,
          type: 'scheduled',
          status: 'Agendado',
          siteId: article.siteId,
          scheduledDate: article.scheduledDate,
          articleId: article.id,
          article: article
        });
      }
    });

    console.log('📊 Posts encontrados para calendário:', {
      total: posts.length,
      published: posts.filter(p => p.type === 'published').length,
      scheduled: posts.filter(p => p.type === 'scheduled').length
    });

    return posts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [state.articles]);

  // Filtrar posts por site
  const filteredPosts = useMemo(() => {
    if (selectedSiteId === 'all') {
      return allPosts;
    }
    return allPosts.filter(post => post.siteId === selectedSiteId);
  }, [allPosts, selectedSiteId]);

  // Obter posts para um dia específico
  const getPostsForDay = useCallback((day: number) => {
    return filteredPosts.filter(post => {
      if (!post.date) return false;
      
      try {
        const postDate = new Date(post.date);
        // Verificar se a data é válida
        if (isNaN(postDate.getTime())) {
          console.warn('⚠️ Data inválida encontrada:', post.date);
          return false;
        }
        
        return postDate.getDate() === day && 
               postDate.getMonth() === currentMonth &&
               postDate.getFullYear() === currentYear;
      } catch (error) {
        console.warn('⚠️ Erro ao processar data:', post.date, error);
        return false;
      }
    });
  }, [filteredPosts, currentMonth, currentYear]);

  // Obter posts do dia selecionado
  const selectedDayPosts = useMemo(() => {
    return selectedDay ? getPostsForDay(selectedDay) : [];
  }, [selectedDay, getPostsForDay]);

  // Navegação do calendário
  const navigateMonth = useCallback((direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      setCurrentDate(new Date(currentYear, currentMonth - 1, 1));
    } else {
      setCurrentDate(new Date(currentYear, currentMonth + 1, 1));
    }
    setSelectedDay(null);
  }, [currentYear, currentMonth]);

  // Ir para hoje
  const goToToday = useCallback(() => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDay(today.getDate());
  }, []);

  // Função para aplicar filtros
  const handleFilterChange = useCallback((filterType: 'site', value: any) => {
    if (filterType === 'site') {
      setSelectedSiteId(value);
    }
    setSelectedDay(null);
  }, []);

  // Função para contar palavras
  const countWords = useCallback((htmlContent: string): number => {
    if (!htmlContent) return 0;
    const textContent = htmlContent.replace(/<[^>]*>/g, ' ').trim();
    const words = textContent.split(/\s+/).filter(word => word.length > 0);
    return words.length;
  }, []);

  // Função para visualizar artigo
  const openArticleInNewTab = useCallback((post: any) => {
    const article = post.article;
    const wordCount = countWords(article.conteudo);
    const articleWindow = window.open('', '_blank');
    if (articleWindow) {
      const htmlContent = `
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${article.titulo}</title>
          <style>
            body { font-family: 'Montserrat', Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: #fff; }
            .article-title { font-family: 'Poppins', Arial, sans-serif; font-size: 2rem; margin-bottom: 20px; color: #8B5FBF; line-height: 1.3; }
            .article-meta { color: #666; margin-bottom: 20px; font-size: 0.9rem; border-bottom: 1px solid #eee; padding-bottom: 15px; }
            .article-content { line-height: 1.6; color: #333; }
            .article-content h1, .article-content h2 { color: #8B5FBF; margin-top: 30px; }
            .article-content h3 { color: #6B4C93; margin-top: 25px; }
            .article-image { width: 100%; max-width: 600px; margin: 20px 0; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
          </style>
        </head>
        <body>
          <h1 class="article-title">${article.titulo}</h1>
          <div class="article-meta">
            📅 ${post.type === 'published' ? 'Publicado' : 'Agendado para'} ${new Date(post.date).toLocaleString('pt-BR')} • 📊 ${wordCount} palavras • 🌐 ${getSiteName(post.siteId)}
          </div>
          ${article.imageUrl ? `<img src="${article.imageUrl}" alt="${article.titulo}" class="article-image" />` : ''}
          <div class="article-content">${article.conteudo || '<p>Conteúdo não disponível</p>'}</div>
        </body>
        </html>
      `;
      articleWindow.document.write(htmlContent);
      articleWindow.document.close();
    }
  }, [countWords, getSiteName]);

  // Renderizar o calendário
  const renderCalendar = () => {
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
    const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);
    const daysInMonth = lastDayOfMonth.getDate();
    const startDay = firstDayOfMonth.getDay();

    const calendarDays = [];
    const today = new Date();
    const isCurrentMonth = today.getMonth() === currentMonth && today.getFullYear() === currentYear;

    // Dias vazios do mês anterior
    for (let i = 0; i < startDay; i++) {
      calendarDays.push(
        <div key={`prev-${i}`} className="h-24 bg-gray-50 border border-gray-100 opacity-40">
        </div>
      );
    }

    // Dias do mês atual
    for (let day = 1; day <= daysInMonth; day++) {
      const dayPosts = getPostsForDay(day);
      const isToday = isCurrentMonth && today.getDate() === day;
      const isSelected = selectedDay === day;
      const isPast = new Date(currentYear, currentMonth, day) < new Date(today.getFullYear(), today.getMonth(), today.getDate());
      
      // Separar posts por tipo
      const publishedPosts = dayPosts.filter(p => p.type === 'published');
      const scheduledPosts = dayPosts.filter(p => p.type === 'scheduled');

      calendarDays.push(
        <div 
          key={day}
          onClick={() => setSelectedDay(day)}
          className={`
            h-24 border border-gray-200 p-2 cursor-pointer transition-all duration-200 overflow-hidden relative
            ${isToday 
              ? 'bg-[#8B5FBF]/10 border-[#8B5FBF] ring-2 ring-[#8B5FBF]/20' 
              : isSelected
                ? 'bg-blue-50 border-blue-300 ring-2 ring-blue-200'
                : isPast 
                  ? 'bg-gray-50/50 hover:bg-gray-100/50' 
                  : 'bg-white hover:bg-gray-50 hover:border-gray-300'
            }
            ${dayPosts.length > 0 ? 'border-l-4 border-l-[#8B5FBF]' : ''}
          `}
        >
          {/* Cabeçalho do dia */}
          <div className={`text-sm font-medium mb-1 flex items-center justify-between ${
            isToday 
              ? 'text-[#8B5FBF]' 
              : isSelected
                ? 'text-blue-800'
                : isPast 
                  ? 'text-gray-400' 
                  : 'text-gray-900'
          }`}>
            <span>{day}</span>
            {dayPosts.length > 0 && (
              <div className="flex items-center gap-1">
                {publishedPosts.length > 0 && (
                  <div className="w-2 h-2 rounded-full bg-green-500" title={`${publishedPosts.length} publicado(s)`}></div>
                )}
                {scheduledPosts.length > 0 && (
                  <div className="w-2 h-2 rounded-full bg-amber-500" title={`${scheduledPosts.length} agendado(s)`}></div>
                )}
              </div>
            )}
          </div>
          
          {/* Indicador "Hoje" */}
          {isToday && (
            <div className="text-xs text-[#8B5FBF] font-medium mb-1">Hoje</div>
          )}

          {/* Posts do dia */}
          <div className="space-y-1">
            {/* Mostrar até 2 posts */}
            {dayPosts.slice(0, 2).map(post => (
              <div 
                key={post.id} 
                className={`text-xs px-1.5 py-0.5 rounded truncate cursor-pointer transition-opacity hover:opacity-80 ${
                  post.type === 'published' 
                    ? 'bg-green-100 text-green-800 border border-green-200' 
                    : 'bg-amber-100 text-amber-800 border border-amber-200'
                }`}
                title={`${post.title} (${post.type === 'published' ? 'Publicado' : 'Agendado'})`}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDay(day);
                }}
              >
                {post.title}
              </div>
            ))}
            {/* Indicador de mais posts */}
            {dayPosts.length > 2 && (
              <div className="text-xs text-gray-500 px-1.5 font-medium">
                +{dayPosts.length - 2} mais
              </div>
            )}
          </div>

          {/* Contador de posts (canto inferior direito) */}
          {dayPosts.length > 0 && (
            <div className="absolute bottom-1 right-1 bg-[#8B5FBF] text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-medium">
              {dayPosts.length}
            </div>
          )}
        </div>
      );
    }

    return calendarDays;
  };

  // Estatísticas
  const stats = useMemo(() => {
    const published = filteredPosts.filter(p => p.type === 'published').length;
    const scheduled = filteredPosts.filter(p => p.type === 'scheduled').length;
    const total = filteredPosts.length;
    
    return { published, scheduled, total };
  }, [filteredPosts]);

  // Log para debugging
  useEffect(() => {
    console.log('📅 Calendário atualizado:', {
      posts: allPosts.length,
      filteredPosts: filteredPosts.length,
      selectedSite: selectedSiteId,
      currentMonth: `${monthNames[currentMonth]} ${currentYear}`,
      selectedDay: selectedDay
    });
  }, [allPosts.length, filteredPosts.length, selectedSiteId, currentMonth, currentYear, selectedDay, monthNames]);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="font-poppins text-2xl text-black mb-2">
          Calendário de Conteúdo
        </h1>
        <p className="font-montserrat text-gray-600">
          Visualize e gerencie todos os seus artigos publicados e agendados em uma visão macro mensal
        </p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border border-gray-200">
          <CardContent className="p-6 text-center">
            <div className="font-poppins text-2xl text-black mb-1">
              {stats.total}
            </div>
            <div className="font-montserrat text-sm text-gray-600">Total de Posts</div>
          </CardContent>
        </Card>
        <Card className="border border-gray-200">
          <CardContent className="p-6 text-center">
            <div className="font-poppins text-2xl text-green-600 mb-1">
              {stats.published}
            </div>
            <div className="font-montserrat text-sm text-gray-600">Publicados</div>
          </CardContent>
        </Card>
        <Card className="border border-gray-200">
          <CardContent className="p-6 text-center">
            <div className="font-poppins text-2xl text-amber-600 mb-1">
              {stats.scheduled}
            </div>
            <div className="font-montserrat text-sm text-gray-600">Agendados</div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <Card className="border border-gray-200">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between">
            {/* Month Navigation */}
            <div className="flex items-center gap-4">
              <Button
                onClick={() => navigateMonth('prev')}
                size="default"
                variant="outline"
                className="h-11 px-4"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="text-center min-w-48">
                <h2 className="font-poppins text-xl text-black">
                  {monthNames[currentMonth]} {currentYear}
                </h2>
              </div>
              
              <Button
                onClick={() => navigateMonth('next')}
                size="default"
                variant="outline"
                className="h-11 px-4"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>

              <Button
                onClick={goToToday}
                size="default"
                className="h-11 px-4 bg-purple-600 hover:bg-purple-700 text-white"
              >
                Hoje
              </Button>
            </div>

            {/* Filters */}
            <div className="flex items-center gap-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center">
                  <Filter size={16} className="text-gray-600" />
                </div>
                <Label className="font-montserrat font-medium text-black">Filtrar por Site</Label>
              </div>
              
              <Select value={selectedSiteId.toString()} onValueChange={(value) => handleFilterChange('site', value === 'all' ? 'all' : parseInt(value))}>
                <SelectTrigger className="w-48 h-11">
                  <SelectValue placeholder="Site" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Sites</SelectItem>
                  {availableSites.map(site => (
                    <SelectItem key={site.id} value={site.id.toString()}>
                      {site.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedSiteId !== 'all' && (
                <Button 
                  variant="outline" 
                  size="default"
                  onClick={() => handleFilterChange('site', 'all')}
                  className="h-11 px-4"
                >
                  <XCircle size={16} className="mr-2" />
                  Limpar
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Content */}
      <div>
        {filteredPosts.length === 0 ? (
          <Card className="border border-gray-200">
            <CardContent className="p-16 text-center">
              <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-6">
                <CalendarIcon size={24} className="text-gray-400" />
              </div>
              <h3 className="font-poppins text-xl font-medium text-gray-900 mb-3">
                {selectedSiteId === 'all' ? 'Nenhum conteúdo encontrado' : 'Nenhum conteúdo para este site'}
              </h3>
              <p className="font-montserrat text-gray-600 max-w-md mx-auto mb-6">
                {selectedSiteId === 'all' 
                  ? 'Você ainda não possui artigos publicados ou agendados. Comece criando seu primeiro conteúdo.'
                  : `O site "${availableSites.find(s => s.id === selectedSiteId)?.name}" ainda não possui conteúdo publicado ou agendado.`
                }
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button
                  onClick={() => window.location.hash = 'articles'}
                  className="bg-[#8B5FBF] hover:bg-[#6B4C93] text-white"
                >
                  Produzir Artigos
                </Button>
                {selectedSiteId !== 'all' && (
                  <Button
                    onClick={() => handleFilterChange('site', 'all')}
                    variant="outline"
                  >
                    Ver Todos os Sites
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            {/* Calendar */}
            <Card className="border border-gray-200">
              <CardContent className="p-0">
                {/* Calendar Header */}
                <div className="grid grid-cols-7 border-b border-gray-200">
                  {dayNames.map(day => (
                    <div key={day} className="h-12 flex items-center justify-center bg-gray-50 border-r border-gray-200 last:border-r-0">
                      <span className="font-poppins font-medium text-gray-700">{day}</span>
                    </div>
                  ))}
                </div>
                
                {/* Calendar Grid */}
                <div className="grid grid-cols-7">
                  {renderCalendar()}
                </div>
              </CardContent>
            </Card>

            {/* Selected Day Posts */}
            {selectedDay && (
              <Card className="border border-gray-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="font-poppins text-xl font-semibold text-gray-900">
                      Posts de {selectedDay} de {monthNames[currentMonth]}
                    </h3>
                    <div className="flex items-center gap-3">
                      <Badge variant="secondary" className="bg-[#8B5FBF]/10 text-[#8B5FBF]">
                        {selectedDayPosts.length} post(s)
                      </Badge>
                      <Button
                        onClick={() => setSelectedDay(null)}
                        size="sm"
                        variant="ghost"
                        className="text-gray-500 hover:text-gray-700"
                      >
                        <XCircle size={16} />
                      </Button>
                    </div>
                  </div>

                  {selectedDayPosts.length === 0 ? (
                    <div className="text-center py-8">
                      <CalendarIcon size={48} className="mx-auto text-gray-300 mb-4" />
                      <h4 className="font-poppins font-medium text-gray-700 mb-2">
                        Nenhum post neste dia
                      </h4>
                      <p className="font-montserrat text-gray-500">
                        Não há artigos publicados ou agendados para esta data.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {selectedDayPosts.map(post => (
                        <Card key={post.id} className="border border-gray-200 hover:border-gray-300 transition-colors">
                          <CardContent className="p-4">
                            <div className="flex items-start gap-4">
                              {/* Content */}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-3 mb-2">
                                  <div className="flex items-center text-sm text-gray-500">
                                    <Monitor size={14} className="mr-1" />
                                    {getSiteName(post.siteId)}
                                  </div>
                                  
                                  <Badge className={`text-xs ${
                                    post.type === 'published' 
                                      ? 'bg-green-50 text-green-700 border-green-200' 
                                      : 'bg-amber-50 text-amber-700 border-amber-200'
                                  }`}>
                                    {post.type === 'published' ? (
                                      <>
                                        <CheckCircle size={10} className="mr-1" />
                                        Publicado
                                      </>
                                    ) : (
                                      <>
                                        <Clock size={10} className="mr-1" />
                                        Agendado
                                      </>
                                    )}
                                  </Badge>
                                </div>

                                <h4 className="font-poppins font-medium text-gray-900 mb-2 line-clamp-2 leading-tight">
                                  {post.title}
                                </h4>

                                <div className="flex items-center gap-3 mb-3">
                                  <span className="text-sm text-gray-600">
                                    {post.type === 'published' ? 'Publicado em' : 'Agendado para'}: {' '}
                                    {new Date(post.date).toLocaleString('pt-BR')}
                                  </span>
                                </div>

                                <div className="text-sm text-gray-500">
                                  {countWords(post.content)} palavras
                                </div>
                              </div>

                              {/* Actions */}
                              <div className="flex items-center gap-2 flex-shrink-0">
                                <Button
                                  onClick={() => openArticleInNewTab(post)}
                                  size="default"
                                  className="h-10 px-4 bg-green-600 hover:bg-green-700 text-white shadow-sm"
                                >
                                  <Eye className="h-4 w-4 mr-2" />
                                  Visualizar
                                </Button>

                                {post.url && (
                                  <Button
                                    onClick={() => window.open(post.url, '_blank')}
                                    size="default"
                                    className="h-10 px-4 bg-[#8B5FBF] hover:bg-[#6B4C93] text-white shadow-sm"
                                  >
                                    <ExternalLink className="h-4 w-4 mr-2" />
                                    Ver Online
                                  </Button>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Legend */}
            <Card className="border border-gray-200">
              <CardContent className="p-6">
                <h3 className="font-poppins font-semibold text-gray-900 mb-4">Legenda</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-3 bg-green-100 border border-green-200 rounded"></div>
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    </div>
                    <span className="font-montserrat text-sm text-gray-600">Posts Publicados</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-3 bg-amber-100 border border-amber-200 rounded"></div>
                      <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                    </div>
                    <span className="font-montserrat text-sm text-gray-600">Posts Agendados</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 bg-[#8B5FBF]/10 border border-[#8B5FBF]/20 rounded"></div>
                    <span className="font-montserrat text-sm text-gray-600">Dia Atual</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-4 bg-[#8B5FBF] rounded-full"></div>
                    <span className="font-montserrat text-sm text-gray-600">Borda: Dias com Posts</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}