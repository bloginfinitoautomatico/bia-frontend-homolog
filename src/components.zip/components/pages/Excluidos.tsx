import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';
import { Trash2, XCircle, RotateCcw, Clock, CheckCircle, AlertCircle, Star, BarChart3 } from '../icons';
import { useBia } from '../BiaContext';
import { toast } from 'sonner';

interface ExcluidosProps {
  userData: any;
}

export function Excluidos({ userData }: ExcluidosProps) {
  const { state, actions } = useBia();
  const [sortBy, setSortBy] = useState<'date' | 'title'>('date');

  // Filtrar ideias excluídas
  const ideiasExcluidas = state.ideas.filter(idea => idea.status === 'excluido');

  const handleRestore = (ideaId: number) => {
    try {
      actions.updateIdea(ideaId, { 
        status: 'pendente', // Voltar para status padrão
        deletedDate: undefined
      });
      
      toast.success('Ideia restaurada com sucesso!');
    } catch (error) {
      console.error('Erro ao restaurar ideia:', error);
      toast.error('Erro ao restaurar ideia');
    }
  };

  const handlePermanentDelete = (ideaId: number) => {
    try {
      // Excluir permanentemente do estado
      actions.deleteIdea(ideaId);
      
      toast.success('Ideia excluída permanentemente!');
    } catch (error) {
      console.error('Erro ao excluir permanentemente ideia:', error);
      toast.error('Erro ao excluir permanentemente ideia');
    }
  };

  const getSortedIdeias = () => {
    const sorted = [...ideiasExcluidas];
    if (sortBy === 'date') {
      sorted.sort((a, b) => {
        const dateA = a.deletedDate ? new Date(a.deletedDate).getTime() : new Date(a.createdAt).getTime();
        const dateB = b.deletedDate ? new Date(b.deletedDate).getTime() : new Date(b.createdAt).getTime();
        return dateB - dateA;
      });
    } else {
      sorted.sort((a, b) => a.titulo.localeCompare(b.titulo));
    }
    return sorted;
  };

  const sortedIdeias = getSortedIdeias();

  return (
    <div className="space-y-8">
      {/* Header Clean */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div>
          <h1 className="font-poppins text-2xl text-black mb-2">
            Itens Excluídos
          </h1>
          <p className="font-montserrat text-gray-600">
            Gerencie ideias excluídas, restaure ou remova permanentemente quando necessário
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
            <SelectTrigger className="w-40 font-montserrat">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Data de Exclusão</SelectItem>
              <SelectItem value="title">Título</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Estatísticas com ícones roxos */}
      {sortedIdeias.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border border-gray-200 hover:shadow-md transition-all">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                  <Trash2 size={20} style={{ color: '#8B5FBF' }} />
                </div>
              </div>
              <div className="space-y-2">
                <div className="font-montserrat text-sm text-gray-600">
                  Total Excluídas
                </div>
                <div className="font-poppins text-2xl text-black">
                  {sortedIdeias.length}
                </div>
                <div className="font-montserrat text-xs text-gray-500">
                  Podem ser restauradas
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-gray-200 hover:shadow-md transition-all">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                  <Clock size={20} style={{ color: '#8B5FBF' }} />
                </div>
              </div>
              <div className="space-y-2">
                <div className="font-montserrat text-sm text-gray-600">
                  Não Produzidas
                </div>
                <div className="font-poppins text-2xl text-black">
                  {sortedIdeias.filter(i => !i.articleId).length}
                </div>
                <div className="font-montserrat text-xs text-gray-500">
                  Sem artigos gerados
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-gray-200 hover:shadow-md transition-all">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                  <CheckCircle size={20} style={{ color: '#8B5FBF' }} />
                </div>
              </div>
              <div className="space-y-2">
                <div className="font-montserrat text-sm text-gray-600">
                  Já Produzidas
                </div>
                <div className="font-poppins text-2xl text-black">
                  {sortedIdeias.filter(i => i.status === 'produzido' || i.articleId).length}
                </div>
                <div className="font-montserrat text-xs text-gray-500">
                  Com artigos gerados
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Card className="border border-gray-200">
        <CardHeader className="pb-4">
          <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
            <Trash2 size={20} style={{ color: '#8B5FBF' }} />
            <span>Ideias Excluídas ({sortedIdeias.length})</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {sortedIdeias.length > 0 ? (
            <div className="space-y-4">
              {sortedIdeias.map((idea) => (
                <div key={idea.id} className="flex flex-col lg:flex-row lg:items-start lg:justify-between p-6 border border-gray-200 rounded-lg hover:shadow-md transition-all gap-4">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                      <XCircle size={20} style={{ color: '#8B5FBF' }} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h3 className="font-poppins text-lg text-black mb-3">{idea.titulo}</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                        <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                          <span className="font-montserrat font-medium text-black block mb-1">Excluída em:</span>
                          <span className="font-montserrat text-sm text-gray-600">
                            {idea.deletedDate 
                              ? new Date(idea.deletedDate).toLocaleDateString('pt-BR')
                              : 'Data não disponível'
                            }
                          </span>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                          <span className="font-montserrat font-medium text-black block mb-1">Categoria:</span>
                          <span className="font-montserrat text-sm text-gray-600">{idea.categoria || 'Não informado'}</span>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                          <span className="font-montserrat font-medium text-black block mb-1">Site:</span>
                          <span className="font-montserrat text-sm text-gray-600">
                            {idea.siteId 
                              ? state.sites.find(s => s.id === idea.siteId)?.nome || 'Site não encontrado'
                              : 'Não vinculado'
                            }
                          </span>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                          <span className="font-montserrat font-medium text-black block mb-1">Criada em:</span>
                          <span className="font-montserrat text-sm text-gray-600">{new Date(idea.createdAt).toLocaleDateString('pt-BR')}</span>
                        </div>
                      </div>
                      {idea.tags && idea.tags.length > 0 && (
                        <div className="mt-3">
                          <span className="font-montserrat font-medium text-sm text-black block mb-2">Tags:</span>
                          <div className="flex flex-wrap gap-2">
                            {idea.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="border-purple-200 text-purple-700 bg-purple-50 text-xs font-montserrat">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex flex-row lg:flex-col gap-3 lg:ml-6">
                    <Badge variant="outline" className="border-red-200 text-red-700 bg-red-50 font-montserrat lg:text-center">
                      <XCircle className="mr-1" size={12} />
                      Excluída
                    </Badge>
                    <Button 
                      onClick={() => handleRestore(idea.id)}
                      variant="outline" 
                      size="sm" 
                      className="font-montserrat hover:bg-green-50 hover:border-green-300 flex-1 lg:flex-none"
                    >
                      <RotateCcw className="mr-1" size={14} />
                      Restaurar
                    </Button>
                    <Button 
                      onClick={() => {
                        if (confirm('Tem certeza que deseja excluir permanentemente esta ideia? Esta ação não pode ser desfeita.')) {
                          handlePermanentDelete(idea.id);
                        }
                      }}
                      variant="destructive" 
                      size="sm" 
                      className="font-montserrat flex-1 lg:flex-none"
                    >
                      <Trash2 className="mr-1" size={14} />
                      Excluir
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="flex items-center justify-center w-16 h-16 bg-purple-50 rounded-full mx-auto mb-6">
                <Trash2 size={32} style={{ color: '#8B5FBF' }} />
              </div>
              <h3 className="font-poppins text-xl text-black mb-2">Nenhuma ideia excluída</h3>
              <p className="font-montserrat text-gray-600 mb-4">
                As ideias excluídas aparecerão aqui e poderão ser restauradas.
              </p>
              <p className="font-montserrat text-sm text-gray-500">
                Para excluir ideias, vá para "Produzir Artigos", selecione as ideias e clique em "Excluir".
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Avisos importantes com fundo colorido */}
      <Card className="border border-gray-200" style={{ backgroundColor: '#fff7ed' }}>
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <AlertCircle size={20} style={{ color: '#8B5FBF' }} />
            </div>
            <div className="flex-1">
              <h4 className="font-poppins text-lg text-black mb-3 flex items-center gap-2">
                <span>⚠️ Atenção - Ideias Produzidas</span>
              </h4>
              <div className="space-y-3">
                <div className="p-4 bg-white/60 rounded-lg border border-orange-100">
                  <p className="font-montserrat text-sm text-gray-700">
                    Se você restaurar uma ideia que já foi produzida em artigo, o artigo correspondente continuará existindo normalmente na aba "Produzir Artigos".
                  </p>
                </div>
                <div className="p-4 bg-white/60 rounded-lg border border-orange-100">
                  <div className="flex items-center gap-2 mb-2">
                    <BarChart3 size={16} style={{ color: '#8B5FBF' }} />
                    <span className="font-montserrat font-medium text-black">Ao restaurar uma ideia produzida:</span>
                  </div>
                  <p className="font-montserrat text-sm text-gray-700">
                    Você terá tanto a ideia quanto o artigo gerado, permitindo produzir novos artigos da mesma ideia se desejar.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Dica para usuários com fundo colorido */}
      <Card className="border border-gray-200" style={{ backgroundColor: '#f8f5ff' }}>
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Star size={20} style={{ color: '#8B5FBF' }} />
            </div>
            <div className="flex-1">
              <h4 className="font-poppins text-lg text-black mb-4">Como funciona a exclusão de ideias?</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="p-3 bg-white/60 rounded-lg border border-purple-100">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#8B5FBF' }}></div>
                      <span className="font-montserrat text-sm text-gray-700">Ideias excluídas ficam aqui por segurança</span>
                    </div>
                  </div>
                  <div className="p-3 bg-white/60 rounded-lg border border-purple-100">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#8B5FBF' }}></div>
                      <span className="font-montserrat text-sm text-gray-700">Você pode restaurá-las a qualquer momento</span>
                    </div>
                  </div>
                  <div className="p-3 bg-white/60 rounded-lg border border-purple-100">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#8B5FBF' }}></div>
                      <span className="font-montserrat text-sm text-gray-700">Ou excluí-las permanentemente se não precisar mais</span>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="p-3 bg-white/60 rounded-lg border border-purple-100">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#8B5FBF' }}></div>
                      <span className="font-montserrat text-sm text-gray-700">Para excluir: vá em "Produzir Artigos" e selecione as ideias</span>
                    </div>
                  </div>
                  <div className="p-3 bg-white/60 rounded-lg border border-purple-100">
                    <div className="flex items-center gap-2 mb-1">
                      <CheckCircle size={12} style={{ color: '#8B5FBF' }} />
                      <span className="font-montserrat text-sm font-medium text-black">Restaurar ideia produzida:</span>
                    </div>
                    <span className="font-montserrat text-sm text-gray-700 ml-4">Mantém o artigo existente e permite gerar novos</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}