import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Alert, AlertDescription } from '../ui/alert';
import { Checkbox } from '../ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Calendar as CalendarComponent } from '../ui/calendar';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Loader2, 
  Calendar,
  Eye,
  Zap,
  Send,
  Trash2,
  Lightbulb,
  ChevronLeft,
  ChevronRight,
  Play,
  Globe,
  XCircle,
  Filter,
  Monitor,
  Tag,
  ExternalLink,
  MoreHorizontal,
  Search,
  RefreshCw,
  User,
  FolderOpen,
  Image
} from '../icons';
import { useBia } from '../BiaContext';
import { FREE_PLAN_LIMITS, getPlanLimits } from '../../utils/constants';
import { toast } from 'sonner';
import { contentService, ContentGenerationParams } from '../../services/contentService';
import { wordpressService } from '../../services/wordpressService';
import { openaiService } from '../../services/openaiService';

interface ProduzirArtigosProps {
  userData: any;
  onUpdateUser?: (updatedUserData: any) => Promise<boolean>;
}

export function ProduzirArtigos({ userData, onUpdateUser }: ProduzirArtigosProps) {
  const { state, actions } = useBia();
  
  // Estados de seleção - usando arrays para evitar problemas de referência
  const [selectedIdeaIds, setSelectedIdeaIds] = useState<number[]>([]);
  
  // Estado para diagnóstico da API OpenAI
  const [apiDiagnostic, setApiDiagnostic] = useState<{
    checked: boolean;
    hasKey: boolean;
    isValid: boolean;
    error?: string;
    details?: string;
  }>({ checked: false, hasKey: false, isValid: false });
  
  // Estados para operações individuais com progresso
  const [processingSingle, setProcessingSingle] = useState<{ [key: number]: boolean }>({});
  const [singleProgress, setSingleProgress] = useState<{ [key: number]: number }>({});
  const [publishingSingle, setPublishingSingle] = useState<{ [key: number]: boolean }>({});
  const [schedulingSingle, setSchedulingSingle] = useState<{ [key: number]: boolean }>({});
  const [deletingSingle, setDeletingSingle] = useState<{ [key: number]: boolean }>({});
  
  // Estados para operações em massa com progresso individual
  const [processingBatch, setProcessingBatch] = useState(false);
  const [publishingBatch, setPublishingBatch] = useState(false);
  const [deletingBatch, setDeletingBatch] = useState(false);
  const [batchProgress, setBatchProgress] = useState<{ [key: number]: number }>({});
  
  // Estados para agendamento
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [currentSchedulingArticle, setCurrentSchedulingArticle] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string>('08:00');

  // Estados para visualização
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [currentViewingArticle, setCurrentViewingArticle] = useState<any>(null);

  // Estados de paginação e filtros
  const [currentPage, setCurrentPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'produced'>('all');
  const [siteFilter, setSiteFilter] = useState<'all' | number>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const ITEMS_PER_PAGE = 15;

  // Cache WordPress
  const [wordpressSitesCache, setWordpressSitesCache] = useState<Map<string, boolean>>(new Map());

  // Sincronizar WordPress e verificar API OpenAI na inicialização
  useEffect(() => {
    const initializeServices = async () => {
      try {
        // Sincronizar WordPress
        console.log('🔄 Sincronizando WordPress na ProduzirArtigos...');
        await wordpressService.syncFromBiaContext();
        
        // Carregar cache de sites WordPress
        const wpSites = wordpressService.getSites();
        const cache = new Map<string, boolean>();
        wpSites.forEach(site => {
          cache.set(site.id, !!(site.url && site.username && site.applicationPassword));
        });
        setWordpressSitesCache(cache);
        
        console.log('✅ Sincronização WordPress concluída, cache carregado:', cache.size);
        
        // Verificar status da API OpenAI
        console.log('🔬 Verificando status da chave OpenAI...');
        const diagnostic = await openaiService.diagnosticSystem();
        
        setApiDiagnostic({
          checked: true,
          hasKey: diagnostic.hasApiKey,
          isValid: diagnostic.apiKeyValid,
          error: diagnostic.error,
          details: diagnostic.details
        });
        
        if (diagnostic.hasApiKey && diagnostic.apiKeyValid) {
          console.log('✅ Sistema OpenAI funcionando corretamente');
        } else {
          console.warn('⚠️ Problema detectado no sistema OpenAI:', {
            hasKey: diagnostic.hasApiKey,
            isValid: diagnostic.apiKeyValid,
            details: diagnostic.details
          });
        }
      } catch (error) {
        console.warn('⚠️ Erro na inicialização dos serviços:', error);
        setApiDiagnostic({
          checked: true,
          hasKey: false,
          isValid: false,
          error: 'Erro na verificação',
          details: 'Não foi possível verificar o status da API'
        });
      }
    };
    
    initializeServices();
  }, []);

  // Verificar limites do plano
  const limits = actions.checkFreePlanLimits();
  const isFreePlan = actions.isFreePlan();
  const userPlan = userData?.plano || 'Free';
  const planLimits = getPlanLimits(userPlan);
  const isDevOrAdmin = userData?.email === 'dev@bia.com' || userData?.email === 'admin@bia.com';

  // Obter nome do site por ID
  const getSiteName = useCallback((siteId: number) => {
    const site = state.sites.find(s => s.id === siteId);
    return site?.nome || `Site ${siteId}`;
  }, [state.sites]);

  // Obter lista de sites únicos das ideias
  const availableSites = useMemo(() => {
    const siteIds = [...new Set(state.ideas.map(idea => idea.siteId))];
    return siteIds.map(siteId => ({
      id: siteId,
      name: getSiteName(siteId)
    })).sort((a, b) => a.name.localeCompare(b.name));
  }, [state.ideas, getSiteName]);

  // Filtrar ideias disponíveis (excluir publicadas, agendadas e excluídas)
  const availableIdeas = useMemo(() => {
    let filteredIdeas = state.ideas.filter(idea => {
      // Excluir ideias excluídas
      if (idea.status === 'excluido') return false;
      
      // Verificar se tem artigo associado
      const article = state.articles.find(a => a.ideaId === idea.id);
      
      // Excluir se foi publicado ou agendado
      if (article && (article.publishedUrl || article.scheduledDate)) {
        return false;
      }
      
      return true;
    });

    // Aplicar filtro de busca
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filteredIdeas = filteredIdeas.filter(idea => 
        idea.titulo.toLowerCase().includes(query) ||
        idea.categoria.toLowerCase().includes(query) ||
        getSiteName(idea.siteId).toLowerCase().includes(query)
      );
    }

    // Aplicar filtro de site
    if (siteFilter !== 'all') {
      filteredIdeas = filteredIdeas.filter(idea => idea.siteId === siteFilter);
    }

    // Aplicar filtro de status
    if (statusFilter === 'pending') {
      filteredIdeas = filteredIdeas.filter(idea => idea.status === 'ativa');
    } else if (statusFilter === 'produced') {
      filteredIdeas = filteredIdeas.filter(idea => idea.status === 'produzido');
    }

    return filteredIdeas;
  }, [state.ideas, state.articles, statusFilter, siteFilter, searchQuery, getSiteName]);

  // Paginação
  const totalPages = Math.ceil(availableIdeas.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const currentPageIdeas = useMemo(() => {
    return availableIdeas.slice(startIndex, endIndex);
  }, [availableIdeas, startIndex, endIndex]);

  // Estatísticas
  const articlesUsed = useMemo(() => 
    state.articles.filter(a => a.status === 'Concluído').length, 
    [state.articles]
  );
  const articlesRemaining = isDevOrAdmin ? 'Ilimitado' : Math.max(0, planLimits.articles - articlesUsed);
  const progressValue = isDevOrAdmin ? 0 : (articlesUsed / planLimits.articles) * 100;

  // FUNÇÕES DE SELEÇÃO
  const handleSelectIdea = useCallback((ideaId: number, checked: boolean) => {
    console.log(`🔄 Seleção alterada - ID: ${ideaId}, Checked: ${checked}`);
    
    setSelectedIdeaIds(prev => {
      if (checked) {
        if (!prev.includes(ideaId)) {
          const newSelection = [...prev, ideaId];
          console.log('✅ Nova seleção:', newSelection);
          return newSelection;
        }
        return prev;
      } else {
        const newSelection = prev.filter(id => id !== ideaId);
        console.log('❌ Removido da seleção:', newSelection);
        return newSelection;
      }
    });
  }, []);

  const handleSelectAllIdeas = useCallback((checked: boolean) => {
    console.log(`🔄 Seleção em massa - Checked: ${checked}`);
    
    if (checked) {
      const currentPageIds = currentPageIdeas.map(idea => idea.id);
      setSelectedIdeaIds(currentPageIds);
      console.log('✅ Todas selecionadas:', currentPageIds);
    } else {
      setSelectedIdeaIds([]);
      console.log('❌ Todas desselecionadas');
    }
  }, [currentPageIdeas]);

  // Limpar seleção
  const handleClearSelection = useCallback(() => {
    setSelectedIdeaIds([]);
    setBatchProgress({});
    setSingleProgress({});
    console.log('🧹 Seleção limpa');
  }, []);

  // Verificar se todas as ideias da página atual estão selecionadas
  const allCurrentPageSelected = useMemo(() => {
    const currentPageIds = currentPageIdeas.map(idea => idea.id);
    return currentPageIds.length > 0 && currentPageIds.every(id => selectedIdeaIds.includes(id));
  }, [currentPageIdeas, selectedIdeaIds]);

  // Função para aplicar filtros e resetar página
  const handleFilterChange = useCallback((filterType: 'status' | 'site', value: any) => {
    setCurrentPage(1);
    setSelectedIdeaIds([]);
    setBatchProgress({});
    setSingleProgress({});
    
    if (filterType === 'status') {
      setStatusFilter(value);
    } else if (filterType === 'site') {
      setSiteFilter(value);
    }
  }, []);

  // FUNÇÃO PARA CONTAR PALAVRAS
  const countWords = useCallback((htmlContent: string): number => {
    if (!htmlContent) return 0;
    const textContent = htmlContent.replace(/<[^>]*>/g, ' ').trim();
    const words = textContent.split(/\s+/).filter(word => word.length > 0);
    return words.length;
  }, []);

  // Função para testar a API OpenAI
  const handleTestApiKey = async () => {
    console.log('🧪 Testando chave OpenAI manualmente...');
    
    try {
      const testResult = await openaiService.testApiKey();
      
      if (testResult.success) {
        toast.success('Chave OpenAI funcionando corretamente!');
        setApiDiagnostic(prev => ({
          ...prev,
          hasKey: true,
          isValid: true,
          details: testResult.details
        }));
      } else {
        toast.error(`Problema na chave OpenAI: ${testResult.error}`);
        setApiDiagnostic(prev => ({
          ...prev,
          hasKey: !!testResult.details,
          isValid: false,
          error: testResult.error,
          details: testResult.details
        }));
      }
    } catch (error) {
      console.error('❌ Erro ao testar chave:', error);
      toast.error('Erro ao testar a conexão com OpenAI');
    }
  };

  // FUNÇÃO PARA VISUALIZAR ARTIGO
  const handleViewArticle = useCallback((ideaId: number) => {
    console.log(`👁️ Visualizando artigo para ideia ${ideaId}`);
    
    const idea = state.ideas.find(i => i.id === ideaId);
    const article = state.articles.find(a => a.ideaId === ideaId);
    
    if (!idea || !article) {
      toast.error('Artigo não encontrado');
      return;
    }

    setCurrentViewingArticle({
      idea,
      article,
      siteName: getSiteName(idea.siteId),
      wordCount: countWords(article.conteudo)
    });
    setViewDialogOpen(true);
  }, [state.ideas, state.articles, getSiteName, countWords]);

  // FUNÇÃO DE PRODUÇÃO INDIVIDUAL COM PROGRESSO VISUAL
  const handleProduceFromIdea = useCallback(async (ideaId: number) => {
    console.log(`🚀 Iniciando produção individual para ideia ${ideaId}`);
    
    if (processingSingle[ideaId]) {
      console.log(`⚠️ Ideia ${ideaId} já está sendo processada - ignorando`);
      return;
    }

    // Verificar se a API está funcionando
    if (!apiDiagnostic.hasKey || !apiDiagnostic.isValid) {
      toast.error('Sistema de IA não disponível. Verifique a configuração da chave OpenAI.');
      return;
    }

    if (!limits.articles && !isDevOrAdmin) {
      toast.error(`Limite atingido! Seu plano permite apenas ${planLimits.articles} artigos.`);
      return;
    }

    const idea = state.ideas.find(i => i.id === ideaId);
    if (!idea) {
      toast.error('Ideia não encontrada');
      return;
    }

    // Marcar como processando e inicializar progresso
    setProcessingSingle(prev => ({ ...prev, [ideaId]: true }));
    setSingleProgress(prev => ({ ...prev, [ideaId]: 0 }));
    setSelectedIdeaIds(prev => prev.filter(id => id !== ideaId));

    try {
      console.log(`📝 Preparando parâmetros para geração do artigo ${ideaId}`);
      
      // Progresso: Iniciando (10%)
      setSingleProgress(prev => ({ ...prev, [ideaId]: 10 }));
      
      // Progresso: Preparando parâmetros (25%)
      setSingleProgress(prev => ({ ...prev, [ideaId]: 25 }));

      console.log(`🔄 Gerando artigo ${ideaId} diretamente com OpenAI...`);
      
      // Progresso: Gerando conteúdo (50%)
      setSingleProgress(prev => ({ ...prev, [ideaId]: 50 }));
      
      // Usar diretamente o openaiService com parâmetros aprimorados para SEO
      const result = await openaiService.generateContent({
        type: 'content',
        userId: parseInt(userData?.id) || Date.now(),
        prompt: idea.titulo,
        parameters: {
          nicho: idea.generationParams?.nicho || idea.categoria || 'Geral',
          palavrasChave: idea.generationParams?.palavrasChave || idea.tags?.join(', ') || '',
          idioma: idea.generationParams?.idioma || 'Português',
          contexto: idea.generationParams?.contexto,
          userPlan: userData?.plano || 'Free',
          userEmail: userData?.email,
          // Parâmetros adicionais para garantir formatação SEO
          enforceHtmlFormatting: true,
          seoOptimized: true,
          includeStructuredData: true
        }
      });

      // Progresso: Processando resultado (75%)
      setSingleProgress(prev => ({ ...prev, [ideaId]: 75 }));

      if (!result.success) {
        console.error(`❌ Erro na geração do artigo ${ideaId}: ${result.error}`);
        setSingleProgress(prev => ({ ...prev, [ideaId]: -1 }));
        
        if (result.error?.includes('Chave API OpenAI não configurada') || 
            result.error?.includes('painel administrativo')) {
          toast.error('Sistema temporariamente indisponível para produção de conteúdo. Tente novamente em alguns minutos.');
        } else {
          toast.error(`Erro ao produzir artigo: ${result.error}`);
        }
        return;
      }

      console.log(`✅ Artigo ${ideaId} gerado com sucesso, salvando...`);
      
      // Garantir formatação HTML adequada antes de salvar
      let processedContent = result.content || '';
      
      // Aplicar formatação HTML aprimorada se necessário
      if (!processedContent.includes('<h1>') && !processedContent.includes('<h2>')) {
        console.log('🔧 Aplicando formatação HTML aprimorada...');
        processedContent = applyAdvancedHtmlFormatting(processedContent, idea.titulo);
      }
      
      const articleData = {
        titulo: idea.titulo,
        conteudo: processedContent,
        status: 'Concluído' as const,
        siteId: idea.siteId,
        ideaId: ideaId,
        imageUrl: result.imageUrl,
        wordpressData: idea.wordpressData,
        generationParams: idea.generationParams
      };

      const success = actions.addArticle(articleData);
      
      if (success) {
        actions.updateIdea(ideaId, { 
          status: 'produzido',
          articleId: Date.now()
        });
        
        // Progresso: Concluído (100%)
        setSingleProgress(prev => ({ ...prev, [ideaId]: 100 }));
        
        console.log(`✅ Artigo ${ideaId} salvo com sucesso`);
        toast.success(result.imageUrl 
          ? 'Artigo produzido com sucesso! (Conteúdo + Imagem gerada)'
          : 'Artigo produzido com sucesso!'
        );

        // Limpar progresso após 2 segundos
        setTimeout(() => {
          setSingleProgress(prev => {
            const newState = { ...prev };
            delete newState[ideaId];
            return newState;
          });
        }, 2000);
      } else {
        setSingleProgress(prev => ({ ...prev, [ideaId]: -1 }));
        toast.error('Erro ao salvar o artigo');
      }

    } catch (error) {
      console.error(`❌ Erro ao produzir artigo ${ideaId}:`, error);
      setSingleProgress(prev => ({ ...prev, [ideaId]: -1 }));
      toast.error('Erro inesperado ao produzir artigo. Tente novamente.');
    } finally {
      setProcessingSingle(prev => {
        const newState = { ...prev };
        delete newState[ideaId];
        console.log(`🔄 Processamento finalizado para ideia ${ideaId}`);
        return newState;
      });
    }
  }, [apiDiagnostic, limits.articles, planLimits.articles, state.ideas, actions, processingSingle, userData, isDevOrAdmin]);

  // Função para aplicar formatação HTML avançada com SEO
  const applyAdvancedHtmlFormatting = useCallback((content: string, title: string): string => {
    console.log('🎯 Aplicando formatação HTML avançada com otimização SEO...');
    
    if (!content || content.trim().length === 0) {
      return content;
    }

    // Verificar se já tem formatação HTML adequada
    const hasHtmlStructure = content.includes('<h1>') || content.includes('<h2>') || content.includes('<p>');
    
    if (hasHtmlStructure) {
      console.log('✅ Conteúdo já possui estrutura HTML adequada');
      return content;
    }

    // Dividir conteúdo em linhas
    const lines = content.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    const htmlLines: string[] = [];
    
    let inList = false;
    let inTable = false;
    let hasMainTitle = false;

    for (let i = 0; i < lines.length; i++) {
      let line = lines[i];
      
      if (!line) continue;

      // Detectar e formatar títulos
      if (line.match(/^#{1,3}\s+/)) {
        // Markdown headers
        if (inList) {
          htmlLines.push('</ul>');
          inList = false;
        }
        if (inTable) {
          htmlLines.push('</table>');
          inTable = false;
        }

        const level = (line.match(/^#+/) || [''])[0].length;
        const text = line.replace(/^#+\s*/, '');
        
        if (level === 1 && !hasMainTitle) {
          htmlLines.push(`<h1>${text}</h1>`);
          hasMainTitle = true;
        } else if (level <= 2) {
          htmlLines.push(`<h2>${text}</h2>`);
        } else {
          htmlLines.push(`<h3>${text}</h3>`);
        }
      }
      // Detectar títulos por maiúsculas ou palavras-chave
      else if (line.length < 100 && (
        line === line.toUpperCase() || 
        line.includes('INTRODUÇÃO') || 
        line.includes('CONCLUSÃO') ||
        line.includes('BENEFÍCIOS') ||
        line.includes('VANTAGENS') ||
        line.includes('COMO') ||
        line.includes('POR QUE') ||
        line.includes('DICAS') ||
        line.includes('PASSOS')
      )) {
        if (inList) {
          htmlLines.push('</ul>');
          inList = false;
        }
        if (inTable) {
          htmlLines.push('</table>');
          inTable = false;
        }
        
        if (!hasMainTitle && i === 0) {
          htmlLines.push(`<h1>${line}</h1>`);
          hasMainTitle = true;
        } else {
          htmlLines.push(`<h2>${line}</h2>`);
        }
      }
      // Detectar listas
      else if (line.match(/^[\-\*\+]\s+/) || line.match(/^\d+\.\s+/)) {
        if (!inList) {
          if (inTable) {
            htmlLines.push('</table>');
            inTable = false;
          }
          htmlLines.push('<ul>');
          inList = true;
        }
        const text = line.replace(/^[\-\*\+\d\.\s]+/, '');
        htmlLines.push(`<li>${text}</li>`);
      }
      // Detectar tabelas simples
      else if (line.includes('|') && line.split('|').length >= 3) {
        if (inList) {
          htmlLines.push('</ul>');
          inList = false;
        }
        if (!inTable) {
          htmlLines.push('<table style="width: 100%; border-collapse: collapse; margin: 20px 0;">');
          inTable = true;
        }
        
        const cells = line.split('|').map(cell => cell.trim()).filter(cell => cell);
        htmlLines.push('<tr>');
        cells.forEach(cell => {
          if (cell.includes('---') || cell.match(/^[\-\s]+$/)) {
            // Linha separadora - ignorar
            return;
          }
          htmlLines.push(`<td style="border: 1px solid #ddd; padding: 8px;">${cell}</td>`);
        });
        htmlLines.push('</tr>');
      }
      // Parágrafos normais
      else {
        if (inList) {
          htmlLines.push('</ul>');
          inList = false;
        }
        if (inTable) {
          htmlLines.push('</table>');
          inTable = false;
        }
        
        // Aplicar formatação inline
        line = line
          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
          .replace(/\*(.*?)\*/g, '<em>$1</em>')
          .replace(/`(.*?)`/g, '<code>$1</code>');
        
        htmlLines.push(`<p>${line}</p>`);
      }
    }

    // Fechar tags abertas
    if (inList) {
      htmlLines.push('</ul>');
    }
    if (inTable) {
      htmlLines.push('</table>');
    }

    // Garantir que há um título H1 se não foi detectado
    if (!hasMainTitle && title) {
      htmlLines.unshift(`<h1>${title}</h1>`);
    }

    const formattedContent = htmlLines.join('\n');
    
    console.log('✅ Formatação HTML avançada aplicada:', {
      originalLength: content.length,
      formattedLength: formattedContent.length,
      hasMainTitle,
      lineCount: htmlLines.length
    });
    
    return formattedContent;
  }, []);

  // FUNÇÃO DE PRODUÇÃO EM MASSA (ATUALIZADA)
  const handleBatchProduce = useCallback(async () => {
    if (selectedIdeaIds.length === 0) {
      toast.error('Selecione pelo menos uma ideia para produzir em massa');
      return;
    }

    const requiredArticles = selectedIdeaIds.length;
    if (isFreePlan && !isDevOrAdmin && articlesUsed + requiredArticles > planLimits.articles) {
      toast.error(`Limite insuficiente! Você precisa de ${requiredArticles} artigos, mas só tem ${articlesRemaining} disponíveis.`);
      return;
    }

    setProcessingBatch(true);
    setBatchProgress({});

    console.log(`🚀 Iniciando produção em massa de ${selectedIdeaIds.length} ideias`);

    try {
      let successCount = 0;
      let errorCount = 0;

      for (let i = 0; i < selectedIdeaIds.length; i++) {
        const ideaId = selectedIdeaIds[i];
        const idea = state.ideas.find(idea => idea.id === ideaId);
        
        if (!idea) {
          console.warn(`⚠️ Ideia ${ideaId} não encontrada, pulando...`);
          errorCount++;
          continue;
        }

        try {
          console.log(`📝 Processando ideia ${i + 1}/${selectedIdeaIds.length}: ${idea.titulo}`);
          
          // Atualizar progresso individual
          setBatchProgress(prev => ({ ...prev, [ideaId]: 25 }));

          // Progresso: Gerando conteúdo
          setBatchProgress(prev => ({ ...prev, [ideaId]: 50 }));

          // Usar diretamente o openaiService com formatação aprimorada
          const result = await openaiService.generateContent({
            type: 'content',
            userId: parseInt(userData?.id) || Date.now(),
            prompt: idea.titulo,
            parameters: {
              nicho: idea.generationParams?.nicho || idea.categoria || 'Geral',
              palavrasChave: idea.generationParams?.palavrasChave || idea.tags?.join(', ') || '',
              idioma: idea.generationParams?.idioma || 'Português',
              contexto: idea.generationParams?.contexto,
              userPlan: userData?.plano || 'Free',
              userEmail: userData?.email,
              // Parâmetros adicionais para garantir formatação SEO
              enforceHtmlFormatting: true,
              seoOptimized: true,
              includeStructuredData: true
            }
          });

          if (!result.success) {
            console.error(`❌ Erro na geração do artigo ${ideaId}: ${result.error}`);
            setBatchProgress(prev => ({ ...prev, [ideaId]: -1 }));
            errorCount++;
            continue;
          }

          // Progresso: Salvando
          setBatchProgress(prev => ({ ...prev, [ideaId]: 75 }));

          // Garantir formatação HTML adequada
          let processedContent = result.content || '';
          if (!processedContent.includes('<h1>') && !processedContent.includes('<h2>')) {
            processedContent = applyAdvancedHtmlFormatting(processedContent, idea.titulo);
          }

          const articleData = {
            titulo: idea.titulo,
            conteudo: processedContent,
            status: 'Concluído' as const,
            siteId: idea.siteId,
            ideaId: ideaId,
            imageUrl: result.imageUrl,
            wordpressData: idea.wordpressData,
            generationParams: idea.generationParams
          };

          const success = actions.addArticle(articleData);
          
          if (success) {
            actions.updateIdea(ideaId, { 
              status: 'produzido',
              articleId: Date.now()
            });
            
            setBatchProgress(prev => ({ ...prev, [ideaId]: 100 }));
            successCount++;
            console.log(`✅ Artigo ${ideaId} produzido com sucesso (${i + 1}/${selectedIdeaIds.length})`);
          } else {
            setBatchProgress(prev => ({ ...prev, [ideaId]: -1 }));
            errorCount++;
          }

        } catch (error) {
          console.error(`❌ Erro ao processar ideia ${ideaId}:`, error);
          setBatchProgress(prev => ({ ...prev, [ideaId]: -1 }));
          errorCount++;
        }

        // Pequena pausa entre as gerações para não sobrecarregar a API
        if (i < selectedIdeaIds.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }

      // Limpar seleção e mostrar resultado
      setSelectedIdeaIds([]);
      
      if (successCount > 0 && errorCount === 0) {
        toast.success(`🎉 Produção em massa concluída! ${successCount} artigos produzidos com sucesso.`);
      } else if (successCount > 0 && errorCount > 0) {
        toast.warning(`Produção parcial: ${successCount} sucessos, ${errorCount} erros. Verifique os artigos individualmente.`);
      } else {
        toast.error(`❌ Falha na produção em massa. ${errorCount} erros ocorreram.`);
      }

      // Limpar progresso após alguns segundos
      setTimeout(() => {
        setBatchProgress({});
      }, 5000);

    } catch (error) {
      console.error('❌ Erro crítico na produção em massa:', error);
      toast.error('Erro crítico na produção em massa. Tente novamente.');
    } finally {
      setProcessingBatch(false);
    }
  }, [selectedIdeaIds, isFreePlan, articlesUsed, planLimits.articles, articlesRemaining, state.ideas, actions, userData, isDevOrAdmin, applyAdvancedHtmlFormatting]);

  // FUNÇÃO PARA DELETAR IDEIAS
  const handleDeleteIdea = useCallback(async (ideaId: number) => {
    if (deletingSingle[ideaId]) return;

    const idea = state.ideas.find(i => i.id === ideaId);
    if (!idea) {
      toast.error('Ideia não encontrada');
      return;
    }

    if (!confirm(`Tem certeza que deseja excluir a ideia "${idea.titulo}"? Esta ação não pode ser desfeita.`)) {
      return;
    }

    setDeletingSingle(prev => ({ ...prev, [ideaId]: true }));
    setSelectedIdeaIds(prev => prev.filter(id => id !== ideaId));

    try {
      const success = actions.deleteIdea(ideaId);
      
      if (success) {
        toast.success('Ideia excluída com sucesso');
      } else {
        toast.error('Erro ao excluir ideia');
      }
    } catch (error) {
      console.error('Erro ao excluir ideia:', error);
      toast.error('Erro inesperado ao excluir ideia');
    } finally {
      setDeletingSingle(prev => {
        const newState = { ...prev };
        delete newState[ideaId];
        return newState;
      });
    }
  }, [state.ideas, actions, deletingSingle]);

  // FUNÇÃO PARA DELETAR EM MASSA
  const handleBatchDelete = useCallback(async () => {
    if (selectedIdeaIds.length === 0) {
      toast.error('Selecione pelo menos uma ideia para excluir');
      return;
    }

    if (!confirm(`Tem certeza que deseja excluir ${selectedIdeaIds.length} ideia(s) selecionada(s)? Esta ação não pode ser desfeita.`)) {
      return;
    }

    setDeletingBatch(true);

    try {
      let successCount = 0;
      let errorCount = 0;

      for (const ideaId of selectedIdeaIds) {
        try {
          const success = actions.deleteIdea(ideaId);
          if (success) {
            successCount++;
          } else {
            errorCount++;
          }
        } catch (error) {
          console.error(`Erro ao excluir ideia ${ideaId}:`, error);
          errorCount++;
        }
      }

      setSelectedIdeaIds([]);

      if (errorCount === 0) {
        toast.success(`${successCount} ideia(s) excluída(s) com sucesso`);
      } else {
        toast.warning(`${successCount} sucessos, ${errorCount} erros na exclusão`);
      }

    } catch (error) {
      console.error('Erro crítico na exclusão em massa:', error);
      toast.error('Erro crítico na exclusão em massa');
    } finally {
      setDeletingBatch(false);
    }
  }, [selectedIdeaIds, actions]);

  // FUNÇÃO PARA PUBLICAR ARTIGO NO WORDPRESS
  const handlePublishArticle = useCallback(async (ideaId: number) => {
    console.log(`📤 Iniciando publicação do artigo para ideia ${ideaId}`);

    if (publishingSingle[ideaId]) {
      console.log(`⚠️ Artigo ${ideaId} já está sendo publicado - ignorando`);
      return;
    }

    const idea = state.ideas.find(i => i.id === ideaId);
    const article = state.articles.find(a => a.ideaId === ideaId);
    
    if (!idea || !article) {
      toast.error('Artigo não encontrado');
      return;
    }

    // Verificar configuração WordPress
    const site = state.sites.find(s => s.id === idea.siteId);
    
    if (!site) {
      console.error(`❌ Site não encontrado para siteId: ${idea.siteId}`);
      toast.error('Site não encontrado. Verifique se o site ainda existe na seção Meus Sites.');
      return;
    }

    if (!site.wordpressUrl || !site.wordpressUsername || !site.wordpressPassword) {
      console.error(`❌ WordPress não configurado para site ${site.nome}`);
      toast.error(`WordPress não configurado para o site "${site.nome}". Configure na seção Meus Sites.`);
      return;
    }

    setPublishingSingle(prev => ({ ...prev, [ideaId]: true }));

    try {
      console.log(`📝 Publicando artigo "${article.titulo}" no WordPress...`);
      
      // Usar a API do servidor para publicar
      const { projectId, publicAnonKey } = await import('../../utils/supabase/info');
      
      const publishUrl = `https://${projectId}.supabase.co/functions/v1/make-server-53322c0b/wordpress/publish-post`;
      
      console.log('📡 URL de publicação:', publishUrl);
      
      const requestData = {
        siteData: {
          url: site.wordpressUrl.trim(),
          username: site.wordpressUsername.trim(),
          applicationPassword: site.wordpressPassword.trim()
        },
        postData: {
          title: article.titulo,
          content: article.conteudo,
          status: 'publish',
          categoryName: idea.categoria || '',
          tagNames: idea.tags || []
        },
        // Adicionar dados da imagem se disponível
        imageData: article.imageUrl ? {
          url: article.imageUrl,
          alt: article.titulo,
          title: article.titulo
        } : undefined
      };
      
      console.log('📋 Dados de publicação preparados:', {
        url: requestData.siteData.url,
        title: requestData.postData.title,
        hasContent: !!requestData.postData.content,
        categoryName: requestData.postData.categoryName,
        tagCount: requestData.postData.tagNames?.length || 0,
        hasImageData: !!requestData.imageData
      });
      
      // Adicionar timeout mais longo e melhor logging
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 45000); // 45 segundos
      
      try {
        const response = await fetch(publishUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(requestData),
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        console.log('📨 Resposta da publicação:', {
          status: response.status,
          statusText: response.statusText,
          ok: response.ok,
          headers: Object.fromEntries(response.headers.entries())
        });
        
        if (!response.ok) {
          let errorDetails = '';
          try {
            const errorText = await response.text();
            errorDetails = errorText;
            console.error('❌ Erro HTTP na publicação:', {
              status: response.status,
              statusText: response.statusText,
              error: errorText
            });
          } catch (parseError) {
            console.error('❌ Não foi possível ler resposta de erro:', parseError);
            errorDetails = 'Resposta de erro não legível';
          }
          
          // Mensagens de erro mais específicas
          if (response.status === 404) {
            throw new Error('Rota WordPress não encontrada no servidor. Aguarde alguns momentos e tente novamente.');
          } else if (response.status === 401) {
            throw new Error('Credenciais WordPress inválidas. Verifique a configuração na seção Meus Sites.');
          } else if (response.status === 403) {
            throw new Error('Permissões insuficientes no WordPress. Verifique se o usuário tem permissão para publicar.');
          } else if (response.status >= 500) {
            throw new Error('Erro interno do servidor. Tente novamente em alguns momentos.');
          } else {
            throw new Error(`Erro na publicação (${response.status}): ${errorDetails}`);
          }
        }
        
        const publishResult = await response.json();
        
        if (publishResult.success) {
          console.log('✅ Artigo publicado com sucesso:', publishResult);
          
          // Atualizar artigo com informações de publicação
          actions.updateArticle(article.id, {
            publishedUrl: publishResult.postUrl || publishResult.data?.link,
            publishedAt: new Date().toISOString(),
            wordpressId: publishResult.postId || publishResult.data?.id,
            status: 'Publicado'
          });
          
          toast.success(`Artigo publicado com sucesso no WordPress! 🎉`);
        } else {
          console.error('❌ Falha na publicação:', publishResult);
          throw new Error(publishResult.error || 'Falha na publicação WordPress');
        }
      } catch (fetchError) {
        clearTimeout(timeoutId);
        throw fetchError;
      }
      
    } catch (error) {
      console.error(`❌ Erro na publicação do artigo ${ideaId}:`, error);
      
      let errorMessage = 'Erro na publicação WordPress';
      
      if (error.name === 'AbortError') {
        errorMessage = 'Timeout na publicação. O WordPress pode estar lento ou indisponível.';
      } else if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
        errorMessage = 'Erro de conectividade. Verifique sua conexão e tente novamente.';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(`Erro na publicação: ${errorMessage}`);
      
    } finally {
      setPublishingSingle(prev => {
        const newState = { ...prev };
        delete newState[ideaId];
        return newState;
      });
    }
  }, [state.ideas, state.articles, state.sites, actions, publishingSingle]);

  // FUNÇÃO PARA AGENDAR ARTIGO NO WORDPRESS
  const handleScheduleArticle = useCallback(async () => {
    if (!currentSchedulingArticle || !selectedDate) {
      toast.error('Selecione uma data válida');
      return;
    }

    const ideaId = currentSchedulingArticle;
    const idea = state.ideas.find(i => i.id === ideaId);
    const article = state.articles.find(a => a.ideaId === ideaId);
    
    if (!idea || !article) {
      toast.error('Artigo não encontrado');
      return;
    }

    // Verificar configuração WordPress
    const site = state.sites.find(s => s.id === idea.siteId);
    
    if (!site) {
      console.error(`❌ Site não encontrado para siteId: ${idea.siteId}`);
      toast.error('Site não encontrado. Verifique se o site ainda existe na seção Meus Sites.');
      return;
    }

    if (!site.wordpressUrl || !site.wordpressUsername || !site.wordpressPassword) {
      console.error(`❌ WordPress não configurado para site ${site.nome} no agendamento`);
      toast.error(`WordPress não configurado para o site "${site.nome}". Configure na seção Meus Sites.`);
      return;
    }

    setSchedulingSingle(prev => ({ ...prev, [ideaId]: true }));

    try {
      // Combinar data e hora selecionadas
      const [hours, minutes] = selectedTime.split(':').map(Number);
      const scheduledDateTime = new Date(selectedDate);
      scheduledDateTime.setHours(hours, minutes, 0, 0);

      // Verificar se a data não é no passado
      if (scheduledDateTime <= new Date()) {
        toast.error('A data de agendamento deve ser no futuro');
        return;
      }

      console.log(`📅 Agendando artigo "${article.titulo}" para ${scheduledDateTime.toLocaleString('pt-BR')}`);
      
      // Usar a API do servidor para agendar
      const { projectId, publicAnonKey } = await import('../../utils/supabase/info');
      
      const scheduleData = {
        siteData: {
          url: site.wordpressUrl.trim(),
          username: site.wordpressUsername.trim(),
          applicationPassword: site.wordpressPassword.trim()
        },
        postData: {
          title: article.titulo.trim(),
          content: article.conteudo,
          status: 'future',
          date: scheduledDateTime.toISOString(),
          categoryName: idea.categoria || 'Geral',
          tagNames: (idea.tags || []).filter(tag => tag && typeof tag === 'string' && tag.trim())
        },
        // Adicionar dados da imagem se disponível para agendamento
        imageData: article.imageUrl ? {
          url: article.imageUrl,
          alt: article.titulo,
          title: article.titulo
        } : undefined
      };

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-53322c0b/wordpress/schedule-post`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify(scheduleData),
        signal: AbortSignal.timeout(60000)
      });

      if (response.ok) {
        const result = await response.json();
        
        if (result.success) {
          // Atualizar artigo com dados do agendamento
          actions.updateArticle(article.id, {
            status: 'Agendado' as const,
            scheduledDate: scheduledDateTime.toISOString(),
            wordpressPostId: result.postId
          });

          console.log(`✅ Artigo agendado com sucesso para ${scheduledDateTime.toLocaleString('pt-BR')}`);
          toast.success(`Artigo agendado para ${scheduledDateTime.toLocaleDateString('pt-BR')} às ${selectedTime}! 📅`);
          
          // Fechar modal
          setScheduleDialogOpen(false);
          setCurrentSchedulingArticle(null);
          setSelectedDate(undefined);
          setSelectedTime('08:00');
        } else {
          toast.error(`Erro ao agendar: ${result.error || 'Erro desconhecido'}`);
        }
      } else {
        const errorText = await response.text().catch(() => 'Erro desconhecido');
        toast.error(`Erro no agendamento: HTTP ${response.status} - ${errorText}`);
      }
    } catch (error) {
      console.error(`❌ Erro ao agendar artigo ${ideaId}:`, error);
      if (error.name === 'AbortError') {
        toast.error('Timeout no agendamento. Tente novamente.');
      } else {
        toast.error('Erro inesperado ao agendar artigo. Tente novamente.');
      }
    } finally {
      setSchedulingSingle(prev => {
        const newState = { ...prev };
        delete newState[ideaId];
        return newState;
      });
    }
  }, [currentSchedulingArticle, selectedDate, selectedTime, state.ideas, state.articles, state.sites, actions]);

  // Função para abrir modal de agendamento
  const handleOpenScheduleDialog = useCallback((ideaId: number) => {
    setCurrentSchedulingArticle(ideaId);
    setSelectedDate(undefined);
    setSelectedTime('08:00');
    setScheduleDialogOpen(true);
  }, []);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-poppins text-2xl text-black mb-2">Produzir Artigos</h1>
        <p className="font-montserrat text-gray-600">Transforme suas ideias em artigos completos usando IA</p>
      </div>

      {/* Status da API OpenAI */}
      {apiDiagnostic.checked && (!apiDiagnostic.hasKey || !apiDiagnostic.isValid) && (
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="font-montserrat">
            <div className="flex items-center justify-between">
              <div>
                <strong>Sistema de IA indisponível:</strong> {
                  !apiDiagnostic.hasKey 
                    ? 'A chave OpenAI não está configurada no sistema.'
                    : 'A chave OpenAI configurada é inválida.'
                } {apiDiagnostic.details && (
                  <span className="text-sm block mt-1 text-red-700">
                    Detalhes: {apiDiagnostic.details}
                  </span>
                )}
              </div>
              <Button
                onClick={handleTestApiKey}
                size="sm"
                variant="outline"
                className="ml-4 text-red-600 border-red-300 hover:bg-red-100"
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Testar
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Status do usuário */}
      <Card className="border border-gray-200">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div>
                <p className="font-montserrat text-sm text-black">
                  <strong>Plano {userData?.plano || 'Free'}:</strong> {articlesRemaining} artigos restantes
                </p>
                <p className="font-montserrat text-xs text-gray-600 mt-1">
                  {articlesUsed} de {isFreePlan ? planLimits.articles : '∞'} artigos utilizados
                </p>
              </div>
              
              {/* Indicador de status da API */}
              {apiDiagnostic.checked && (
                <div 
                  className={`w-3 h-3 rounded-full ${
                    apiDiagnostic.hasKey && apiDiagnostic.isValid 
                      ? 'bg-green-500' 
                      : 'bg-red-500'
                  }`} 
                  title={
                    apiDiagnostic.hasKey && apiDiagnostic.isValid 
                      ? 'Sistema de IA funcionando' 
                      : 'Sistema de IA indisponível'
                  } 
                />
              )}
            </div>
            
            {isFreePlan && (
              <div className="w-full sm:w-48">
                <Progress value={progressValue} variant="bia-purple" className="h-2" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Alerta de limite */}
      {!limits.articles && isFreePlan && !isDevOrAdmin && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertCircle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-700 font-montserrat">
            <strong>Limite atingido!</strong> Você utilizou todos os {planLimits.articles} artigos do plano gratuito.
            Faça upgrade para produzir mais artigos.
          </AlertDescription>
        </Alert>
      )}

      {/* Lista de ideias */}
      <Card>
        <CardHeader>
          <CardTitle className="font-poppins flex items-center">
            <FileText className="mr-2 h-5 w-5 text-purple-600" />
            Ideias Disponíveis ({availableIdeas.length})
            {apiDiagnostic.checked && (
              <div className={`w-2 h-2 rounded-full ml-2 ${
                apiDiagnostic.hasKey && apiDiagnostic.isValid 
                  ? 'bg-green-500' 
                  : 'bg-red-500'
              }`} />
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Filtros */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar ideias..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 font-montserrat"
                />
              </div>
            </div>
            
            <Select value={statusFilter} onValueChange={(value: 'all' | 'pending' | 'produced') => handleFilterChange('status', value)}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="pending">Pendentes</SelectItem>
                <SelectItem value="produced">Produzidos</SelectItem>
              </SelectContent>
            </Select>

            {availableSites.length > 1 && (
              <Select value={siteFilter.toString()} onValueChange={(value) => handleFilterChange('site', value === 'all' ? 'all' : parseInt(value))}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os sites</SelectItem>
                  {availableSites.map(site => (
                    <SelectItem key={site.id} value={site.id.toString()}>
                      {site.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          {/* Ações em massa */}
          {selectedIdeaIds.length > 0 && (
            <div className="flex flex-wrap gap-2 p-4 bg-gray-50 rounded-lg border">
              <div className="flex items-center space-x-2 mr-4">
                <span className="font-montserrat text-sm text-gray-700">
                  {selectedIdeaIds.length} item(s) selecionado(s)
                </span>
              </div>
              
              <Button
                size="sm"
                onClick={handleBatchProduce}
                disabled={processingBatch || !apiDiagnostic.isValid}
                className="text-white"
                style={{ backgroundColor: '#8B5FBF' }}
              >
                {processingBatch ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-1" style={{ color: '#8B5FBF' }} />
                ) : (
                  <Zap className="h-4 w-4 mr-1" />
                )}
                Produzir Selecionados
              </Button>

              <Button
                size="sm"
                variant="destructive"
                onClick={handleBatchDelete}
                disabled={deletingBatch}
              >
                {deletingBatch ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-1" />
                ) : (
                  <Trash2 className="h-4 w-4 mr-1" />
                )}
                Excluir Selecionados
              </Button>

              <Button
                size="sm"
                variant="outline"
                onClick={handleClearSelection}
              >
                <XCircle className="h-4 w-4 mr-1" />
                Limpar Seleção
              </Button>
            </div>
          )}

          {/* Seleção de todas as ideias da página */}
          {currentPageIdeas.length > 0 && (
            <div className="flex items-center space-x-2 p-2 border-b">
              <Checkbox
                checked={allCurrentPageSelected}
                onCheckedChange={handleSelectAllIdeas}
                disabled={processingBatch}
              />
              <Label className="font-montserrat text-sm">
                Selecionar todas da página atual ({currentPageIdeas.length})
              </Label>
            </div>
          )}

          {/* Lista de ideias */}
          {currentPageIdeas.length === 0 ? (
            <div className="text-center py-12">
              <Lightbulb className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="font-poppins text-lg text-gray-700 mb-2">
                {searchQuery || statusFilter !== 'all' || siteFilter !== 'all' 
                  ? 'Nenhuma ideia encontrada com os filtros aplicados'
                  : 'Nenhuma ideia disponível'
                }
              </h3>
              <p className="font-montserrat text-gray-500">
                {searchQuery || statusFilter !== 'all' || siteFilter !== 'all'
                  ? 'Tente ajustar os filtros para encontrar suas ideias.'
                  : 'Vá para a seção "Gerar Ideias" para criar suas primeiras ideias de conteúdo.'
                }
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {currentPageIdeas.map((idea) => {
                const hasArticle = state.articles.some(a => a.ideaId === idea.id);
                const article = state.articles.find(a => a.ideaId === idea.id);
                const isProcessing = processingSingle[idea.id];
                const progress = singleProgress[idea.id];
                const batchItemProgress = batchProgress[idea.id];
                const canProduce = apiDiagnostic.hasKey && apiDiagnostic.isValid && (limits.articles || isDevOrAdmin);

                return (
                  <div key={idea.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Checkbox
                            checked={selectedIdeaIds.includes(idea.id)}
                            onCheckedChange={(checked) => handleSelectIdea(idea.id, checked as boolean)}
                            disabled={isProcessing || hasArticle || processingBatch}
                          />
                          <h4 className="font-montserrat font-medium text-black">
                            {idea.titulo}
                          </h4>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-2">
                          <Badge variant="outline" className="text-xs">
                            {getSiteName(idea.siteId)}
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {idea.categoria}
                          </Badge>
                          {idea.status === 'produzido' && (
                            <Badge className="text-xs bg-green-100 text-green-800">
                              Produzido
                            </Badge>
                          )}
                          {idea.tags?.slice(0, 2).map((tag, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {idea.tags && idea.tags.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{idea.tags.length - 2}
                            </Badge>
                          )}
                        </div>

                        {/* Barra de progresso para ideias sendo processadas - ROXO BIA */}
                        {(isProcessing && progress !== undefined) || (batchItemProgress !== undefined) && (
                          <div className="mt-2">
                            <div className="flex justify-between text-xs text-gray-600 mb-1">
                              <span>
                                {processingBatch ? 'Produção em massa...' : 'Produzindo artigo...'}
                              </span>
                              <span>{batchItemProgress || progress}%</span>
                            </div>
                            <Progress 
                              value={(batchItemProgress || progress) === -1 ? 100 : (batchItemProgress || progress)} 
                              variant={(batchItemProgress || progress) === -1 ? 'error' : 'bia-purple'}
                              className="h-2"
                            />
                            {(batchItemProgress || progress) === -1 && (
                              <span className="text-xs text-red-600 mt-1">Erro na produção</span>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center space-x-2 ml-4">
                        {hasArticle && article ? (
                          <>
                            <Button
                              size="sm"
                              onClick={() => handleViewArticle(idea.id)}
                              className="bg-green-600 hover:bg-green-700 text-white border-green-600"
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              Ver
                            </Button>
                            {!article.publishedUrl && !article.scheduledDate && (
                              <>
                                <Button
                                  size="sm"
                                  className="text-white"
                                  style={{ backgroundColor: '#8B5FBF' }}
                                  onClick={() => handlePublishArticle(idea.id)}
                                  disabled={publishingSingle[idea.id]}
                                >
                                  {publishingSingle[idea.id] ? (
                                    <Loader2 className="h-4 w-4 animate-spin" style={{ color: '#8B5FBF' }} />
                                  ) : (
                                    <Send className="h-4 w-4 mr-1" />
                                  )}
                                  Publicar
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleOpenScheduleDialog(idea.id)}
                                  disabled={schedulingSingle[idea.id]}
                                  className="bg-white border-[#8B5FBF] text-[#8B5FBF] hover:bg-purple-50"
                                >
                                  {schedulingSingle[idea.id] ? (
                                    <Loader2 className="h-4 w-4 animate-spin" style={{ color: '#8B5FBF' }} />
                                  ) : (
                                    <Calendar className="h-4 w-4 mr-1" />
                                  )}
                                  Agendar
                                </Button>
                              </>
                            )}
                            {(article.publishedUrl || article.scheduledDate) && (
                              <Badge className="text-xs">
                                {article.publishedUrl ? 'Publicado' : 'Agendado'}
                              </Badge>
                            )}
                          </>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => handleProduceFromIdea(idea.id)}
                            disabled={isProcessing || !canProduce || processingBatch}
                            className="text-white disabled:bg-gray-300"
                            style={{ 
                              backgroundColor: canProduce && !isProcessing && !processingBatch ? '#8B5FBF' : '#9CA3AF' 
                            }}
                          >
                            {isProcessing || (processingBatch && batchItemProgress !== undefined) ? (
                              <Loader2 className="h-4 w-4 animate-spin mr-1" style={{ color: '#8B5FBF' }} />
                            ) : (
                              <Zap className="h-4 w-4 mr-1" />
                            )}
                            {isProcessing || (processingBatch && batchItemProgress !== undefined) ? 'Produzindo...' : 'Produzir'}
                          </Button>
                        )}
                        
                        {/* Botão para excluir ideia */}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeleteIdea(idea.id)}
                          disabled={deletingSingle[idea.id] || isProcessing || processingBatch}
                          className="text-red-600 hover:bg-red-50"
                        >
                          {deletingSingle[idea.id] ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Paginação */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-4">
              <div className="text-sm text-gray-600 font-montserrat">
                Página {currentPage} de {totalPages} ({availableIdeas.length} ideias)
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                  Anterior
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                >
                  Próxima
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal para visualizar artigo */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-poppins flex items-center">
              <Eye className="mr-2 h-5 w-5 text-blue-600" />
              Visualizar Artigo
            </DialogTitle>
            <DialogDescription className="font-montserrat">
              Visualize o conteúdo completo do artigo gerado, incluindo imagem, informações e formatação.
            </DialogDescription>
          </DialogHeader>
          
          {currentViewingArticle && (
            <div className="space-y-6">
              {/* Informações do artigo */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <Label className="font-montserrat text-sm text-gray-600">Site</Label>
                  <p className="font-montserrat">{currentViewingArticle.siteName}</p>
                </div>
                <div>
                  <Label className="font-montserrat text-sm text-gray-600">Categoria</Label>
                  <p className="font-montserrat">{currentViewingArticle.idea.categoria}</p>
                </div>
                <div>
                  <Label className="font-montserrat text-sm text-gray-600">Palavras</Label>
                  <p className="font-montserrat">{currentViewingArticle.wordCount}</p>
                </div>
                <div>
                  <Label className="font-montserrat text-sm text-gray-600">Status</Label>
                  <Badge className="bg-green-100 text-green-800">
                    {currentViewingArticle.article.status}
                  </Badge>
                </div>
              </div>

              {/* Tags */}
              {currentViewingArticle.idea.tags && currentViewingArticle.idea.tags.length > 0 && (
                <div>
                  <Label className="font-montserrat text-sm text-gray-600 mb-2 block">Tags</Label>
                  <div className="flex flex-wrap gap-2">
                    {currentViewingArticle.idea.tags.map((tag, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Imagem em destaque */}
              {currentViewingArticle.article.imageUrl && (
                <div>
                  <Label className="font-montserrat text-sm text-gray-600 mb-2 block">Imagem em Destaque</Label>
                  <div className="border rounded-lg overflow-hidden">
                    <img 
                      src={currentViewingArticle.article.imageUrl} 
                      alt={currentViewingArticle.article.titulo}
                      className="w-full h-64 object-cover"
                    />
                  </div>
                </div>
              )}

              {/* Conteúdo do artigo */}
              <div>
                <Label className="font-montserrat text-sm text-gray-600 mb-2 block">Conteúdo</Label>
                <div 
                  className="prose max-w-none p-4 border rounded-lg bg-white"
                  dangerouslySetInnerHTML={{ __html: currentViewingArticle.article.conteudo }}
                />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal para agendamento */}
      <Dialog open={scheduleDialogOpen} onOpenChange={setScheduleDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-poppins flex items-center">
              <Calendar className="mr-2 h-5 w-5 text-orange-600" />
              Agendar Publicação
            </DialogTitle>
            <DialogDescription className="font-montserrat">
              Selecione a data e horário para publicar automaticamente no WordPress.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Calendário */}
            <div>
              <Label className="font-montserrat mb-2 block">Data da Publicação</Label>
              <CalendarComponent
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                disabled={(date) => date < new Date()}
                className="rounded-md border w-full"
              />
            </div>

            {/* Horário */}
            <div>
              <Label className="font-montserrat mb-2 block">Horário</Label>
              <Select value={selectedTime} onValueChange={setSelectedTime}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 24 }, (_, i) => {
                    const hour = i.toString().padStart(2, '0');
                    return (
                      <SelectItem key={hour} value={`${hour}:00`}>
                        {hour}:00
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            {/* Botões */}
            <div className="flex justify-end space-x-2 pt-4">
              <Button
                variant="outline"
                onClick={() => setScheduleDialogOpen(false)}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleScheduleArticle}
                disabled={!selectedDate || schedulingSingle[currentSchedulingArticle]}
                className="text-white"
                style={{ backgroundColor: '#8B5FBF' }}
              >
                {schedulingSingle[currentSchedulingArticle] ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-1" style={{ color: '#8B5FBF' }} />
                ) : (
                  <Calendar className="h-4 w-4 mr-1" />
                )}
                Agendar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}