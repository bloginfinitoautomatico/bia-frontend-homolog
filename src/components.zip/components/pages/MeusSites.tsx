import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';
import { Alert, AlertDescription } from '../ui/alert';
import { Progress } from '../ui/progress';
import { 
  Plus, 
  Monitor, 
  CheckCircle, 
  XCircle, 
  ExternalLink, 
  Trash2, 
  FileText, 
  Settings, 
  Loader2, 
  AlertCircle,
  Globe,
  Wifi,
  WifiOff,
  ArrowUpRight,
  Clock,
  Lightbulb,
  BarChart3
} from '../icons';
import { useBia } from '../BiaContext';
import { formatDate } from '../../utils/helpers';
import { toast } from 'sonner';
import { FREE_PLAN_LIMITS, getPlanLimits, isFreePlan } from '../../utils/constants';

interface MeusSitesProps {
  userData: any;
  onUpdateUser?: (userData: any) => Promise<boolean>;
}

interface WordPressCredentials {
  url: string;
  username: string;
  applicationPassword: string;
}

export function MeusSites({ userData, onUpdateUser }: MeusSitesProps) {
  const { state, actions } = useBia();
  const [showAddForm, setShowAddForm] = useState(false);
  const [showWordPressForm, setShowWordPressForm] = useState<number | null>(null);
  const [connectingWP, setConnectingWP] = useState(false);
  const [syncing, setSyncing] = useState(true);
  const [newSite, setNewSite] = useState({ 
    nome: '', 
    url: '',
    status: 'ativo' as const
  });
  const [wordpressCredentials, setWordpressCredentials] = useState<WordPressCredentials>({
    url: '',
    username: '',
    applicationPassword: ''
  });

  // Sincronizar dados WordPress na inicialização
  React.useEffect(() => {
    const syncData = async () => {
      try {
        const { wordpressService } = await import('../../services/wordpressService');
        
        setTimeout(async () => {
          try {
            await wordpressService.syncFromBiaContext();
            console.log('✅ Sincronização WordPress concluída em MeusSites');
          } catch (error) {
            console.warn('⚠️ Sincronização WordPress falhou (não crítico):', error?.message || error);
          }
        }, 3000);
        
      } catch (error) {
        console.warn('Erro ao carregar serviço WordPress:', error);
      } finally {
        setSyncing(false);
      }
    };

    syncData();
  }, []);

  // Verificar limites do plano
  const limits = actions.checkFreePlanLimits();
  const userPlan = userData?.plano || 'Free';
  const isFree = isFreePlan(userPlan);
  const planLimits = getPlanLimits(userPlan);

  const handleAddSite = () => {
    if (!newSite.nome.trim()) {
      toast.error('Nome do site é obrigatório');
      return;
    }
    
    if (newSite.url && !newSite.url.startsWith('http')) {
      toast.error('URL deve começar com http:// ou https://');
      return;
    }

    if (!limits.sites) {
      toast.error(`Limite de ${planLimits.sites} sites atingido. Faça upgrade do seu plano.`);
      return;
    }
    
    const success = actions.addSite(newSite);
    if (success) {
      toast.success('Site adicionado com sucesso!');
      setNewSite({ nome: '', url: '', status: 'ativo' });
      setShowAddForm(false);
    } else {
      toast.error('Erro ao adicionar site. Limite atingido.');
    }
  };

  const handleToggleStatus = (site: any) => {
    const newStatus = site.status === 'ativo' ? 'inativo' : 'ativo';
    actions.updateSite(site.id, { status: newStatus });
    toast.success(`Site ${newStatus === 'ativo' ? 'ativado' : 'pausado'} com sucesso!`);
  };

  const handleRemoveSite = (site: any) => {
    if (confirm('Tem certeza que deseja remover este site? Todos os artigos e ideias relacionados também serão removidos.')) {
      actions.deleteSite(site.id);
      toast.success('Site removido com sucesso!');
    }
  };

  const handleConnectWordPress = async (siteId: number) => {
    if (!wordpressCredentials.url || !wordpressCredentials.username || !wordpressCredentials.applicationPassword) {
      toast.error('Todos os campos são obrigatórios');
      return;
    }

    if (!wordpressCredentials.url.startsWith('http')) {
      toast.error('URL deve começar com http:// ou https://');
      return;
    }

    setConnectingWP(true);
    
    try {
      console.log('🔧 Iniciando processo de conexão WordPress...');
      
      toast.info('🔍 Testando conexão WordPress via servidor...', { duration: 3000 });
      
      const { wordpressService } = await import('../../services/wordpressService');
      const testResult = await wordpressService.testConnection({
        url: wordpressCredentials.url,
        username: wordpressCredentials.username,
        applicationPassword: wordpressCredentials.applicationPassword
      });

      if (!testResult.success) {
        console.error('❌ Falha no teste de conexão:', testResult);
        
        let errorTitle = '🚫 Falha na Conexão WordPress';
        let errorMessage = testResult.error || 'Erro desconhecido na conexão';
        let suggestions: string[] = [];
        
        const errorCategory = testResult.errorCategory || 'general';
        
        switch (errorCategory) {
          case 'credentials':
            errorTitle = '🔑 Credenciais Inválidas';
            suggestions.push('• Verifique se o nome de usuário está correto');
            suggestions.push('• Gere uma nova Application Password no WordPress');
            suggestions.push('• Use apenas usuários com papel de Administrador');
            break;
            
          case 'permissions':
            errorTitle = '⛔ Permissões Insuficientes';
            suggestions.push('• Use um usuário com papel de Administrador');
            suggestions.push('• Verifique se o usuário pode criar posts');
            break;
            
          case 'connectivity':
            errorTitle = '🚫 Site Inacessível';
            suggestions.push('• Verifique se a URL está correta');
            suggestions.push('• Teste a URL no navegador');
            break;
            
          case 'cors':
            errorTitle = '✅ Site Online - Problema de CORS';
            suggestions.push('• Instale o plugin "CORS WP"');
            suggestions.push('• Configure CORS no servidor');
            break;
        }
        
        let finalMessage = `${errorTitle}\n\n${errorMessage}`;
        
        if (suggestions.length > 0) {
          finalMessage += '\n\n💡 Soluções:\n' + suggestions.join('\n');
        }
        
        toast.error(finalMessage, { 
          duration: 15000,
          style: {
            maxWidth: '700px',
            whiteSpace: 'pre-line'
          }
        });
        return;
      }

      console.log('✅ Teste de conexão bem-sucedido:', testResult);
      
      let successMessage = '✅ Conexão WordPress estabelecida com sucesso!';
      
      if (testResult.serverTested) {
        successMessage += '\n\n🎯 Conexão validada via servidor';
      }
      
      const { categories = [], authors = [], tags = [] } = testResult;
      if (categories.length > 0 || authors.length > 0 || tags.length > 0) {
        successMessage += '\n\n📋 Dados carregados:';
        if (categories.length > 0) successMessage += `\n• ${categories.length} categorias`;
        if (authors.length > 0) successMessage += `\n• ${authors.length} autores`;
        if (tags.length > 0) successMessage += `\n• ${tags.length} tags`;
      }
      
      toast.success(successMessage, { 
        duration: 6000,
        style: { whiteSpace: 'pre-line' }
      });

      const wordpressData = {
        wordpressUrl: wordpressCredentials.url,
        wordpressUsername: wordpressCredentials.username,
        wordpressPassword: wordpressCredentials.applicationPassword
      };

      actions.updateSite(siteId, wordpressData);
      
      setTimeout(async () => {
        try {
          const syncSuccess = await actions.forceSyncToDatabase();
          if (syncSuccess) {
            console.log('✅ Dados salvos no banco');
            toast.success('Dados salvos com segurança!', { duration: 2000 });
          }
        } catch (syncError) {
          console.error('❌ Erro na sincronização:', syncError);
        }
      }, 500);
      
      setShowWordPressForm(null);
      setWordpressCredentials({ url: '', username: '', applicationPassword: '' });
      toast.success('🎉 Site conectado ao WordPress!');
      
    } catch (error) {
      console.error('❌ Erro ao conectar WordPress:', error);
      
      let errorMessage = '❌ Erro Inesperado\n\nErro ao conectar com o WordPress.';
      
      if (error instanceof Error) {
        if (error.message.includes('fetch') || error.message.includes('network')) {
          errorMessage = `🌐 Erro de Rede\n\nNão foi possível acessar ${wordpressCredentials.url}.\n\n💡 Verifique sua conexão e tente novamente.`;
        } else {
          errorMessage = `❌ Erro Técnico\n\n${error.message}`;
        }
      }
      
      toast.error(errorMessage, { 
        duration: 10000,
        style: {
          maxWidth: '600px',
          whiteSpace: 'pre-line'
        }
      });
    } finally {
      setConnectingWP(false);
    }
  };

  const handleStartWordPressIntegration = (siteId: number) => {
    const site = state.sites.find(s => s.id === siteId);
    if (site && site.url) {
      setWordpressCredentials(prev => ({
        ...prev,
        url: site.url
      }));
    }
    setShowWordPressForm(siteId);
  };

  // Calcular estatísticas
  const activeSites = state.sites.filter(s => s.status === 'ativo');
  const pausedSites = state.sites.filter(s => s.status === 'inativo');
  const connectedWordPressSites = state.sites.filter(s => s.wordpressUrl);
  const totalArticles = state.articles.length;
  const siteArticles = state.sites.map(site => ({
    ...site,
    articleCount: state.articles.filter(article => article.siteId === site.id).length
  }));

  // Corrigir cálculo de limites - usar valores reais em vez de números absurdos
  const sitesLimit = planLimits.isUnlimited ? 'Ilimitado' : planLimits.sites;
  const sitesUsed = state.sites.length;
  const canAddSite = planLimits.isUnlimited || sitesUsed < planLimits.sites;

  // Estatísticas principais com design clean
  const mainStats = [
    {
      title: 'Sites Ativos',
      value: activeSites.length,
      maxValue: planLimits.isUnlimited ? '∞' : planLimits.sites,
      icon: Monitor,
      description: 'Publicando conteúdo',
      isUnlimited: planLimits.isUnlimited
    },
    {
      title: 'Sites WordPress',
      value: connectedWordPressSites.length,
      maxValue: activeSites.length,
      icon: Wifi,
      description: 'Integração ativa',
      isUnlimited: false
    },
    {
      title: 'Total de Artigos',
      value: totalArticles,
      icon: FileText,
      description: 'Em todos os sites',
      isUnlimited: true
    },
    {
      title: 'Sites Pausados',
      value: pausedSites.length,
      icon: XCircle,
      description: 'Temporariamente inativos',
      isUnlimited: true
    }
  ];

  return (
    <div className="space-y-8">
      {/* Header Clean */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div>
          <h1 className="font-poppins text-2xl text-black mb-2">
            Meus Sites
          </h1>
          <p className="font-montserrat text-gray-600">
            Gerencie seus sites WordPress para publicação automática de conteúdo
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Badge 
            variant="outline"
            className="px-3 py-1 font-montserrat text-gray-700 border-gray-200"
          >
            {sitesUsed}/{planLimits.isUnlimited ? '∞' : sitesLimit} sites
          </Badge>
          <Button 
            onClick={() => setShowAddForm(true)}
            disabled={!canAddSite}
            className="font-montserrat disabled:bg-gray-300"
            style={{ backgroundColor: '#8B5FBF' }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Conectar Site
          </Button>
        </div>
      </div>

      {/* Alerta sobre limite - mostrar apenas quando realmente atingiu o limite */}
      {!canAddSite && !planLimits.isUnlimited && (
        <Card className="border border-orange-200 bg-orange-50">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="flex items-center justify-center w-10 h-10 bg-orange-100 rounded-lg flex-shrink-0">
                <AlertCircle className="h-5 w-5" style={{ color: '#8B5FBF' }} />
              </div>
              <div className="flex-1">
                <h3 className="font-poppins text-lg text-orange-800 mb-2">
                  Limite de Sites Atingido
                </h3>
                <p className="font-montserrat text-orange-700 mb-4">
                  Você atingiu o limite de <strong>{sitesLimit} sites</strong> do seu plano atual. 
                  Para conectar mais sites, faça upgrade para um plano superior.
                </p>
                <Button
                  onClick={() => window.location.hash = 'store'}
                  variant="outline"
                  className="font-montserrat border-orange-300 text-orange-700 hover:bg-orange-100"
                >
                  Ver Planos Disponíveis
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Estatísticas Clean */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {mainStats.map((stat, index) => {
          const Icon = stat.icon;
          const progressValue = !stat.isUnlimited && stat.maxValue && stat.maxValue !== '∞' ? 
            Math.min(100, (stat.value / Number(stat.maxValue)) * 100) : 0;
          
          return (
            <Card 
              key={index} 
              className="border border-gray-200 hover:shadow-md transition-all"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                    <Icon size={20} style={{ color: '#8B5FBF' }} />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="font-montserrat text-sm text-gray-600">
                    {stat.title}
                  </div>
                  
                  <div className="font-poppins text-2xl text-black">
                    {stat.value}{stat.maxValue && stat.maxValue !== '∞' ? `/${stat.maxValue}` : ''}
                  </div>
                  
                  <div className="font-montserrat text-xs text-gray-500">
                    {stat.description}
                  </div>

                  {/* Progress Bar para limites */}
                  {!stat.isUnlimited && stat.maxValue && stat.maxValue !== '∞' && (
                    <div className="pt-2">
                      <Progress 
                        value={progressValue} 
                        className="h-1.5"
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Formulário de adicionar site */}
      {showAddForm && (
        <Card className="border border-gray-200">
          <CardHeader className="pb-4">
            <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
              <Plus size={20} style={{ color: '#8B5FBF' }} />
              Conectar Novo Site
            </CardTitle>
            <p className="font-montserrat text-gray-600">
              Adicione os dados básicos do seu site WordPress. Após salvar, você poderá configurar a integração completa.
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="siteName" className="font-montserrat text-black">Nome do Site *</Label>
                <Input
                  id="siteName"
                  value={newSite.nome}
                  onChange={(e) => setNewSite({ ...newSite, nome: e.target.value })}
                  placeholder="Ex: MeuBlog.com"
                  className="font-montserrat"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="siteUrl" className="font-montserrat text-black">URL do Site</Label>
                <Input
                  id="siteUrl"
                  value={newSite.url}
                  onChange={(e) => setNewSite({ ...newSite, url: e.target.value })}
                  placeholder="https://meublog.com"
                  className="font-montserrat"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="siteStatus" className="font-montserrat text-black">Status Inicial</Label>
              <Select value={newSite.status} onValueChange={(value) => setNewSite({ ...newSite, status: value as 'ativo' | 'inativo' })}>
                <SelectTrigger className="font-montserrat">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">Ativo</SelectItem>
                  <SelectItem value="inativo">Pausado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex space-x-3 pt-4 border-t border-gray-200">
              <Button 
                onClick={handleAddSite} 
                className="font-montserrat text-white"
                style={{ backgroundColor: '#8B5FBF' }}
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                Salvar Site
              </Button>
              <Button 
                onClick={() => setShowAddForm(false)} 
                variant="outline" 
                className="font-montserrat"
              >
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Formulário WordPress */}
      {showWordPressForm !== null && (
        <Card className="border border-gray-200">
          <CardHeader className="pb-4">
            <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
              <Settings size={20} style={{ color: '#8B5FBF' }} />
              Configurar Integração WordPress
            </CardTitle>
            <p className="font-montserrat text-gray-600">
              Configure a conexão para publicação automática no seu site WordPress
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert className="border-purple-200 bg-purple-50">
              <Lightbulb className="h-5 w-5" style={{ color: '#8B5FBF' }} />
              <AlertDescription className="text-purple-800">
                <strong>Como obter uma Application Password:</strong><br />
                1. Acesse: <em>Painel WordPress → Usuários → Perfil</em><br />
                2. Role até <em>"Application Passwords"</em><br />
                3. Digite um nome (ex: "BIA") e clique <em>"Add New"</em><br />
                4. Copie a senha gerada completa e cole abaixo
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 gap-6">
              <div className="space-y-2">
                <Label htmlFor="wpUrl" className="font-montserrat text-black">URL do Site *</Label>
                <Input
                  id="wpUrl"
                  value={wordpressCredentials.url}
                  onChange={(e) => setWordpressCredentials({ ...wordpressCredentials, url: e.target.value })}
                  placeholder="https://meublog.com"
                  className="font-montserrat"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="wpUsername" className="font-montserrat text-black">Nome de Usuário *</Label>
                <Input
                  id="wpUsername"
                  value={wordpressCredentials.username}
                  onChange={(e) => setWordpressCredentials({ ...wordpressCredentials, username: e.target.value })}
                  placeholder="admin"
                  className="font-montserrat"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="wpPassword" className="font-montserrat text-black">Application Password *</Label>
                <Input
                  id="wpPassword"
                  type="password"
                  value={wordpressCredentials.applicationPassword}
                  onChange={(e) => setWordpressCredentials({ ...wordpressCredentials, applicationPassword: e.target.value })}
                  placeholder="xxxx xxxx xxxx xxxx xxxx xxxx"
                  className="font-montserrat"
                />
                <p className="font-montserrat text-xs text-gray-500">
                  ⚠️ NÃO use sua senha normal do WordPress. Use apenas Application Password.
                </p>
              </div>
            </div>

            <div className="flex space-x-3 pt-4 border-t border-gray-200">
              <Button 
                onClick={() => handleConnectWordPress(showWordPressForm)}
                disabled={connectingWP}
                className="font-montserrat text-white"
                style={{ backgroundColor: '#8B5FBF' }}
              >
                {connectingWP ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testando conexão...
                  </>
                ) : (
                  <>
                    <Wifi className="mr-2 h-4 w-4" />
                    Conectar WordPress
                  </>
                )}
              </Button>
              <Button 
                onClick={() => {
                  setShowWordPressForm(null);
                  setWordpressCredentials({ url: '', username: '', applicationPassword: '' });
                }} 
                variant="outline" 
                className="font-montserrat"
              >
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lista de Sites Clean */}
      <div className="space-y-4">
        {state.sites.length === 0 ? (
          <Card className="border border-gray-200">
            <CardContent className="p-12 text-center">
              <div className="flex items-center justify-center w-16 h-16 bg-purple-50 rounded-full mx-auto mb-6">
                <Monitor size={32} style={{ color: '#8B5FBF' }} />
              </div>
              <h3 className="font-poppins text-xl text-black mb-2">
                Nenhum site conectado ainda
              </h3>
              <p className="font-montserrat text-gray-600 mb-6 max-w-md mx-auto">
                Conecte seu primeiro site WordPress para começar a publicar conteúdo automaticamente.
              </p>
              <Button
                onClick={() => setShowAddForm(true)}
                disabled={!canAddSite}
                className="font-montserrat text-white"
                style={{ backgroundColor: '#8B5FBF' }}
              >
                <Plus className="mr-2 h-4 w-4" />
                Conectar Primeiro Site
              </Button>
            </CardContent>
          </Card>
        ) : (
          state.sites.map((site) => {
            const siteStats = siteArticles.find(s => s.id === site.id);
            const articleCount = siteStats?.articleCount || 0;
            const isConnected = !!site.wordpressUrl;
            const isActive = site.status === 'ativo';
            
            return (
              <Card 
                key={site.id} 
                className="border border-gray-200 hover:shadow-md transition-all"
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center flex-shrink-0">
                        {isConnected ? (
                          <Wifi size={24} className={isActive ? 'text-green-600' : 'text-gray-500'} />
                        ) : (
                          <Monitor size={24} style={{ color: isActive ? '#8B5FBF' : '#9CA3AF' }} />
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-poppins text-lg text-black truncate">
                            {site.nome}
                          </h3>
                          <Badge 
                            variant="outline"
                            className={`text-xs font-montserrat ${
                              isActive 
                                ? 'border-green-200 text-green-700 bg-green-50' 
                                : 'border-gray-200 text-gray-600 bg-gray-50'
                            }`}
                          >
                            {isActive ? 'Ativo' : 'Pausado'}
                          </Badge>
                          {isConnected && (
                            <Badge 
                              variant="outline"
                              className="border-blue-200 text-blue-700 bg-blue-50 text-xs font-montserrat"
                            >
                              <Wifi size={10} className="mr-1" />
                              WordPress
                            </Badge>
                          )}
                        </div>
                        
                        {site.url && (
                          <div className="flex items-center gap-2 mb-2">
                            <Globe size={14} className="text-gray-400 flex-shrink-0" />
                            <a 
                              href={site.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="font-montserrat text-sm text-blue-600 hover:underline truncate"
                            >
                              {site.url}
                            </a>
                            <ExternalLink size={12} className="text-gray-400" />
                          </div>
                        )}
                        
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <FileText size={14} className="text-gray-400" />
                            <span className="font-montserrat">{articleCount} artigos</span>
                          </div>
                          {site.createdAt && (
                            <div className="flex items-center gap-1">
                              <Clock size={14} className="text-gray-400" />
                              <span className="font-montserrat">
                                Criado {formatDate(site.createdAt)}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Button
                        onClick={() => handleToggleStatus(site)}
                        variant="outline"
                        size="sm"
                        className={`font-montserrat ${
                          isActive 
                            ? 'border-orange-300 text-orange-700 hover:bg-orange-50' 
                            : 'border-green-300 text-green-700 hover:bg-green-50'
                        }`}
                      >
                        {isActive ? (
                          <>
                            <XCircle size={14} className="mr-1" />
                            Pausar
                          </>
                        ) : (
                          <>
                            <CheckCircle size={14} className="mr-1" />
                            Ativar
                          </>
                        )}
                      </Button>
                      
                      {!isConnected ? (
                        <Button
                          onClick={() => handleStartWordPressIntegration(site.id)}
                          size="sm"
                          className="font-montserrat text-white"
                          style={{ backgroundColor: '#8B5FBF' }}
                        >
                          <Settings size={14} className="mr-1" />
                          Conectar WP
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handleStartWordPressIntegration(site.id)}
                          variant="outline"
                          size="sm"
                          className="font-montserrat border-purple-200 text-purple-700 hover:bg-purple-50"
                        >
                          <Settings size={14} className="mr-1" />
                          Configurar
                        </Button>
                      )}
                      
                      <Button
                        onClick={() => handleRemoveSite(site)}
                        variant="outline"
                        size="sm"
                        className="font-montserrat border-red-200 text-red-700 hover:bg-red-50"
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}