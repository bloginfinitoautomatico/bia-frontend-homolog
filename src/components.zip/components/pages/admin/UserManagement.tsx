import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card';
import { Button } from '../../ui/button';
import { Input } from '../../ui/input';
import { Badge } from '../../ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../ui/table';
import { Alert, AlertDescription } from '../../ui/alert';
import { 
  Users, 
  Search, 
  Filter, 
  RefreshCw, 
  Edit3, 
  Eye, 
  UserPlus, 
  Shield,
  Calendar,
  Mail,
  MessageCircle,
  CreditCard,
  AlertCircle,
  CheckCircle,
  Loader2,
  Database
} from '../../icons';
import { UserEditor } from './UserEditor';
import { toast } from 'sonner';

interface User {
  id: string;
  name: string;
  email: string;
  cpf?: string;
  whatsapp?: string;
  dataNascimento?: string;
  plano: string;
  status: string;
  createdAt: string;
  lastLogin?: string;
  updatedAt?: string;
  uniqueKey?: string;
}

interface UserManagementProps {
  onUpdateUser?: (userData: any) => Promise<boolean>;
}

export function UserManagement({ onUpdateUser }: UserManagementProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPlan, setSelectedPlan] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [isInitializing, setIsInitializing] = useState(false);
  const [error, setError] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showUserEditor, setShowUserEditor] = useState(false);
  const [initializationStep, setInitializationStep] = useState('');

  // Carregar usuários
  useEffect(() => {
    loadUsers();
  }, []);

  // Filtrar usuários quando os filtros mudarem
  useEffect(() => {
    filterUsers();
  }, [users, searchTerm, selectedPlan, selectedStatus]);

  const loadUsers = async () => {
    setIsLoading(true);
    setError('');

    try {
      console.log('👥 Carregando lista de usuários para admin...');

      const { projectId, publicAnonKey } = await import('../../../utils/supabase/info');

      // Carregar usuários via rota admin
      console.log('🔗 Fazendo requisição para /admin/users...');
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-53322c0b/admin/users`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      console.log('📡 Resposta recebida:', {
        status: response.status,
        ok: response.ok,
        statusText: response.statusText
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Erro na resposta:', errorText);
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const result = await response.json();
      console.log('📋 Resultado completo:', result);

      if (result.success && result.users) {
        console.log(`✅ ${result.users.length} usuários carregados do servidor`);
        
        // Validar estrutura dos dados recebidos
        const validUsers = result.users.filter((user: any) => {
          const isValid = user && user.id && user.email;
          if (!isValid) {
            console.warn('⚠️ Usuário inválido encontrado:', user);
          }
          return isValid;
        });

        console.log(`📊 ${validUsers.length} usuários válidos encontrados`);

        // Processar usuários e garantir IDs únicos para keys do React
        const processedUsers = validUsers.map((user: any, index: number) => {
          console.log(`🔄 Processando usuário ${index + 1}:`, {
            id: user.id,
            email: user.email,
            name: user.name,
            plano: user.plano
          });

          return {
            id: user.id,
            name: user.name || 'Nome não informado',
            email: user.email,
            plano: user.plano || 'Free',
            status: user.status || 'active',
            createdAt: user.created_at || new Date().toISOString(),
            lastLogin: user.last_login,
            updatedAt: user.updated_at,
            cpf: user.cpf,
            whatsapp: user.whatsapp,
            dataNascimento: user.data_nascimento,
            // Criar chave única para React
            uniqueKey: `${user.id}_${index}_${Date.now()}`
          };
        });
        
        // Remover usuários duplicados baseado no email (manter o mais recente)
        const uniqueUsers = processedUsers.reduce((acc: User[], current: any) => {
          const existingIndex = acc.findIndex(user => user.email === current.email);
          if (existingIndex >= 0) {
            // Se já existe um usuário com este email, manter o mais recente
            const existingUser = acc[existingIndex];
            const currentDate = new Date(current.updatedAt || current.createdAt || 0);
            const existingDate = new Date(existingUser.updatedAt || existingUser.createdAt || 0);
            
            if (currentDate > existingDate) {
              acc[existingIndex] = current; // Substituir pelo mais recente
              console.log(`🔄 Usuário ${current.email} atualizado (mais recente)`);
            } else {
              console.log(`⏭️ Usuário ${current.email} ignorado (mais antigo)`);
            }
          } else {
            acc.push(current); // Adicionar se não existe
            console.log(`➕ Usuário ${current.email} adicionado`);
          }
          return acc;
        }, []);
        
        console.log(`📊 Resultado final: ${uniqueUsers.length} usuários únicos`);
        console.log('📋 Lista final de usuários:', uniqueUsers.map(u => ({ email: u.email, name: u.name, plano: u.plano })));
        
        setUsers(uniqueUsers);
        setError(''); // Limpar erros anteriores

        if (uniqueUsers.length === 0) {
          console.log('⚠️ Nenhum usuário encontrado no sistema');
          toast.info('Nenhum usuário encontrado no sistema.');
        } else {
          toast.success(`${uniqueUsers.length} usuários carregados com sucesso`);
        }
      } else {
        console.error('❌ Resposta inválida:', result);
        throw new Error(result.error || 'Resposta inválida do servidor');
      }

    } catch (error) {
      console.error('❌ Erro ao carregar usuários:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      setError('Erro ao carregar lista de usuários: ' + errorMessage);
      toast.error('Erro ao carregar usuários: ' + errorMessage);
      
      // Definir array vazio em caso de erro
      setUsers([]);
    } finally {
      setIsLoading(false);
    }
  };

  const initializeAdminUser = async () => {
    setIsInitializing(true);
    setInitializationStep('Criando usuário administrador...');
    
    try {
      console.log('👑 Inicializando usuário administrador...');

      const { projectId, publicAnonKey } = await import('../../../utils/supabase/info');

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-53322c0b/admin/init-admin`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();

      if (result.success) {
        console.log('✅ Usuário admin inicializado:', result);
        
        toast.success(`Admin ${result.action === 'created' ? 'criado' : 'atualizado'} com sucesso!`);
        
        // Mostrar credenciais do admin se foram fornecidas
        if (result.credentials) {
          toast.info(`Email: ${result.credentials.email} | Senha: ${result.credentials.password}`, {
            duration: 10000,
            description: 'Salve essas credenciais em local seguro!'
          });
        }

        // Recarregar lista de usuários
        setTimeout(loadUsers, 1000);
        
      } else {
        throw new Error(result.error || 'Erro ao inicializar admin');
      }

    } catch (error) {
      console.error('❌ Erro ao inicializar admin:', error);
      toast.error('Erro ao inicializar usuário administrador');
      setError('Erro ao inicializar admin: ' + error.message);
    } finally {
      setIsInitializing(false);
      setInitializationStep('');
    }
  };

  const filterUsers = () => {
    let filtered = [...users];

    // Filtro por busca (nome, email, CPF)
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(user => 
        user.name?.toLowerCase().includes(search) ||
        user.email?.toLowerCase().includes(search) ||
        user.cpf?.includes(search)
      );
    }

    // Filtro por plano
    if (selectedPlan !== 'all') {
      filtered = filtered.filter(user => user.plano === selectedPlan);
    }

    // Filtro por status
    if (selectedStatus !== 'all') {
      filtered = filtered.filter(user => user.status === selectedStatus);
    }

    setFilteredUsers(filtered);
  };

  const handleEditUser = (user: User) => {
    setSelectedUser(user);
    setShowUserEditor(true);
  };

  const handleUserUpdated = (updatedUser: User) => {
    setUsers(prevUsers => 
      prevUsers.map(user => 
        user.id === updatedUser.id ? { ...updatedUser, uniqueKey: user.uniqueKey } : user
      )
    );
    toast.success('Usuário atualizado com sucesso!');
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Nunca';
    try {
      return new Date(dateString).toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      return 'Data inválida';
    }
  };

  const getPlanBadge = (plan: string) => {
    const planColors = {
      'Free': 'bg-gray-500',
      'Básico': 'bg-blue-500',
      'Intermediário': 'bg-purple-500',
      'Avançado': 'bg-green-500',
      'BIA': 'bg-orange-500',
      'Custom': 'bg-pink-500'
    };
    
    return (
      <Badge className={`${planColors[plan] || 'bg-gray-500'} text-white`}>
        <Shield className="h-3 w-3 mr-1" />
        {plan}
      </Badge>
    );
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      'active': 'bg-green-500',
      'inactive': 'bg-gray-500',
      'suspended': 'bg-red-500'
    };

    const statusLabels = {
      'active': 'Ativo',
      'inactive': 'Inativo',
      'suspended': 'Suspenso'
    };

    const Icon = status === 'active' ? CheckCircle : AlertCircle;
    
    return (
      <Badge className={`${statusColors[status] || 'bg-gray-500'} text-white`}>
        <Icon className="h-3 w-3 mr-1" />
        {statusLabels[status] || status}
      </Badge>
    );
  };

  // Estatísticas rápidas
  const totalUsers = users.length;
  const activeUsers = users.filter(u => u.status === 'active').length;
  const freeUsers = users.filter(u => u.plano === 'Free').length;
  const paidUsers = users.filter(u => u.plano !== 'Free').length;

  if (showUserEditor && selectedUser) {
    return (
      <UserEditor
        user={selectedUser}
        onClose={() => {
          setShowUserEditor(false);
          setSelectedUser(null);
        }}
        onUserUpdated={handleUserUpdated}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-poppins text-3xl text-black">Gerenciamento de Usuários</h2>
          <p className="font-montserrat text-gray-600">
            Gerencie usuários, planos e créditos da plataforma
          </p>
        </div>
        <div className="flex space-x-2">
          {users.length === 0 && !isLoading && (
            <Button 
              onClick={initializeAdminUser} 
              disabled={isInitializing}
              className="font-montserrat bg-purple-600 hover:bg-purple-700 text-white"
            >
              {isInitializing ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <UserPlus className="h-4 w-4 mr-2" />
              )}
              {isInitializing ? 'Inicializando...' : 'Criar Admin'}
            </Button>
          )}
          <Button 
            onClick={loadUsers} 
            disabled={isLoading}
            className="font-montserrat"
            variant="outline"
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4 mr-2" />
            )}
            Atualizar
          </Button>
        </div>
      </div>

      {/* Status de inicialização */}
      {isInitializing && initializationStep && (
        <Alert className="border-blue-200 bg-blue-50">
          <Database className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-700">
            {initializationStep}
          </AlertDescription>
        </Alert>
      )}

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-blue-600" />
              <div>
                <p className="font-poppins text-2xl font-bold text-blue-600">{totalUsers}</p>
                <p className="font-montserrat text-sm text-gray-600">Total de Usuários</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-8 w-8 text-green-600" />
              <div>
                <p className="font-poppins text-2xl font-bold text-green-600">{activeUsers}</p>
                <p className="font-montserrat text-sm text-gray-600">Usuários Ativos</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-purple-600" />
              <div>
                <p className="font-poppins text-2xl font-bold text-purple-600">{paidUsers}</p>
                <p className="font-montserrat text-sm text-gray-600">Planos Pagos</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <UserPlus className="h-8 w-8 text-gray-600" />
              <div>
                <p className="font-poppins text-2xl font-bold text-gray-600">{freeUsers}</p>
                <p className="font-montserrat text-sm text-gray-600">Planos Gratuitos</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      {users.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Buscar por nome, email ou CPF..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 font-montserrat"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <select
                  value={selectedPlan}
                  onChange={(e) => setSelectedPlan(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-md font-montserrat text-sm"
                >
                  <option value="all">Todos os Planos</option>
                  <option value="Free">Gratuito</option>
                  <option value="Básico">Básico</option>
                  <option value="Intermediário">Intermediário</option>
                  <option value="Avançado">Avançado</option>
                  <option value="BIA">BIA Premium</option>
                  <option value="Custom">Personalizado</option>
                </select>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-md font-montserrat text-sm"
                >
                  <option value="all">Todos os Status</option>
                  <option value="active">Ativo</option>
                  <option value="inactive">Inativo</option>
                  <option value="suspended">Suspenso</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Alertas */}
      {error && (
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-700">
            {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Debug Info */}
      {!isLoading && !error && (
        <Alert className="border-blue-200 bg-blue-50">
          <CheckCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-700 font-montserrat">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
              <div>
                <span className="font-medium">Status:</span> {users.length > 0 ? 'Carregado' : 'Vazio'}
              </div>
              <div>
                <span className="font-medium">Total:</span> {users.length} usuários
              </div>
              <div>
                <span className="font-medium">Filtrados:</span> {filteredUsers.length} usuários
              </div>
              <div>
                <span className="font-medium">Última Atualização:</span> {new Date().toLocaleTimeString('pt-BR')}
              </div>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Tabela de Usuários */}
      <Card>
        <CardHeader>
          <CardTitle className="font-poppins flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-purple-600" />
              <span>Lista de Usuários ({filteredUsers.length})</span>
            </div>
            <div className="text-sm font-montserrat text-gray-500">
              Total: {users.length} | Filtrados: {filteredUsers.length}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
              <span className="ml-2 font-montserrat">Carregando usuários...</span>
            </div>
          ) : error ? (
            <div className="text-center p-8">
              <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-4" />
              <h3 className="font-poppins text-lg text-red-600 mb-2">Erro ao Carregar Usuários</h3>
              <p className="font-montserrat text-gray-500 mb-4">
                {error}
              </p>
              <Button 
                onClick={() => loadUsers()} 
                className="font-montserrat bg-purple-600 hover:bg-purple-700 text-white"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Tentar Novamente
              </Button>
            </div>
          ) : users.length === 0 ? (
            <div className="text-center p-8">
              <Database className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="font-poppins text-lg text-gray-600 mb-2">Sistema não inicializado</h3>
              <p className="font-montserrat text-gray-500 mb-4">
                Nenhum usuário encontrado no sistema. Clique em "Criar Admin" para inicializar o sistema com um usuário administrador.
              </p>
              <Button 
                onClick={initializeAdminUser} 
                disabled={isInitializing}
                className="font-montserrat bg-purple-600 hover:bg-purple-700 text-white"
              >
                {isInitializing ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <UserPlus className="h-4 w-4 mr-2" />
                )}
                {isInitializing ? 'Inicializando Sistema...' : 'Criar Usuário Administrador'}
              </Button>
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center p-8">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="font-poppins text-lg text-gray-600 mb-2">Nenhum usuário encontrado</h3>
              <p className="font-montserrat text-gray-500 mb-4">
                {searchTerm || selectedPlan !== 'all' || selectedStatus !== 'all' 
                  ? 'Tente ajustar os filtros de busca' 
                  : 'Nenhum usuário encontrado nos filtros atuais'
                }
              </p>
              <div className="text-sm font-montserrat text-gray-400">
                Total de usuários no sistema: {users.length}
              </div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="font-montserrat">Usuário</TableHead>
                  <TableHead className="font-montserrat">Contato</TableHead>
                  <TableHead className="font-montserrat">Plano</TableHead>
                  <TableHead className="font-montserrat">Status</TableHead>
                  <TableHead className="font-montserrat">Último Login</TableHead>
                  <TableHead className="font-montserrat">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user, index) => {
                  console.log(`🎨 Renderizando usuário na tabela: ${user.email}`);
                  
                  return (
                    <TableRow key={user.uniqueKey || `${user.id}_${index}`}>
                      <TableCell>
                        <div>
                          <p className="font-montserrat font-medium">
                            {user.name || 'Nome não informado'}
                          </p>
                          <p className="font-montserrat text-sm text-gray-600">
                            {user.email}
                          </p>
                          {user.cpf && (
                            <p className="font-montserrat text-xs text-gray-500">
                              CPF: {user.cpf}
                            </p>
                          )}
                          <p className="font-montserrat text-xs text-gray-400">
                            ID: {user.id}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center space-x-1">
                            <Mail className="h-3 w-3 text-gray-400" />
                            <span className="font-montserrat text-xs text-gray-600 truncate max-w-[150px]">
                              {user.email}
                            </span>
                          </div>
                          {user.whatsapp ? (
                            <div className="flex items-center space-x-1">
                              <MessageCircle className="h-3 w-3 text-gray-400" />
                              <span className="font-montserrat text-xs text-gray-600">
                                {user.whatsapp}
                              </span>
                            </div>
                          ) : (
                            <div className="flex items-center space-x-1">
                              <MessageCircle className="h-3 w-3 text-gray-300" />
                              <span className="font-montserrat text-xs text-gray-400">
                                Não informado
                              </span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {getPlanBadge(user.plano)}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(user.status)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-3 w-3 text-gray-400" />
                          <span className="font-montserrat text-sm text-gray-600">
                            {formatDate(user.lastLogin)}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditUser(user)}
                            className="font-montserrat"
                          >
                            <Edit3 className="h-3 w-3 mr-1" />
                            Editar
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}