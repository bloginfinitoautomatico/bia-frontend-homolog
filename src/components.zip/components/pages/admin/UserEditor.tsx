import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../ui/card';
import { Button } from '../../ui/button';
import { Input } from '../../ui/input';
import { Label } from '../../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../ui/select';
import { Alert, AlertDescription } from '../../ui/alert';
import { Badge } from '../../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../../ui/dialog';
import { 
  User, 
  Edit3, 
  Save, 
  XCircle, 
  AlertCircle, 
  CheckCircle, 
  CreditCard, 
  Calendar,
  Star,
  Shield,
  Loader2
} from '../../icons';
import { toast } from 'sonner';

interface UserEditorProps {
  user: any;
  onClose: () => void;
  onUserUpdated: (updatedUser: any) => void;
}

interface UserCredits {
  ideas: number;
  articles: number;
  sites: number;
  validUntil?: string;
  notes?: string;
}

export function UserEditor({ user, onClose, onUserUpdated }: UserEditorProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  
  // Estados dos dados do usuário
  const [userData, setUserData] = useState({
    name: user.name || '',
    email: user.email || '',
    cpf: user.cpf || '',
    whatsapp: user.whatsapp || '',
    dataNascimento: user.dataNascimento || '',
    plano: user.plano || 'Free',
    status: user.status || 'active'
  });

  // Estados dos créditos extras
  const [userCredits, setUserCredits] = useState<UserCredits>({
    ideas: 0,
    articles: 0,
    sites: 0,
    validUntil: '',
    notes: ''
  });

  // Estados para consumo atual
  const [currentConsumption, setCurrentConsumption] = useState({
    ideasUsed: 0,
    articlesUsed: 0,
    sitesUsed: 0
  });

  const [showCreditsModal, setShowCreditsModal] = useState(false);

  // Opções de planos disponíveis
  const planOptions = [
    { value: 'Free', label: 'Gratuito', color: 'bg-gray-500' },
    { value: 'Básico', label: 'Básico', color: 'bg-blue-500' },
    { value: 'Intermediário', label: 'Intermediário', color: 'bg-purple-500' },
    { value: 'Avançado', label: 'Avançado', color: 'bg-green-500' },
    { value: 'BIA', label: 'BIA Premium', color: 'bg-orange-500' },
    { value: 'Custom', label: 'Plano Personalizado', color: 'bg-pink-500' }
  ];

  // Carregar dados do usuário e consumo ao montar componente
  useEffect(() => {
    loadUserDetails();
  }, [user.id]);

  const loadUserDetails = async () => {
    setIsLoading(true);
    setError('');

    try {
      console.log('📊 Carregando detalhes do usuário:', user.email);

      const { projectId, publicAnonKey } = await import('../../../utils/supabase/info');

      // Carregar consumo atual
      const consumptionResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-53322c0b/users/consumption/${user.id}`,
        {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        }
      );

      if (consumptionResponse.ok) {
        const consumptionResult = await consumptionResponse.json();
        if (consumptionResult.success) {
          setCurrentConsumption({
            ideasUsed: consumptionResult.consumption.ideasUsed || 0,
            articlesUsed: consumptionResult.consumption.articlesUsed || 0,
            sitesUsed: consumptionResult.consumption.sitesUsed || 0
          });
        }
      }

      // Carregar créditos extras (se existirem)
      const creditsResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-53322c0b/admin/user-credits/${user.id}`,
        {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        }
      );

      if (creditsResponse.ok) {
        const creditsResult = await creditsResponse.json();
        if (creditsResult.success && creditsResult.credits) {
          setUserCredits(creditsResult.credits);
        }
      }

    } catch (error) {
      console.error('❌ Erro ao carregar detalhes do usuário:', error);
      setError('Erro ao carregar dados do usuário');
    } finally {
      setIsLoading(false);
    }
  };

  // Atualizar dados básicos do usuário
  const handleSaveUser = async () => {
    setIsSaving(true);
    setError('');

    try {
      console.log('💾 Salvando dados do usuário:', userData.email);

      const { projectId, publicAnonKey } = await import('../../../utils/supabase/info');

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-53322c0b/admin/update-user`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            userId: user.id,
            updates: {
              name: userData.name,
              cpf: userData.cpf,
              whatsapp: userData.whatsapp,
              dataNascimento: userData.dataNascimento,
              plano: userData.plano,
              status: userData.status
            }
          })
        }
      );

      const result = await response.json();

      if (result.success) {
        console.log('✅ Usuário atualizado com sucesso');
        toast.success('Dados do usuário atualizados com sucesso!');
        
        // Notificar componente pai sobre a atualização
        onUserUpdated({
          ...user,
          ...userData,
          updatedAt: new Date().toISOString()
        });
      } else {
        throw new Error(result.error || 'Erro ao atualizar usuário');
      }

    } catch (error) {
      console.error('❌ Erro ao salvar usuário:', error);
      setError('Erro ao salvar alterações: ' + error.message);
      toast.error('Erro ao salvar alterações');
    } finally {
      setIsSaving(false);
    }
  };

  // Salvar créditos extras
  const handleSaveCredits = async () => {
    setIsSaving(true);
    setError('');

    try {
      console.log('💳 Salvando créditos extras para usuário:', user.email);

      const { projectId, publicAnonKey } = await import('../../../utils/supabase/info');

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-53322c0b/admin/set-user-credits`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            userId: user.id,
            credits: {
              ideas: parseInt(userCredits.ideas.toString()) || 0,
              articles: parseInt(userCredits.articles.toString()) || 0,
              sites: parseInt(userCredits.sites.toString()) || 0,
              validUntil: userCredits.validUntil || null,
              notes: userCredits.notes || '',
              grantedAt: new Date().toISOString(),
              grantedBy: 'admin' // Você pode personalizar isso
            }
          })
        }
      );

      const result = await response.json();

      if (result.success) {
        console.log('✅ Créditos atualizados com sucesso');
        toast.success('Créditos atualizados com sucesso!');
        setShowCreditsModal(false);
        
        // Recarregar dados
        loadUserDetails();
      } else {
        throw new Error(result.error || 'Erro ao atualizar créditos');
      }

    } catch (error) {
      console.error('❌ Erro ao salvar créditos:', error);
      setError('Erro ao salvar créditos: ' + error.message);
      toast.error('Erro ao salvar créditos');
    } finally {
      setIsSaving(false);
    }
  };

  // Resetar consumo do usuário
  const handleResetConsumption = async () => {
    if (!confirm('Tem certeza que deseja resetar o consumo deste usuário? Esta ação não pode ser desfeita.')) {
      return;
    }

    setIsSaving(true);
    setError('');

    try {
      console.log('🔄 Resetando consumo do usuário:', user.email);

      const { projectId, publicAnonKey } = await import('../../../utils/supabase/info');

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-53322c0b/admin/reset-user-consumption`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            userId: user.id
          })
        }
      );

      const result = await response.json();

      if (result.success) {
        console.log('✅ Consumo resetado com sucesso');
        toast.success('Consumo do usuário resetado com sucesso!');
        
        // Recarregar dados
        loadUserDetails();
      } else {
        throw new Error(result.error || 'Erro ao resetar consumo');
      }

    } catch (error) {
      console.error('❌ Erro ao resetar consumo:', error);
      setError('Erro ao resetar consumo: ' + error.message);
      toast.error('Erro ao resetar consumo');
    } finally {
      setIsSaving(false);
    }
  };

  const getPlanBadgeColor = (plan: string) => {
    const planOption = planOptions.find(p => p.value === plan);
    return planOption?.color || 'bg-gray-500';
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'Não definido';
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  if (isLoading) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="p-6">
          <div className="flex items-center justify-center space-x-2">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span className="font-montserrat">Carregando dados do usuário...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div className="flex items-center space-x-3">
            <User className="h-6 w-6 text-purple-600" />
            <div>
              <CardTitle className="font-poppins text-xl">Editar Usuário</CardTitle>
              <p className="font-montserrat text-sm text-gray-600">{user.email}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge className={`${getPlanBadgeColor(userData.plano)} text-white`}>
              <Shield className="h-3 w-3 mr-1" />
              {userData.plano}
            </Badge>
            <Button variant="outline" size="sm" onClick={onClose}>
              <XCircle className="h-4 w-4 mr-1" />
              Fechar
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Alertas */}
      {error && (
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-700">
            {error}
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Dados Básicos */}
        <Card>
          <CardHeader>
            <CardTitle className="font-poppins flex items-center space-x-2">
              <Edit3 className="h-5 w-5 text-purple-600" />
              <span>Dados Básicos</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="font-montserrat">Nome Completo</Label>
              <Input
                value={userData.name}
                onChange={(e) => setUserData(prev => ({ ...prev, name: e.target.value }))}
                className="font-montserrat"
                placeholder="Nome completo do usuário"
              />
            </div>

            <div>
              <Label className="font-montserrat">Email (somente leitura)</Label>
              <Input
                value={userData.email}
                disabled
                className="font-montserrat bg-gray-100"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-montserrat">CPF</Label>
                <Input
                  value={userData.cpf}
                  onChange={(e) => setUserData(prev => ({ ...prev, cpf: e.target.value }))}
                  className="font-montserrat"
                  placeholder="000.000.000-00"
                />
              </div>
              <div>
                <Label className="font-montserrat">WhatsApp</Label>
                <Input
                  value={userData.whatsapp}
                  onChange={(e) => setUserData(prev => ({ ...prev, whatsapp: e.target.value }))}
                  className="font-montserrat"
                  placeholder="(11) 99999-9999"
                />
              </div>
            </div>

            <div>
              <Label className="font-montserrat">Data de Nascimento</Label>
              <Input
                type="date"
                value={userData.dataNascimento}
                onChange={(e) => setUserData(prev => ({ ...prev, dataNascimento: e.target.value }))}
                className="font-montserrat"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-montserrat">Plano</Label>
                <Select
                  value={userData.plano}
                  onValueChange={(value) => setUserData(prev => ({ ...prev, plano: value }))}
                >
                  <SelectTrigger className="font-montserrat">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {planOptions.map(plan => (
                      <SelectItem key={plan.value} value={plan.value} className="font-montserrat">
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full ${plan.color}`}></div>
                          <span>{plan.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="font-montserrat">Status</Label>
                <Select
                  value={userData.status}
                  onValueChange={(value) => setUserData(prev => ({ ...prev, status: value }))}
                >
                  <SelectTrigger className="font-montserrat">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active" className="font-montserrat">Ativo</SelectItem>
                    <SelectItem value="inactive" className="font-montserrat">Inativo</SelectItem>
                    <SelectItem value="suspended" className="font-montserrat">Suspenso</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button 
              onClick={handleSaveUser} 
              disabled={isSaving}
              className="w-full font-montserrat text-white"
              style={{ backgroundColor: '#8B5FBF' }}
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Dados Básicos
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Consumo e Créditos */}
        <Card>
          <CardHeader>
            <CardTitle className="font-poppins flex items-center space-x-2">
              <CreditCard className="h-5 w-5 text-purple-600" />
              <span>Consumo & Créditos</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Consumo Atual */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-poppins text-sm font-medium mb-3">Consumo Atual</h4>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="font-montserrat text-2xl font-bold text-blue-600">
                    {currentConsumption.ideasUsed}
                  </p>
                  <p className="font-montserrat text-xs text-gray-600">Ideias</p>
                </div>
                <div>
                  <p className="font-montserrat text-2xl font-bold text-green-600">
                    {currentConsumption.articlesUsed}
                  </p>
                  <p className="font-montserrat text-xs text-gray-600">Artigos</p>
                </div>
                <div>
                  <p className="font-montserrat text-2xl font-bold text-purple-600">
                    {currentConsumption.sitesUsed}
                  </p>
                  <p className="font-montserrat text-xs text-gray-600">Sites</p>
                </div>
              </div>
            </div>

            {/* Créditos Extras */}
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-poppins text-sm font-medium">Créditos Extras</h4>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowCreditsModal(true)}
                  className="font-montserrat"
                >
                  <Star className="h-3 w-3 mr-1" />
                  Gerenciar
                </Button>
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="font-montserrat text-xl font-bold text-blue-600">
                    {userCredits.ideas || 0}
                  </p>
                  <p className="font-montserrat text-xs text-gray-600">Ideias Extra</p>
                </div>
                <div>
                  <p className="font-montserrat text-xl font-bold text-green-600">
                    {userCredits.articles || 0}
                  </p>
                  <p className="font-montserrat text-xs text-gray-600">Artigos Extra</p>
                </div>
                <div>
                  <p className="font-montserrat text-xl font-bold text-purple-600">
                    {userCredits.sites || 0}
                  </p>
                  <p className="font-montserrat text-xs text-gray-600">Sites Extra</p>
                </div>
              </div>
              {userCredits.validUntil && (
                <p className="font-montserrat text-xs text-gray-600 mt-2 text-center">
                  <Calendar className="h-3 w-3 inline mr-1" />
                  Válido até: {formatDate(userCredits.validUntil)}
                </p>
              )}
            </div>

            {/* Ações */}
            <div className="space-y-2">
              <Button
                variant="destructive"
                size="sm"
                onClick={handleResetConsumption}
                disabled={isSaving}
                className="w-full font-montserrat"
              >
                {isSaving ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <AlertCircle className="h-4 w-4 mr-2" />
                )}
                Resetar Consumo
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modal de Créditos */}
      <Dialog open={showCreditsModal} onOpenChange={setShowCreditsModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-poppins flex items-center space-x-2">
              <Star className="h-5 w-5 text-purple-600" />
              <span>Gerenciar Créditos Extras</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="font-montserrat text-xs">Ideias</Label>
                <Input
                  type="number"
                  min="0"
                  value={userCredits.ideas}
                  onChange={(e) => setUserCredits(prev => ({ ...prev, ideas: parseInt(e.target.value) || 0 }))}
                  className="font-montserrat"
                />
              </div>
              <div>
                <Label className="font-montserrat text-xs">Artigos</Label>
                <Input
                  type="number"
                  min="0"
                  value={userCredits.articles}
                  onChange={(e) => setUserCredits(prev => ({ ...prev, articles: parseInt(e.target.value) || 0 }))}
                  className="font-montserrat"
                />
              </div>
              <div>
                <Label className="font-montserrat text-xs">Sites</Label>
                <Input
                  type="number"
                  min="0"
                  value={userCredits.sites}
                  onChange={(e) => setUserCredits(prev => ({ ...prev, sites: parseInt(e.target.value) || 0 }))}
                  className="font-montserrat"
                />
              </div>
            </div>

            <div>
              <Label className="font-montserrat">Válido Até (opcional)</Label>
              <Input
                type="date"
                value={userCredits.validUntil}
                onChange={(e) => setUserCredits(prev => ({ ...prev, validUntil: e.target.value }))}
                className="font-montserrat"
              />
            </div>

            <div>
              <Label className="font-montserrat">Observações</Label>
              <Input
                value={userCredits.notes}
                onChange={(e) => setUserCredits(prev => ({ ...prev, notes: e.target.value }))}
                className="font-montserrat"
                placeholder="Ex: Promoção especial, negociação..."
              />
            </div>

            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => setShowCreditsModal(false)}
                className="flex-1 font-montserrat"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSaveCredits}
                disabled={isSaving}
                className="flex-1 font-montserrat text-white"
                style={{ backgroundColor: '#8B5FBF' }}
              >
                {isSaving ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Salvar Créditos
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}