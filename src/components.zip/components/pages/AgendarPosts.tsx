import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';
import { Alert, AlertDescription } from '../ui/alert';
import { Calendar, AlertCircle, Loader2, CheckCircle, Clock, Monitor, Star, BarChart3 } from '../icons';
import { useBia } from '../BiaContext';
import { toast } from 'sonner';

interface AgendarPostsProps {
  userData: any;
}

export function AgendarPosts({ userData }: AgendarPostsProps) {
  const { state, actions } = useBia();
  
  const [formData, setFormData] = useState({
    siteId: '',
    total: 1,
    quantidade: 1,
    frequencia: 'diaria',
    horario: '08:00'
  });

  const [isScheduling, setIsScheduling] = useState(false);
  const [scheduledPosts, setScheduledPosts] = useState<any[]>([]);

  // Sites WordPress conectados (verificar se tem configuração WordPress)
  const connectedSites = state.sites.filter(site => 
    site.status === 'ativo' && site.wordpressUrl && site.wordpressUsername && site.wordpressPassword
  );

  // Artigos concluídos disponíveis para agendamento (filtrados por site selecionado)
  const availableArticles = state.articles.filter(article => {
    const isCompleted = article.status === 'Concluído';
    const isSiteSelected = formData.siteId ? article.siteId.toString() === formData.siteId : true;
    return isCompleted && isSiteSelected;
  });

  // Site selecionado
  const selectedSite = formData.siteId 
    ? connectedSites.find(site => site.id.toString() === formData.siteId)
    : null;

  // Carregar posts agendados do localStorage
  useEffect(() => {
    const saved = localStorage.getItem('scheduledPosts');
    if (saved) {
      try {
        setScheduledPosts(JSON.parse(saved));
      } catch (error) {
        console.error('Erro ao carregar posts agendados:', error);
      }
    }
  }, []);

  // Salvar posts agendados no localStorage
  const saveScheduledPosts = (posts: any[]) => {
    setScheduledPosts(posts);
    localStorage.setItem('scheduledPosts', JSON.stringify(posts));
  };

  // Atualizar total baseado nos artigos disponíveis
  useEffect(() => {
    if (availableArticles.length > 0 && formData.total > availableArticles.length) {
      setFormData(prev => ({
        ...prev,
        total: Math.min(10, availableArticles.length)
      }));
    }
  }, [availableArticles.length, formData.total]);

  const getFrequencyLabel = (freq: string) => {
    switch (freq) {
      case 'diaria': return 'Diária';
      case 'semanal': return 'Semanal';
      case 'mensal': return 'Mensal';
      default: return freq;
    }
  };

  const calculateNextDates = (total: number, frequencia: string, quantidade: number) => {
    const dates = [];
    let currentDate = new Date();
    currentDate.setDate(currentDate.getDate() + 1); // Começar amanhã
    
    let remaining = total;
    while (remaining > 0) {
      const postsThisPeriod = Math.min(quantidade, remaining);
      
      for (let i = 0; i < postsThisPeriod; i++) {
        const postDate = new Date(currentDate);
        postDate.setHours(parseInt(formData.horario.split(':')[0]));
        postDate.setMinutes(parseInt(formData.horario.split(':')[1]));
        
        if (i > 0) {
          // Se mais de um post no mesmo período, espaçar por algumas horas
          postDate.setHours(postDate.getHours() + (i * 2));
        }
        
        dates.push(postDate);
        remaining--;
      }
      
      // Próximo período
      switch (frequencia) {
        case 'diaria':
          currentDate.setDate(currentDate.getDate() + 1);
          break;
        case 'semanal':
          currentDate.setDate(currentDate.getDate() + 7);
          break;
        case 'mensal':
          currentDate.setMonth(currentDate.getMonth() + 1);
          break;
      }
    }
    
    return dates;
  };

  const handleSchedule = async () => {
    if (!formData.siteId) {
      toast.error('Selecione um site para agendar os posts.');
      return;
    }

    if (availableArticles.length === 0) {
      toast.error(`Você não tem artigos concluídos disponíveis para o site ${selectedSite?.nome || 'selecionado'}.`);
      return;
    }

    if (formData.total > availableArticles.length) {
      toast.error(`Você só tem ${availableArticles.length} artigos disponíveis para este site.`);
      return;
    }

    setIsScheduling(true);

    try {
      // Simular agendamento
      await new Promise(resolve => setTimeout(resolve, 2000));

      const dates = calculateNextDates(formData.total, formData.frequencia, formData.quantidade);
      const articlesToSchedule = availableArticles.slice(0, formData.total);
      
      const newScheduledPosts = articlesToSchedule.map((article, index) => ({
        id: Date.now() + index,
        articleId: article.id,
        title: article.titulo,
        content: article.conteudo,
        scheduledDate: dates[index].toISOString(),
        status: 'pending',
        siteId: selectedSite!.id, // Usar o site selecionado
        siteName: selectedSite!.nome,
        createdAt: new Date().toISOString()
      }));

      // Atualizar artigos para status 'Agendado'
      for (const article of articlesToSchedule) {
        actions.updateArticle(article.id, { 
          status: 'Agendado',
          scheduledDate: dates[articlesToSchedule.indexOf(article)].toISOString()
        });
      }

      // Salvar posts agendados
      const updatedScheduledPosts = [...scheduledPosts, ...newScheduledPosts];
      saveScheduledPosts(updatedScheduledPosts);

      toast.success(`${formData.total} posts agendados com sucesso!`);
      
      // Reset form (mantendo o site selecionado)
      setFormData({
        siteId: formData.siteId,
        total: 1,
        quantidade: 1,
        frequencia: 'diaria',
        horario: '08:00'
      });

    } catch (error) {
      toast.error('Erro ao agendar posts. Tente novamente.');
    } finally {
      setIsScheduling(false);
    }
  };

  const pendingScheduledPosts = scheduledPosts.filter(p => p.status === 'pending');

  const calculateEndDate = () => {
    const dates = calculateNextDates(formData.total, formData.frequencia, formData.quantidade);
    if (dates.length > 0) {
      return dates[dates.length - 1].toLocaleDateString('pt-BR');
    }
    return null;
  };

  return (
    <div className="space-y-8">
      {/* Header Clean */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div>
          <h1 className="font-poppins text-2xl text-black mb-2">
            Agendar Posts
          </h1>
          <p className="font-montserrat text-gray-600">
            Configure o agendamento automático dos seus posts WordPress
          </p>
        </div>
      </div>

      {/* Estatísticas com ícones roxos */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
        <Card className="border border-gray-200 hover:shadow-md transition-all">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                <CheckCircle size={20} style={{ color: '#8B5FBF' }} />
              </div>
            </div>
            <div className="space-y-2">
              <div className="font-montserrat text-sm text-gray-600">
                {formData.siteId ? `Artigos Disponíveis (${selectedSite?.nome})` : 'Artigos Disponíveis'}
              </div>
              <div className="font-poppins text-2xl text-black">
                {availableArticles.length}
              </div>
              <div className="font-montserrat text-xs text-gray-500">
                Prontos para agendamento
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-200 hover:shadow-md transition-all">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                <Monitor size={20} style={{ color: '#8B5FBF' }} />
              </div>
            </div>
            <div className="space-y-2">
              <div className="font-montserrat text-sm text-gray-600">
                Sites Conectados
              </div>
              <div className="font-poppins text-2xl text-black">
                {connectedSites.length}
              </div>
              <div className="font-montserrat text-xs text-gray-500">
                Com WordPress ativo
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-200 hover:shadow-md transition-all">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                <Clock size={20} style={{ color: '#8B5FBF' }} />
              </div>
            </div>
            <div className="space-y-2">
              <div className="font-montserrat text-sm text-gray-600">
                Posts Agendados
              </div>
              <div className="font-poppins text-2xl text-black">
                {pendingScheduledPosts.length}
              </div>
              <div className="font-montserrat text-xs text-gray-500">
                Aguardando publicação
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alertas */}
      {!formData.siteId && (
        <Alert className="border-purple-200 bg-purple-50">
          <AlertCircle className="h-4 w-4" style={{ color: '#8B5FBF' }} />
          <AlertDescription className="text-purple-800">
            <strong>Selecione um site</strong> para ver os artigos disponíveis para agendamento.
          </AlertDescription>
        </Alert>
      )}

      {formData.siteId && availableArticles.length === 0 && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertCircle className="h-4 w-4" style={{ color: '#8B5FBF' }} />
          <AlertDescription className="text-orange-800">
            {selectedSite?.nome ? `O site "${selectedSite.nome}" não tem artigos` : 'Você não tem artigos'} <strong>concluídos</strong> disponíveis para agendamento.
            <button 
              onClick={() => window.location.hash = 'articles'}
              className="ml-1 text-orange-800 underline hover:no-underline"
            >
              Vá para "Produzir Artigos" primeiro →
            </button>
          </AlertDescription>
        </Alert>
      )}
      
      {connectedSites.length === 0 && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertCircle className="h-4 w-4" style={{ color: '#8B5FBF' }} />
          <AlertDescription className="text-orange-800">
            Você precisa ter pelo menos um <strong>site WordPress conectado</strong> para agendar posts.
            <button 
              onClick={() => window.location.hash = 'sites'}
              className="ml-1 text-orange-800 underline hover:no-underline"
            >
              Vá para "Meus Sites" e configure WordPress →
            </button>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <Card className="border border-gray-200">
          <CardHeader className="pb-4">
            <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
              <Calendar size={20} style={{ color: '#8B5FBF' }} />
              Configurações de Agendamento
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Seleção de Site - PRIMEIRO CAMPO */}
            <div className="space-y-2">
              <Label htmlFor="siteId" className="font-montserrat text-black flex items-center gap-2">
                <Monitor size={16} style={{ color: '#8B5FBF' }} />
                <span>Selecionar Site *</span>
              </Label>
              <Select 
                value={formData.siteId} 
                onValueChange={(value) => setFormData({...formData, siteId: value, total: 1})}
                disabled={isScheduling}
              >
                <SelectTrigger className="font-montserrat">
                  <SelectValue placeholder="Escolha um site WordPress conectado" />
                </SelectTrigger>
                <SelectContent>
                  {connectedSites.map(site => (
                    <SelectItem key={site.id} value={site.id.toString()}>
                      {site.nome} - {site.url}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {connectedSites.length === 0 && (
                <p className="font-montserrat text-sm text-red-600">
                  Nenhum site WordPress conectado encontrado
                </p>
              )}
            </div>

            {/* Quantidade Total - só aparece quando site estiver selecionado */}
            {formData.siteId && (
              <div className="space-y-2">
                <Label htmlFor="total" className="font-montserrat text-black">Quantidade Total de Posts</Label>
                <Input
                  id="total"
                  type="number"
                  min="1"
                  max={availableArticles.length || 1}
                  value={formData.total}
                  onChange={(e) => setFormData({...formData, total: parseInt(e.target.value) || 1})}
                  className="font-montserrat"
                  disabled={isScheduling || availableArticles.length === 0}
                />
                <p className="font-montserrat text-sm text-gray-500">
                  {availableArticles.length} artigos concluídos disponíveis para {selectedSite?.nome}
                </p>
              </div>
            )}

            {/* Configurações de agendamento - só aparecem quando site estiver selecionado */}
            {formData.siteId && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="quantidade" className="font-montserrat text-black">Posts por Período</Label>
                  <Input
                    id="quantidade"
                    type="number"
                    min="1"
                    max="5"
                    value={formData.quantidade}
                    onChange={(e) => setFormData({...formData, quantidade: parseInt(e.target.value) || 1})}
                    className="font-montserrat"
                    disabled={isScheduling}
                  />
                  <p className="font-montserrat text-sm text-gray-500">
                    Quantos posts publicar por período
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="frequencia" className="font-montserrat text-black">Frequência</Label>
                  <Select 
                    value={formData.frequencia} 
                    onValueChange={(value) => setFormData({...formData, frequencia: value})}
                    disabled={isScheduling}
                  >
                    <SelectTrigger className="font-montserrat">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="diaria">Diária</SelectItem>
                      <SelectItem value="semanal">Semanal</SelectItem>
                      <SelectItem value="mensal">Mensal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="horario" className="font-montserrat text-black">Horário de Publicação</Label>
                  <Input
                    id="horario"
                    type="time"
                    value={formData.horario}
                    onChange={(e) => setFormData({...formData, horario: e.target.value})}
                    className="font-montserrat"
                    disabled={isScheduling}
                  />
                  <p className="font-montserrat text-sm text-gray-500">
                    Horário padrão para todas as publicações
                  </p>
                </div>
              </>
            )}

            {isScheduling && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" style={{ color: '#8B5FBF' }} />
                  <span className="font-montserrat text-sm text-gray-600">Agendando posts...</span>
                </div>
              </div>
            )}

            {formData.siteId && (
              <Button 
                onClick={handleSchedule}
                disabled={isScheduling || !formData.siteId || availableArticles.length === 0 || formData.total > availableArticles.length}
                className="w-full font-montserrat text-white"
                style={{ backgroundColor: '#8B5FBF' }}
              >
                {isScheduling ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Agendando...
                  </>
                ) : (
                  <>
                    <Calendar className="mr-2" size={16} />
                    Agendar {formData.total} Posts
                  </>
                )}
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Prévia do agendamento com fundo colorido - só aparece quando site estiver selecionado */}
        {formData.siteId && (
          <Card className="border border-gray-200" style={{ backgroundColor: '#f0fff4' }}>
            <CardHeader className="pb-4">
              <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
                <BarChart3 size={20} style={{ color: '#8B5FBF' }} />
                Prévia do Agendamento
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between p-3 bg-white/60 rounded-lg border border-green-100">
                  <span className="font-montserrat text-sm text-gray-700">Site selecionado:</span>
                  <span className="font-montserrat text-sm font-medium text-black">{selectedSite?.nome}</span>
                </div>
                <div className="flex justify-between p-3 bg-white/60 rounded-lg border border-green-100">
                  <span className="font-montserrat text-sm text-gray-700">Total de posts:</span>
                  <span className="font-montserrat text-sm font-medium text-black">{formData.total}</span>
                </div>
                <div className="flex justify-between p-3 bg-white/60 rounded-lg border border-green-100">
                  <span className="font-montserrat text-sm text-gray-700">Frequência:</span>
                  <span className="font-montserrat text-sm font-medium text-black">{getFrequencyLabel(formData.frequencia)}</span>
                </div>
                <div className="flex justify-between p-3 bg-white/60 rounded-lg border border-green-100">
                  <span className="font-montserrat text-sm text-gray-700">Posts por período:</span>
                  <span className="font-montserrat text-sm font-medium text-black">{formData.quantidade}</span>
                </div>
                <div className="flex justify-between p-3 bg-white/60 rounded-lg border border-green-100">
                  <span className="font-montserrat text-sm text-gray-700">Horário:</span>
                  <span className="font-montserrat text-sm font-medium text-black">{formData.horario}</span>
                </div>
                {calculateEndDate() && (
                  <div className="flex justify-between p-3 bg-white/60 rounded-lg border border-green-100">
                    <span className="font-montserrat text-sm text-gray-700">Término previsto:</span>
                    <span className="font-montserrat text-sm font-medium text-black">{calculateEndDate()}</span>
                  </div>
                )}
              </div>

              <div className="border-t border-green-200 pt-4">
                <h4 className="font-montserrat font-medium text-black mb-3 flex items-center gap-2">
                  <Clock size={16} style={{ color: '#8B5FBF' }} />
                  Cronograma:
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-2 bg-white/60 rounded border border-green-100">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#8B5FBF' }}></div>
                    <span className="font-montserrat text-sm text-gray-700">Primeiro post: Amanhã às {formData.horario}</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-white/60 rounded border border-green-100">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#8B5FBF' }}></div>
                    <span className="font-montserrat text-sm text-gray-700">Publicação {formData.frequencia}</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-white/60 rounded border border-green-100">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#8B5FBF' }}></div>
                    <span className="font-montserrat text-sm text-gray-700">{formData.quantidade} post(s) por vez</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-white/60 rounded border border-green-100">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#8B5FBF' }}></div>
                    <span className="font-montserrat text-sm text-gray-700">Site: {selectedSite?.nome}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Posts agendados existentes */}
      {pendingScheduledPosts.length > 0 && (
        <Card className="border border-gray-200">
          <CardHeader className="pb-4">
            <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
              <Calendar size={20} style={{ color: '#8B5FBF' }} />
              Posts Já Agendados ({pendingScheduledPosts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingScheduledPosts
                .sort((a, b) => new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime())
                .slice(0, 5)
                .map(post => (
                  <div key={post.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-purple-50 rounded-full flex items-center justify-center flex-shrink-0">
                        <Calendar size={14} style={{ color: '#8B5FBF' }} />
                      </div>
                      <div className="flex-1">
                        <p className="font-montserrat text-sm font-medium text-black">{post.title}</p>
                        <p className="font-montserrat text-xs text-gray-600">
                          {new Date(post.scheduledDate).toLocaleDateString('pt-BR')} às {new Date(post.scheduledDate).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                          {post.siteName && ` • ${post.siteName}`}
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className="border-purple-200 text-purple-700 bg-purple-50 text-xs font-montserrat">
                      <Clock size={10} className="mr-1" />
                      Agendado
                    </Badge>
                  </div>
                ))}
              {pendingScheduledPosts.length > 5 && (
                <p className="font-montserrat text-sm text-gray-500 text-center pt-2">
                  E mais {pendingScheduledPosts.length - 5} posts...
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dicas com fundo colorido */}
      <Card className="border border-gray-200" style={{ backgroundColor: '#f8f5ff' }}>
        <CardHeader className="pb-4">
          <CardTitle className="font-poppins text-lg text-black flex items-center gap-2">
            <Star size={20} style={{ color: '#8B5FBF' }} />
            Dicas para Agendamento Eficaz
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="p-4 bg-white/60 rounded-lg border border-purple-100">
                <div className="flex items-center gap-2 mb-2">
                  <Clock size={16} style={{ color: '#8B5FBF' }} />
                  <h4 className="font-montserrat font-medium text-black">
                    Consistência é chave
                  </h4>
                </div>
                <p className="font-montserrat text-sm text-gray-600">
                  Mantenha uma frequência regular de publicação para engajar melhor sua audiência.
                </p>
              </div>
              <div className="p-4 bg-white/60 rounded-lg border border-purple-100">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart3 size={16} style={{ color: '#8B5FBF' }} />
                  <h4 className="font-montserrat font-medium text-black">
                    Analise o engajamento
                  </h4>
                </div>
                <p className="font-montserrat text-sm text-gray-600">
                  Monitore os horários de maior engajamento do seu público-alvo.
                </p>
              </div>
            </div>
            <div className="space-y-3">
              <div className="p-4 bg-white/60 rounded-lg border border-purple-100">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle size={16} style={{ color: '#8B5FBF' }} />
                  <h4 className="font-montserrat font-medium text-black">
                    Prepare com antecedência
                  </h4>
                </div>
                <p className="font-montserrat text-sm text-gray-600">
                  Tenha conteúdo suficiente produzido antes de configurar agendamentos.
                </p>
              </div>
              <div className="p-4 bg-white/60 rounded-lg border border-purple-100">
                <div className="flex items-center gap-2 mb-2">
                  <Calendar size={16} style={{ color: '#8B5FBF' }} />
                  <h4 className="font-montserrat font-medium text-black">
                    Use o calendário
                  </h4>
                </div>
                <p className="font-montserrat text-sm text-gray-600">
                  Visualize suas publicações agendadas no calendário para melhor organização.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}