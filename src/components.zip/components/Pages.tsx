// Arquivo refatorado que apenas re-exporta os componentes individuais
export { MinhaConta } from './pages/MinhaConta';
export { GerarIdeias } from './pages/GerarIdeias';
export { ProduzirArtigos } from './pages/ProduzirArtigos';
export { AgendarPosts } from './pages/AgendarPosts';
export { Calendario } from './pages/Calendario';
export { Historico } from './pages/Historico';
export { Excluidos } from './pages/Excluidos';
export { MeusSites } from './pages/MeusSites';
export { LojaBIA } from './pages/LojaBIA';
export { Maisfy } from './pages/Maisfy';
export { Suporte } from './pages/Suporte';