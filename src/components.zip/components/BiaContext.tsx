import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { databaseService } from '../services/databaseService';

// Interfaces e tipos
interface Site {
  id: number;
  nome: string;
  url: string;
  descricao: string;
  categoria: string;
  nicho: string;
  status: 'ativo' | 'inativo';
  wordpressUrl?: string;
  wordpressUsername?: string;
  wordpressPassword?: string;
  wordpressData?: any;
  createdAt: string;
  updatedAt: string;
}

interface Idea {
  id: number;
  titulo: string;
  descricao?: string;
  categoria: string;
  tags: string[];
  siteId: number;
  status: 'ativa' | 'produzido' | 'excluido';
  cta?: any;
  generationParams?: any;
  wordpressData?: any;
  articleId?: number;
  createdAt: string;
  updatedAt: string;
  deletedDate?: string;
}

interface Article {
  id: number;
  titulo: string;
  conteudo: string;
  status: 'Rascunho' | 'Em Revisão' | 'Concluído' | 'Publicado';
  siteId: number;
  ideaId: number;
  imageUrl?: string;
  publishedUrl?: string;
  publishedDate?: string;
  scheduledDate?: string;
  scheduledUrl?: string;
  wordpressPostId?: number;
  wordpressData?: any;
  generationParams?: any;
  createdAt: string;
  updatedAt: string;
}

interface User {
  id: string;
  email: string;
  name: string;
  cpf?: string;
  whatsapp?: string;
  dataNascimento?: string;
  plano: string;
}

interface BiaState {
  user: User | null;
  sites: Site[];
  ideas: Idea[];
  articles: Article[];
  isLoading: boolean;
  lastSync: string | null;
  error: string | null;
}

type BiaAction = 
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'UPDATE_USER'; payload: Partial<User> }
  | { type: 'SET_SITES'; payload: Site[] }
  | { type: 'ADD_SITE'; payload: Site }
  | { type: 'UPDATE_SITE'; payload: { id: number; updates: Partial<Site> } }
  | { type: 'DELETE_SITE'; payload: number }
  | { type: 'SET_IDEAS'; payload: Idea[] }
  | { type: 'ADD_IDEAS'; payload: Idea[] }
  | { type: 'UPDATE_IDEA'; payload: { id: number; updates: Partial<Idea> } }
  | { type: 'DELETE_IDEA'; payload: number }
  | { type: 'SET_ARTICLES'; payload: Article[] }
  | { type: 'ADD_ARTICLE'; payload: Article }
  | { type: 'UPDATE_ARTICLE'; payload: { id: number; updates: Partial<Article> } }
  | { type: 'DELETE_ARTICLE'; payload: number }
  | { type: 'LOAD_STATE'; payload: Partial<BiaState> }
  | { type: 'SET_LAST_SYNC'; payload: string }
  | { type: 'SET_ERROR'; payload: string | null };

// Estado inicial
const initialState: BiaState = {
  user: null,
  sites: [],
  ideas: [],
  articles: [],
  isLoading: false,
  lastSync: null,
  error: null
};

// Reducer
function biaReducer(state: BiaState, action: BiaAction): BiaState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };

    case 'SET_USER':
      return { ...state, user: action.payload, error: null };

    case 'UPDATE_USER':
      if (!state.user) return state;
      return { 
        ...state, 
        user: { ...state.user, ...action.payload }, 
        error: null 
      };

    case 'SET_SITES':
      return { ...state, sites: action.payload };

    case 'ADD_SITE': {
      const newSite = {
        ...action.payload,
        createdAt: action.payload.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      return { ...state, sites: [...state.sites, newSite] };
    }

    case 'UPDATE_SITE': {
      const updatedSites = state.sites.map(site =>
        site.id === action.payload.id
          ? { ...site, ...action.payload.updates, updatedAt: new Date().toISOString() }
          : site
      );
      return { ...state, sites: updatedSites };
    }

    case 'DELETE_SITE': {
      const filteredSites = state.sites.filter(site => site.id !== action.payload);
      return { ...state, sites: filteredSites };
    }

    case 'SET_IDEAS':
      return { ...state, ideas: action.payload };

    case 'ADD_IDEAS': {
      const newIdeas = action.payload.map(idea => ({
        ...idea,
        createdAt: idea.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }));
      return { ...state, ideas: [...state.ideas, ...newIdeas] };
    }

    case 'UPDATE_IDEA': {
      const updatedIdeas = state.ideas.map(idea =>
        idea.id === action.payload.id
          ? { ...idea, ...action.payload.updates, updatedAt: new Date().toISOString() }
          : idea
      );
      return { ...state, ideas: updatedIdeas };
    }

    case 'DELETE_IDEA': {
      const filteredIdeas = state.ideas.filter(idea => idea.id !== action.payload);
      return { ...state, ideas: filteredIdeas };
    }

    case 'SET_ARTICLES':
      return { ...state, articles: action.payload };

    case 'ADD_ARTICLE': {
      const newArticle = {
        ...action.payload,
        createdAt: action.payload.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      return { ...state, articles: [...state.articles, newArticle] };
    }

    case 'UPDATE_ARTICLE': {
      const updatedArticles = state.articles.map(article =>
        article.id === action.payload.id
          ? { ...article, ...action.payload.updates, updatedAt: new Date().toISOString() }
          : article
      );
      return { ...state, articles: updatedArticles };
    }

    case 'DELETE_ARTICLE': {
      const filteredArticles = state.articles.filter(article => article.id !== action.payload);
      return { ...state, articles: filteredArticles };
    }

    case 'LOAD_STATE':
      return { ...state, ...action.payload };

    case 'SET_LAST_SYNC':
      return { ...state, lastSync: action.payload };

    case 'SET_ERROR':
      return { ...state, error: action.payload };

    default:
      return state;
  }
}

// Context
const BiaContext = createContext<{
  state: BiaState;
  actions: {
    // User actions
    login: (user: User) => void;
    logout: () => void;
    updateUser: (updates: Partial<User>) => Promise<void>;
    clearError: () => void;
    
    // Site actions
    addSite: (site: Omit<Site, 'id' | 'createdAt' | 'updatedAt'>) => boolean;
    updateSite: (id: number, updates: Partial<Site>) => boolean;
    deleteSite: (id: number) => boolean;
    
    // Idea actions
    addIdeas: (ideas: Omit<Idea, 'id' | 'createdAt' | 'updatedAt'>[]) => boolean;
    updateIdea: (id: number, updates: Partial<Idea>) => boolean;
    deleteIdea: (id: number) => boolean;
    
    // Article actions
    addArticle: (article: Omit<Article, 'id' | 'createdAt' | 'updatedAt'>) => boolean;
    updateArticle: (id: number, updates: Partial<Article>) => boolean;
    deleteArticle: (id: number) => boolean;
    
    // Utility actions
    checkFreePlanLimits: () => { sites: boolean; ideas: boolean; articles: boolean };
    isFreePlan: () => boolean;
    
    // Consumption control actions
    checkConsumptionLimits: (resourceType: 'ideas' | 'articles' | 'sites') => Promise<{ canConsume: boolean; reason?: string; currentUsage?: number; limit?: number }>;
    recordResourceConsumption: (resourceType: 'ideas' | 'articles' | 'sites', quantity?: number) => Promise<boolean>;
    loadFromStorage: () => void;
    saveToStorage: () => void;
    syncWithDatabase: () => Promise<void>;
    loadFromDatabase: () => Promise<void>;
    forceSyncToDatabase: () => Promise<boolean>;
    forceLoadFromDatabase: () => Promise<void>;
  };
} | undefined>(undefined);

// Provider component
export function BiaProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(biaReducer, initialState);

  // Auto-save para localStorage (otimizado)
  const saveToLocalStorage = useCallback(() => {
    try {
      const dataToSave = {
        sites: state.sites,
        ideas: state.ideas,
        articles: state.articles,
        user: state.user, // Incluir dados do usuário para persistência
        lastSync: new Date().toISOString()
      };
      
      localStorage.setItem('bia-state', JSON.stringify(dataToSave));
      
      console.log('✅ Estado salvo no localStorage:', {
        sites: state.sites.length,
        ideas: state.ideas.length,
        articles: state.articles.length,
        user: state.user?.email || 'N/A'
      });
    } catch (error) {
      console.warn('⚠️ Erro ao salvar no localStorage:', error);
    }
  }, [state.sites, state.ideas, state.articles, state.user]);

  // Auto-sync com banco de dados (FORÇADO PARA SUPABASE)
  const syncWithDatabase = useCallback(async () => {
    if (!state.user?.id) {
      console.log('🔄 Sync cancelado: usuário não logado');
      return;
    }

    // Verificar se está online
    if (!navigator.onLine) {
      console.log('🔴 Sync cancelado: sem conexão');
      return;
    }

    try {
      console.log('🔄 === INICIANDO SYNC FORÇADO PARA SUPABASE ===');
      console.log(`👤 Usuário: ${state.user.email} (ID: ${state.user.id})`);
      console.log(`📊 Dados para sync:`, {
        sites: state.sites.length,
        ideas: state.ideas.length,
        articles: state.articles.length
      });
      
      // SEMPRE sincronizar dados, independente do usuário
      const syncData = {
        sites: state.sites,
        ideas: state.ideas,
        articles: state.articles
      };

      try {
        console.log('📡 Enviando dados para Supabase...');
        const result = await databaseService.syncUserData(state.user.id, syncData);
        
        if (result.success) {
          dispatch({ type: 'SET_LAST_SYNC', payload: new Date().toISOString() });
          dispatch({ type: 'SET_ERROR', payload: null }); // Limpar erros anteriores
          console.log('✅ === SYNC COM SUPABASE CONCLUÍDO ===');
          console.log('📈 Dados persistidos com segurança no banco');
        } else {
          console.warn('⚠️ Falha no sync:', result.error);
          
          // Para falhas específicas de dados, mostrar ao usuário
          if (!result.error?.includes('Failed to fetch') && !result.error?.includes('network')) {
            dispatch({ type: 'SET_ERROR', payload: `Erro na sincronização: ${result.error}` });
          } else {
            console.log('🌐 Problema de conectividade detectado - dados mantidos localmente');
          }
        }
      } catch (error) {
        console.warn('⚠️ Erro de conectividade no sync:', error);
        
        // Para erros de rede, não definir erro no estado
        if (error?.message?.includes('Failed to fetch') || error?.name === 'AbortError') {
          console.log('🌐 Problema de conectividade detectado - continuando em modo offline');
        } else {
          dispatch({ type: 'SET_ERROR', payload: 'Erro de sincronização. Dados salvos localmente.' });
        }
      }
    } catch (error) {
      console.warn('⚠️ Erro geral no sync:', error);
      
      // Só mostrar erro se não for problema de rede
      if (!error?.message?.includes('Failed to fetch')) {
        dispatch({ type: 'SET_ERROR', payload: 'Erro interno na sincronização' });
      }
    }
  }, [state.user?.id, state.user?.email, state.sites, state.ideas, state.articles]);

  // Carregar dados do banco (FORÇADO PARA SUPABASE)
  const loadFromDatabase = useCallback(async () => {
    if (!state.user?.id) {
      console.log('📥 Load cancelado: usuário não logado');
      return;
    }

    // Verificar conectividade antes de tentar carregar
    if (!navigator.onLine) {
      console.log('🔴 Load cancelado: sem conexão - usando dados locais');
      return;
    }

    try {
      console.log('📥 === CARREGAMENTO FORÇADO DO SUPABASE ===');
      console.log(`👤 Usuário: ${state.user.email} (ID: ${state.user.id})`);
      
      // SEMPRE tentar carregar do banco primeiro, independente de dados locais
      console.log('📡 Carregando dados do Supabase...');
      
      try {
        const result = await databaseService.loadUserData(state.user.id);
        
        if (result.success && result.data) {
          const bankSites = result.data.sites || [];
          const bankIdeas = result.data.ideas || [];
          const bankArticles = result.data.articles || [];
          
          console.log('📊 Dados encontrados no Supabase:', {
            sites: bankSites.length,
            ideas: bankIdeas.length,
            articles: bankArticles.length
          });

          // Verificar se há dados locais
          const hasLocalData = state.sites.length > 0 || state.ideas.length > 0 || state.articles.length > 0;
          const hasBankData = bankSites.length > 0 || bankIdeas.length > 0 || bankArticles.length > 0;

          if (hasBankData) {
            // Se há dados no banco, usar eles (dados sincronizados são mais confiáveis)
            console.log('✅ Usando dados do Supabase (fonte confiável)');
            dispatch({ type: 'SET_SITES', payload: bankSites });
            dispatch({ type: 'SET_IDEAS', payload: bankIdeas });
            dispatch({ type: 'SET_ARTICLES', payload: bankArticles });
            console.log('✅ Dados carregados do Supabase com sucesso');
          } else if (hasLocalData) {
            // Se não há dados no banco mas há dados locais, sincronizar dados locais
            console.log('💾 Dados locais encontrados, sincronizando para Supabase...');
            
            const syncData = {
              sites: state.sites,
              ideas: state.ideas,
              articles: state.articles
            };
            
            try {
              const syncResult = await databaseService.syncUserData(state.user.id, syncData);
              if (syncResult.success) {
                console.log('✅ Dados locais sincronizados para Supabase com sucesso');
                dispatch({ type: 'SET_ERROR', payload: null });
              } else {
                console.warn('⚠️ Falha na sincronização dos dados locais:', syncResult.error);
                if (!syncResult.error?.includes('Failed to fetch')) {
                  dispatch({ type: 'SET_ERROR', payload: 'Problema na sincronização. Dados mantidos localmente.' });
                }
              }
            } catch (syncError) {
              console.warn('⚠️ Erro de conectividade na sincronização:', syncError);
              if (!syncError?.message?.includes('Failed to fetch')) {
                dispatch({ type: 'SET_ERROR', payload: 'Erro de sincronização. Trabalhando offline.' });
              }
            }
          } else {
            // Nem dados no banco nem dados locais
            console.log('📝 Nenhum dado encontrado - usuário iniciando limpo');
          }
          
          dispatch({ type: 'SET_LAST_SYNC', payload: new Date().toISOString() });
          dispatch({ type: 'SET_ERROR', payload: null });
        } else {
          console.warn('⚠️ Falha ao carregar dados do Supabase:', result.error);
          
          // Verificar se há dados locais para usar como fallback
          const hasLocalData = state.sites.length > 0 || state.ideas.length > 0 || state.articles.length > 0;
          
          if (hasLocalData) {
            console.log('💾 Usando dados locais como fallback');
            // Tentar sincronizar dados locais em background
            setTimeout(async () => {
              try {
                const syncData = {
                  sites: state.sites,
                  ideas: state.ideas,
                  articles: state.articles
                };
                await databaseService.syncUserData(state.user.id, syncData);
                console.log('✅ Dados locais sincronizados em background');
              } catch (error) {
                console.warn('⚠️ Erro na sincronização em background:', error);
              }
            }, 5000);
          }
          
          // Não mostrar erro se for problema de conectividade
          if (!result.error?.includes('Failed to fetch')) {
            dispatch({ type: 'SET_ERROR', payload: 'Não foi possível carregar dados remotos' });
          }
          
          dispatch({ type: 'SET_LAST_SYNC', payload: new Date().toISOString() });
        }
      } catch (loadError) {
        console.warn('⚠️ Erro de conectividade no carregamento:', loadError);
        
        // Para erros de rede, usar dados locais se disponíveis
        if (loadError?.message?.includes('Failed to fetch') || loadError?.name === 'AbortError') {
          console.log('🌐 Problema de conectividade - usando dados locais se disponíveis');
          
          const hasLocalData = state.sites.length > 0 || state.ideas.length > 0 || state.articles.length > 0;
          if (hasLocalData) {
            console.log('💾 Dados locais encontrados, mantendo-os');
          }
        } else {
          dispatch({ type: 'SET_ERROR', payload: 'Erro ao carregar dados. Trabalhando offline.' });
        }
      }
    } catch (error) {
      console.warn('⚠️ Erro geral no carregamento de dados:', error);
      
      // Só mostrar erro se não for problema de rede
      if (!error?.message?.includes('Failed to fetch')) {
        dispatch({ type: 'SET_ERROR', payload: 'Erro interno no carregamento' });
      }
    }
  }, [state.user?.id, state.user?.email, state.sites, state.ideas, state.articles]);

  // Auto-save efeito (imediato para operações críticas)
  useEffect(() => {
    // Save imediato se há mudanças em sites, ideas ou articles
    if (state.sites.length > 0 || state.ideas.length > 0 || state.articles.length > 0) {
      const timeoutId = setTimeout(() => {
        saveToLocalStorage();
      }, 500); // Debounce reduzido para 500ms

      return () => clearTimeout(timeoutId);
    }
  }, [saveToLocalStorage, state.sites.length, state.ideas.length, state.articles.length]);

  // Auto-sync efeito (FORÇADO sempre que dados mudarem)
  useEffect(() => {
    if (state.user?.id && navigator.onLine && (state.sites.length > 0 || state.ideas.length > 0 || state.articles.length > 0)) {
      // Sync imediato sempre que dados mudarem (com debounce)
      const immediateSync = setTimeout(() => {
        console.log('🔄 Sync automático ativado por mudança de dados');
        syncWithDatabase();
      }, 3000); // 3 segundos de debounce

      return () => clearTimeout(immediateSync);
    }
  }, [syncWithDatabase, state.user?.id, state.sites, state.ideas, state.articles]);

  // Sync periódico adicional (para garantir que dados nunca sejam perdidos)
  useEffect(() => {
    if (state.user?.id && navigator.onLine) {
      // Sync inicial após login
      const initialSync = setTimeout(() => {
        syncWithDatabase();
      }, 2000);

      // Sync de backup a cada 5 minutos
      const backupSyncInterval = setInterval(() => {
        if (navigator.onLine && (state.sites.length > 0 || state.ideas.length > 0 || state.articles.length > 0)) {
          console.log('🔄 Sync de backup automático');
          syncWithDatabase();
        }
      }, 300000); // 5 minutos

      return () => {
        clearTimeout(initialSync);
        clearInterval(backupSyncInterval);
      };
    }
  }, [syncWithDatabase, state.user?.id]);

  // Load inicial do localStorage
  useEffect(() => {
    try {
      const savedState = localStorage.getItem('bia-state');
      if (savedState) {
        const parsedState = JSON.parse(savedState);
        console.log('🔄 Carregando estado do localStorage:', {
          sites: parsedState.sites?.length || 0,
          ideas: parsedState.ideas?.length || 0,
          articles: parsedState.articles?.length || 0
        });
        dispatch({ type: 'LOAD_STATE', payload: parsedState });
        console.log('✅ Estado carregado do localStorage com sucesso');
      } else {
        console.log('📝 Nenhum estado encontrado no localStorage');
      }
    } catch (error) {
      console.warn('⚠️ Erro ao carregar do localStorage:', error);
    }
  }, []);

  // Actions
  const actions = {
    // User actions
    login: (user: User) => {
      console.log('🔐 Login no BiaContext:', user.email);
      dispatch({ type: 'SET_USER', payload: user });
      
      // Forçar carregamento dos dados salvos primeiro
      try {
        const savedState = localStorage.getItem('bia-state');
        if (savedState) {
          const parsedState = JSON.parse(savedState);
          console.log('📁 Dados existentes encontrados no localStorage:', {
            sites: parsedState.sites?.length || 0,
            ideas: parsedState.ideas?.length || 0,
            articles: parsedState.articles?.length || 0
          });
          
          // Carregar dados existentes se houver
          if (parsedState.sites?.length > 0 || parsedState.ideas?.length > 0 || parsedState.articles?.length > 0) {
            dispatch({ type: 'LOAD_STATE', payload: parsedState });
            console.log('✅ Dados restaurados do localStorage após login');
          }
        }
      } catch (error) {
        console.warn('⚠️ Erro ao restaurar dados após login:', error);
      }
      
      // Para usuários normais, carregar do banco após um delay menor
      const isDevUser = user.email === 'dev@bia.com';
      const delay = isDevUser ? 3000 : 1000;
      
      setTimeout(() => {
        loadFromDatabase();
      }, delay);
    },

    logout: () => {
      // Salvar dados atuais no localStorage antes do logout
      try {
        const dataToPreserve = {
          sites: state.sites,
          ideas: state.ideas,
          articles: state.articles,
          lastSync: new Date().toISOString()
        };
        
        localStorage.setItem('bia-state', JSON.stringify(dataToPreserve));
        console.log('💾 Dados preservados no logout:', {
          sites: state.sites.length,
          ideas: state.ideas.length,
          articles: state.articles.length
        });
      } catch (error) {
        console.warn('⚠️ Erro ao preservar dados no logout:', error);
      }

      // Limpar apenas o estado do usuário, preservando os dados
      dispatch({ type: 'SET_USER', payload: null });
      dispatch({ type: 'SET_ERROR', payload: null });
      dispatch({ type: 'SET_LAST_SYNC', payload: null });
      
      console.log('🚪 Logout completo - usuário deslogado, dados preservados');
    },

    updateUser: async (updates: Partial<User>) => {
      if (!state.user) {
        console.warn('⚠️ Tentativa de atualizar usuário sem login');
        return;
      }
      
      try {
        console.log('🔄 Atualizando usuário no contexto BIA:', updates);
        dispatch({ type: 'SET_ERROR', payload: null });
        
        // Atualizar localmente primeiro (otimistic update)
        dispatch({ type: 'UPDATE_USER', payload: updates });
        
        // Tentar sincronizar com o banco de dados
        try {
          const result = await databaseService.updateUser(state.user.id, updates);
          
          if (result.success && result.user) {
            // Se o banco retornou dados atualizados, usar eles
            dispatch({ type: 'SET_USER', payload: result.user });
            
            // Atualizar localStorage também
            const savedUser = localStorage.getItem('bia-user');
            if (savedUser) {
              const updatedUser = { ...JSON.parse(savedUser), ...result.user };
              localStorage.setItem('bia-user', JSON.stringify(updatedUser));
            }
            
            console.log('✅ Usuário atualizado e sincronizado com sucesso');
          } else {
            console.warn('⚠️ Resposta inválida do banco:', result);
            
            // Manter atualização local mesmo com erro de sincronização
            const updatedUser = { ...state.user, ...updates };
            const savedUser = localStorage.getItem('bia-user');
            if (savedUser) {
              const localUser = { ...JSON.parse(savedUser), ...updates };
              localStorage.setItem('bia-user', JSON.stringify(localUser));
            }
          }
        } catch (dbError) {
          console.warn('⚠️ Erro na sincronização com banco, mantendo dados locais:', dbError);
          
          // Manter atualização local mesmo com erro de banco
          const updatedUser = { ...state.user, ...updates };
          const savedUser = localStorage.getItem('bia-user');
          if (savedUser) {
            const localUser = { ...JSON.parse(savedUser), ...updates };
            localStorage.setItem('bia-user', JSON.stringify(localUser));
          }
        }
      } catch (error) {
        console.error('❌ Erro crítico na atualização do usuário:', error);
        dispatch({ type: 'SET_ERROR', payload: 'Erro ao atualizar dados do usuário' });
        throw error;
      }
    },

    // Site actions
    addSite: (siteData: Omit<Site, 'id' | 'createdAt' | 'updatedAt'>) => {
      try {
        const newSite: Site = {
          ...siteData,
          id: Date.now(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        
        console.log('➕ Adicionando novo site:', newSite.nome);
        dispatch({ type: 'ADD_SITE', payload: newSite });
        
        // Save imediato para sites (dados críticos)
        setTimeout(() => {
          saveToLocalStorage();
        }, 100);

        // SINCRONIZAÇÃO IMEDIATA COM SUPABASE
        if (state.user?.id && navigator.onLine) {
          setTimeout(async () => {
            try {
              console.log('🔄 Sincronização automática após adicionar site');
              await syncWithDatabase();
              console.log('✅ Site sincronizado com Supabase automaticamente');
            } catch (error) {
              console.warn('⚠️ Erro na sincronização automática do site:', error);
            }
          }, 2000);
        }
        
        return true;
      } catch (error) {
        console.error('❌ Erro ao adicionar site:', error);
        return false;
      }
    },

    updateSite: (id: number, updates: Partial<Site>) => {
      try {
        console.log('✏️ Atualizando site:', id, updates);
        dispatch({ type: 'UPDATE_SITE', payload: { id, updates } });
        
        // Save imediato para atualizações de sites
        setTimeout(() => {
          saveToLocalStorage();
        }, 100);

        // SINCRONIZAÇÃO IMEDIATA COM SUPABASE
        if (state.user?.id && navigator.onLine) {
          setTimeout(async () => {
            try {
              console.log('🔄 Sincronização automática após atualizar site');
              await syncWithDatabase();
              console.log('✅ Atualização de site sincronizada com Supabase automaticamente');
            } catch (error) {
              console.warn('⚠️ Erro na sincronização automática da atualização:', error);
            }
          }, 2000);
        }
        
        return true;
      } catch (error) {
        console.error('❌ Erro ao atualizar site:', error);
        return false;
      }
    },

    deleteSite: (id: number) => {
      try {
        dispatch({ type: 'DELETE_SITE', payload: id });
        return true;
      } catch (error) {
        console.error('❌ Erro ao deletar site:', error);
        return false;
      }
    },

    // Idea actions
    addIdeas: (ideasData: Omit<Idea, 'id' | 'createdAt' | 'updatedAt'>[]) => {
      try {
        const newIdeas: Idea[] = ideasData.map(idea => ({
          ...idea,
          id: Date.now() + Math.random(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }));
        
        console.log(`➕ Adicionando ${newIdeas.length} novas ideias`);
        dispatch({ type: 'ADD_IDEAS', payload: newIdeas });
        
        // SINCRONIZAÇÃO IMEDIATA COM SUPABASE
        if (state.user?.id && navigator.onLine) {
          setTimeout(async () => {
            try {
              console.log('🔄 Sincronização automática após adicionar ideias');
              await syncWithDatabase();
              console.log('✅ Ideias sincronizadas com Supabase automaticamente');
            } catch (error) {
              console.warn('⚠️ Erro na sincronização automática das ideias:', error);
            }
          }, 2000);
        }
        
        return true;
      } catch (error) {
        console.error('❌ Erro ao adicionar ideias:', error);
        return false;
      }
    },

    updateIdea: (id: number, updates: Partial<Idea>) => {
      try {
        console.log('✏️ Atualizando ideia:', id, updates);
        dispatch({ type: 'UPDATE_IDEA', payload: { id, updates } });
        
        // SINCRONIZAÇÃO IMEDIATA COM SUPABASE
        if (state.user?.id && navigator.onLine) {
          setTimeout(async () => {
            try {
              console.log('🔄 Sincronização automática após atualizar ideia');
              await syncWithDatabase();
              console.log('✅ Atualização de ideia sincronizada com Supabase automaticamente');
            } catch (error) {
              console.warn('⚠️ Erro na sincronização automática da atualização da ideia:', error);
            }
          }, 2000);
        }
        
        return true;
      } catch (error) {
        console.error('❌ Erro ao atualizar ideia:', error);
        return false;
      }
    },

    deleteIdea: (id: number) => {
      try {
        dispatch({ type: 'DELETE_IDEA', payload: id });
        return true;
      } catch (error) {
        console.error('❌ Erro ao deletar ideia:', error);
        return false;
      }
    },

    // Article actions
    addArticle: (articleData: Omit<Article, 'id' | 'createdAt' | 'updatedAt'>) => {
      try {
        const newArticle: Article = {
          ...articleData,
          id: Date.now(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        
        console.log('➕ Adicionando novo artigo:', newArticle.titulo);
        dispatch({ type: 'ADD_ARTICLE', payload: newArticle });
        
        // SINCRONIZAÇÃO IMEDIATA COM SUPABASE
        if (state.user?.id && navigator.onLine) {
          setTimeout(async () => {
            try {
              console.log('🔄 Sincronização automática após adicionar artigo');
              await syncWithDatabase();
              console.log('✅ Artigo sincronizado com Supabase automaticamente');
            } catch (error) {
              console.warn('⚠️ Erro na sincronização automática do artigo:', error);
            }
          }, 2000);
        }
        
        return true;
      } catch (error) {
        console.error('❌ Erro ao adicionar artigo:', error);
        return false;
      }
    },

    updateArticle: (id: number, updates: Partial<Article>) => {
      try {
        console.log('✏️ Atualizando artigo:', id, updates);
        dispatch({ type: 'UPDATE_ARTICLE', payload: { id, updates } });
        
        // SINCRONIZAÇÃO IMEDIATA COM SUPABASE
        if (state.user?.id && navigator.onLine) {
          setTimeout(async () => {
            try {
              console.log('🔄 Sincronização automática após atualizar artigo');
              await syncWithDatabase();
              console.log('✅ Atualização de artigo sincronizada com Supabase automaticamente');
            } catch (error) {
              console.warn('⚠️ Erro na sincronização automática da atualização do artigo:', error);
            }
          }, 2000);
        }
        
        return true;
      } catch (error) {
        console.error('❌ Erro ao atualizar artigo:', error);
        return false;
      }
    },

    deleteArticle: (id: number) => {
      try {
        dispatch({ type: 'DELETE_ARTICLE', payload: id });
        return true;
      } catch (error) {
        console.error('❌ Erro ao deletar artigo:', error);
        return false;
      }
    },

    // Utility actions com verificação adequada de limites
    checkFreePlanLimits: () => {
      const userEmail = state.user?.email;
      const plan = state.user?.plano || 'Free';
      
      // Dev e admin sempre têm acesso ilimitado
      if (userEmail === 'dev@bia.com' || userEmail === 'admin@bia.com') {
        return {
          sites: true,
          ideas: true,
          articles: true
        };
      }
      
      // Importar função utilitária
      const { getPlanLimits, isFreePlan } = require('../utils/constants');
      
      if (isFreePlan(plan)) {
        const FREE_LIMITS = { sites: 1, ideas: 10, articles: 3 };
        return {
          sites: state.sites.length < FREE_LIMITS.sites,
          ideas: state.ideas.length < FREE_LIMITS.ideas,
          articles: state.articles.filter(a => a.status === 'Concluído').length < FREE_LIMITS.articles
        };
      }
      
      // Para planos pagos, verificar limites específicos
      const planLimits = getPlanLimits(plan);
      return {
        sites: planLimits.isUnlimited || state.sites.length < planLimits.sites,
        ideas: true, // Ideias sempre ilimitadas em planos pagos
        articles: state.articles.filter(a => a.status === 'Concluído').length < planLimits.articles
      };
    },

    isFreePlan: () => {
      const userEmail = state.user?.email;
      const userPlan = state.user?.plano || 'Free';
      
      // Dev e admin sempre têm acesso ilimitado
      if (userEmail === 'dev@bia.com' || userEmail === 'admin@bia.com') {
        return false;
      }
      
      return userPlan === 'Free';
    },

    loadFromStorage: () => {
      try {
        const savedState = localStorage.getItem('bia-state');
        if (savedState) {
          const parsedState = JSON.parse(savedState);
          dispatch({ type: 'LOAD_STATE', payload: parsedState });
        }
      } catch (error) {
        console.error('❌ Erro ao carregar do localStorage:', error);
      }
    },

    saveToStorage: () => {
      saveToLocalStorage();
    },

    syncWithDatabase,
    loadFromDatabase,

    // Método para forçar sync imediato com banco (usado após conexão WordPress)
    forceSyncToDatabase: async () => {
      if (!state.user?.id) {
        console.warn('⚠️ Não é possível sincronizar sem usuário logado');
        return false;
      }

      if (!navigator.onLine) {
        console.log('🔴 Sistema offline, não é possível sincronizar agora');
        return false;
      }

      try {
        console.log('🔄 === SINCRONIZAÇÃO FORÇADA PARA SUPABASE ===');
        console.log(`👤 Usuário: ${state.user.email} (ID: ${state.user.id})`);
        console.log(`📊 Dados para sync forçado:`, {
          sites: state.sites.length,
          ideas: state.ideas.length,
          articles: state.articles.length
        });
        
        const syncData = {
          sites: state.sites,
          ideas: state.ideas,
          articles: state.articles
        };

        const result = await databaseService.syncUserData(state.user.id, syncData);
        
        if (result.success) {
          dispatch({ type: 'SET_LAST_SYNC', payload: new Date().toISOString() });
          dispatch({ type: 'SET_ERROR', payload: null });
          console.log('✅ === SINCRONIZAÇÃO FORÇADA CONCLUÍDA ===');
          console.log('📈 Todos os dados foram persistidos no Supabase');
          return true;
        } else {
          console.error('❌ Falha na sincronização forçada:', result.error);
          return false;
        }
      } catch (error) {
        console.error('❌ Erro na sincronização forçada:', error);
        return false;
      }
    },

    forceLoadFromDatabase: async () => {
      if (!state.user?.id) {
        console.warn('⚠️ Não é possível carregar sem usuário logado');
        return;
      }

      if (!navigator.onLine) {
        console.log('🔴 Sistema offline, não é possível carregar agora');
        return;
      }

      try {
        console.log('📥 === CARREGAMENTO FORÇADO DO SUPABASE ===');
        console.log(`👤 Usuário: ${state.user.email} (ID: ${state.user.id})`);
        
        const result = await databaseService.loadUserData(state.user.id);
        
        if (result.success && result.data) {
          const bankSites = result.data.sites || [];
          const bankIdeas = result.data.ideas || [];
          const bankArticles = result.data.articles || [];
          
          console.log('📊 Dados carregados do Supabase:', {
            sites: bankSites.length,
            ideas: bankIdeas.length,
            articles: bankArticles.length
          });

          // Substituir dados locais pelos dados do Supabase
          dispatch({ type: 'SET_SITES', payload: bankSites });
          dispatch({ type: 'SET_IDEAS', payload: bankIdeas });
          dispatch({ type: 'SET_ARTICLES', payload: bankArticles });
          dispatch({ type: 'SET_LAST_SYNC', payload: new Date().toISOString() });
          dispatch({ type: 'SET_ERROR', payload: null });
          
          console.log('✅ === CARREGAMENTO FORÇADO CONCLUÍDO ===');
          console.log('📈 Dados do Supabase carregados com sucesso');
        } else {
          console.warn('⚠️ Falha no carregamento forçado:', result.error);
        }
      } catch (error) {
        console.error('❌ Erro no carregamento forçado:', error);
      }
    },

    clearError: () => {
      dispatch({ type: 'SET_ERROR', payload: null });
    },

    // Consumption control functions (with credits support)
    checkConsumptionLimits: async (resourceType: 'ideas' | 'articles' | 'sites') => {
      const user = state.user;
      if (!user) {
        return { canConsume: false, reason: 'Usuário não logado' };
      }
      
      try {
        const { databaseService } = await import('../services/databaseService');
        // Usar a função que considera créditos extras
        return await databaseService.checkConsumptionLimitsWithCredits(user.id, resourceType, user.plano);
      } catch (error) {
        console.error('❌ Erro ao verificar limites:', error);
        // Em caso de erro, permitir consumo (fail open)
        return { canConsume: true };
      }
    },

    recordResourceConsumption: async (resourceType: 'ideas' | 'articles' | 'sites', quantity: number = 1) => {
      const user = state.user;
      if (!user) {
        console.warn('⚠️ Tentativa de registrar consumo sem usuário logado');
        return false;
      }
      
      try {
        const { databaseService } = await import('../services/databaseService');
        return await databaseService.recordResourceConsumption(user.id, resourceType, quantity);
      } catch (error) {
        console.error('❌ Erro ao registrar consumo:', error);
        return false;
      }
    }
  };

  return (
    <BiaContext.Provider value={{ state, actions }}>
      {children}
    </BiaContext.Provider>
  );
}

// Hook para usar o contexto
export function useBia() {
  const context = useContext(BiaContext);
  if (context === undefined) {
    throw new Error('useBia must be used within a BiaProvider');
  }
  return context;
}